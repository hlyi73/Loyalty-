package com.loyalty.generator;

import java.util.Random;
import java.util.UUID;

/*
 * ����
 */
public class PrimaryKeyGenerator {
	private static PrimaryKeyGenerator pkg = null;
	private final static Object key = new Object();

	private PrimaryKeyGenerator() {
	}

	public static PrimaryKeyGenerator getInstance() {
		if (null == pkg) {
			synchronized (key) {
				if (null == pkg) {
					pkg = new PrimaryKeyGenerator();
				}
			}
		}
		return pkg;
	}

	public synchronized String generate() {
		UUID pk = UUID.randomUUID();
		return String.valueOf(pk);
	}
}
