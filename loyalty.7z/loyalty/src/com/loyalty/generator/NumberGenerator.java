package com.loyalty.generator;

import java.util.Random;

/*
 * ����
 */
public class NumberGenerator {
	private static NumberGenerator mng = null;
	private final static Object object = new Object();

	private NumberGenerator() {
	}

	public static NumberGenerator getInstance() {
		if (null == mng) {
			synchronized (object) {
				if (null == mng) {
					mng = new NumberGenerator();
				}
			}
		}
		return mng;
	}

	public String generate() {
		return String.valueOf(System.currentTimeMillis());
	}
}
