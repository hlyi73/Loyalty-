package com.loyalty.generator;

import java.util.Random;

/*
 * ����
 */
public class CardNoGenerator {
	private static CardNoGenerator gng = null;
	private final static Object object = new Object();

	private CardNoGenerator() {
	}

	public static CardNoGenerator getInstance() {
		if (null == gng) {
			synchronized (object) {
				if (null == gng) {
					gng = new CardNoGenerator();
				}
			}
		}
		return gng;
	}

	public synchronized String generate() {
		return String.valueOf(System.currentTimeMillis());
	}
}
