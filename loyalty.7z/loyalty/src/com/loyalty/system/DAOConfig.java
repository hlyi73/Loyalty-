package com.loyalty.system;

import java.io.Reader;
import java.util.Properties;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

import com.ibatis.common.resources.Resources;
import com.ibatis.dao.client.DaoManager;
import com.ibatis.dao.client.DaoManagerBuilder;

public class DAOConfig {
	private static final String resource = "dao.xml";
	private static final Lock lock = new ReentrantLock();
	
	private static DaoManager daoManager;

	public static DaoManager getDaoManager() {
		if (daoManager == null) {
			lock.lock();
			try {
				if (daoManager == null)
					daoManager = newDaoManager(null);
			} finally {
				lock.unlock();
			}
		}	
		return daoManager;
	}

	public static DaoManager newDaoManager(Properties props) {
		try {
			Reader reader = Resources.getResourceAsReader(resource);
			return DaoManagerBuilder.buildDaoManager(reader, props);
		} catch (Exception e) {
			e.printStackTrace();
			new RuntimeException(
					"Could not initialize DaoConfig.  Cause: " + e, e);
		}
		return null;
	}
}