package com.loyalty.core;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.loyalty.action.main.MemberAct;
import com.loyalty.bean.MemberInfo;
import com.loyalty.bean.OrderInfo;
import com.loyalty.bean.OrganizationInfo;
import com.loyalty.bean.PromotionInfo;
import com.loyalty.dto.MAttributes;
import com.loyalty.dto.MExclusiveCondition;
import com.loyalty.dto.MLoyOrder;
import com.loyalty.dto.MLoyOrderItem;
import com.loyalty.dto.MMember;
import com.loyalty.dto.MPromotion;
import com.loyalty.util.DateUtil;
import com.loyalty.util.LoyaltyConstants;
import com.loyalty.util.ObjectUtil;
import com.ruixue.rfw.util.CollectionUtil;

/**
 * @ClassName: PromotionManger
 * @Description: promotion����
 * @author
 * @date Oct 9, 2009 4:28:43 PM
 * 
 */
public class PromotionManger {
	
	private static final CollectionUtil.Filter<PromotionInfo> FILTER_PROMTYPE_BONUS = new CollectionUtil.Filter<PromotionInfo>() {
		@Override
		public Class<PromotionInfo> getType() {
			return PromotionInfo.class;
		}
		@Override
		public boolean evaluate(PromotionInfo arg0) {
			return LoyaltyConstants.PROMOTION_TYPE_BONUS.equals(arg0.getType());
		}
	};
	
	private static final CollectionUtil.Filter<PromotionInfo> FILTER_PROMTYPE_TIER = new CollectionUtil.Filter<PromotionInfo>() {
		@Override
		public Class<PromotionInfo> getType() {
			return PromotionInfo.class;
		}
		@Override
		public boolean evaluate(PromotionInfo arg0) {
			return LoyaltyConstants.PROMOTION_TYPE_TIER.equals(arg0.getType());
		}
	};
	
	private static final CollectionUtil.Filter<PromotionInfo> FILTER_PROMTYPE_QUALIFY = new CollectionUtil.Filter<PromotionInfo>() {
		@Override
		public Class<PromotionInfo> getType() {
			return PromotionInfo.class;
		}
		@Override
		public boolean evaluate(PromotionInfo arg0) {
			return LoyaltyConstants.PROMOTION_TYPE_QUALIFY.equals(arg0.getType());
		}
	};

	/**
	 * @Title: checkExclusiveCondition
	 * @Description: �жϻ�������
	 * @param
	 * @param lst
	 * @param
	 * @return
	 * @return boolean
	 * @throws
	 */
	private boolean checkExclusiveCondition(List<MExclusiveCondition> lst,
			ActionObject obj) {

		for (int j = 0; lst != null && j < lst.size(); j++) {
			MExclusiveCondition cond = lst.get(j);
			PromotionService db = PromotionService.getInstance();
			MAttributes mAttributes = db.getMAttributes(cond.getATTR_ID());
			if (mAttributes == null || mAttributes.getATTR_TYPE() == null
					|| mAttributes.getDATA_TYPE() == null
					|| cond.getOPERATE() == null) {
				return false;
			}
			Attribute attr = new AttributeImpl(mAttributes, obj.getEnv());
			Object attrValue = attr.getAttributes();
			CriteriaImpl cr = new CriteriaImpl();
			Object attValueTo = cr.getOperateResult(cond.getCRITERIA_VALUE(),
					mAttributes.getDATA_TYPE());
			List<Object> lstAttValueTo = new ArrayList<Object>();
			lstAttValueTo.add(attValueTo);
			if (!cr.compare(attrValue, lstAttValueTo, cond.getOPERATE(),
					mAttributes.getDATA_TYPE())) {
				return false;
			}
		}
		return true;
	}

	/**
	 * @Title: onExclusive
	 * @Description: ���⴦��
	 * @param
	 * @return void
	 * @throws
	 */
	public List<String> onExclusive(MLoyOrder order) {
		PromotionService db = PromotionService.getInstance();
		List<String> exclusiveList = new ArrayList<String>();
		List<String> lst = db.selectMExclusivebyProgram(order.getPROGRAM_ID());
		ActionObject obj = new ActionObject(order);
		for (int i = 0; lst != null && i < lst.size(); i++) {
			List<MExclusiveCondition> lstCon = db
					.selectMExclusiveConditionByME(lst.get(i));

			if (checkExclusiveCondition(lstCon, obj)) {
				List<String> lstPT = db.selectPromotionbyMExclusive(order
						.getPROGRAM_ID(), lst.get(i),
						LoyaltyConstants.EXCLUSIVE_TYPE_FALSE);
				exclusiveList.addAll(lstPT);
			} else {
				List<String> lstPF = db.selectPromotionbyMExclusive(order
						.getPROGRAM_ID(), lst.get(i),
						LoyaltyConstants.EXCLUSIVE_TYPE_TRUE);
				exclusiveList.addAll(lstPF);
			}
		}
		return exclusiveList;
	}

	// /**
	// * @Title: Init
	// * @Description: ��ʼ�����׵Ļ���
	// * @param @param order
	// * @return void
	// * @throws
	// */
	// public void Init(MLoyOrder order){
	//		   
	// this.ctx.setCustomerId(order.getCUSTOMER_ID());
	// this.ctx.setMemberId(order.getMEMBER_ID());
	// this.ctx.setOrderId(order.getID());
	// this.ctx.setProgramId(order.getPROGRAM_ID());
	// this.exclusiveList.clear();
	// }

	// /**
	// * @Title: Init
	// * @Description: ��ʼ����Ա�Ļ���
	// * @param @param member
	// * @return void
	// * @throws
	// */
	// public void Init(MMember member){
	//		   
	// this.ctx.setCustomerId(member.getCUSTOMER_ID());
	// this.ctx.setMemberId(member.getID());
	// this.ctx.setOrderId("");
	// this.ctx.setProgramId(member.getPROGRAM_ID());
	// this.exclusiveList.clear();
	// }

	/**
	 * @Title: onMember
	 * @Description: ��Ա��promotion����
	 * @param
	 * @param member
	 * @param
	 * @throws Exception
	 * @return void
	 * @throws
	 */
	public void onMember(MMember member, String strSysDate) throws Exception {

		Date sysDate = DateUtil.parseStringToDate(strSysDate);
		ActionObject obj = new ActionObject(member, sysDate);
		// onBaseMember(obj);
		onQuitMember(obj);
		onBonusMember(obj);
		onTierMember(obj);
		onValidPeriodMember(obj);
	}
	
	public void onTimly(MMember member, String strSysDate, Map<String, Object> params) throws Exception {
		Date sysDate = DateUtil.parseStringToDate(strSysDate);
		ActionObject obj = new ActionObject(member, sysDate, params);
		onPointTimly(obj, LoyaltyConstants.PROMOTION_TYPE_DISQUALIFY);
		onPointTimly(obj, LoyaltyConstants.PROMOTION_TYPE_BONUS);
		onPointTimly(obj, LoyaltyConstants.PROMOTION_TYPE_TIER);
		onPointTimly(obj, LoyaltyConstants.PROMOTION_TYPE_VALIDPERIOD);
	}
	
	public void onTimly(MemberInfo member, String strSysDate, Map<String, Object> params) throws Exception {
		Date sysDate = DateUtil.parseStringToDate(strSysDate);
		ActionObject obj = new ActionObject(member, sysDate, params);
		onPointTimly(obj);
	}
	
	public void onOrderToPoint(OrderInfo o, OrganizationInfo org, Date sysDate) throws Exception {
		ActionObject obj = new ActionObject(org, o, sysDate);
		
		onOrderToPoint(obj);
	}

	/**
	 * @Title: onOrder
	 * @Description: ���׵�promotion�Ĵ���
	 * @param
	 * @param order
	 * @param
	 * @throws Exception
	 * @return void
	 * @throws
	 */
	public void onOrder(MLoyOrder order) throws Exception {
		ActionObject obj = new ActionObject(order);

		// ��Ч��
		onValidPeriodOrder(obj);
		// base item
		onOrderItem(order);
		// Base
		onBaseOrder(obj);
		// Bonus
		// ���㻥��
		List<String> exclusiveList = onExclusive(order);
		onBonusOrder(obj, exclusiveList);
		// �������ֵ
		// MemberAct.addB
		generateMaxValue(order.getPROGRAM_ID(), order.getID());
		// ----
		MemberAct mAct = (MemberAct) ObjectUtil.getAction(MemberAct.class);
		mAct.addBonusPoints(order.getID(), order.getMEMBER_ID(), obj.getEnv()
				.getCtxDate());
		// ---
		// �ӷ�
		// Tier
		onTierOrder(obj);

	}

	/**
	 * @Title: onOrderItem
	 * @Description: ������ϸ�Ĵ���
	 * @param
	 * @param order
	 * @param
	 * @throws Exception
	 * @return void
	 * @throws
	 */
	private void onOrderItem(MLoyOrder order) throws Exception {
		PromotionService db = PromotionService.getInstance();
		List<MLoyOrderItem> list = db.getOrderItem(order.getID());
		for (int i = 0; list != null && i < list.size(); i++) {
			ActionObject obj = new ActionObject(list.get(i), order);
			// Base
			onBaseItem(obj);
			// Bonus
			onBonusItem(obj);
			// Tier
			onTierItem(obj);
			// ��Ч��
			onValidPeriodItem(obj);
		}
	}

	/**
	 * @Title: onSpecialPromotion
	 * @Description: ���׵����⴦��
	 * @param
	 * @param order
	 * @param
	 * @param promotionType
	 * @param
	 * @throws Exception
	 * @return void
	 * @throws
	 */
	public void onSpecialPromotion(MLoyOrder order, String promotionType)
			throws Exception {
		PromotionService db = PromotionService.getInstance();
		Promotion p = PromotionImpl.getInstance();
		ActionObject obj = new ActionObject(order);
		// �����ڶ������������ǡ��˻�,����,�μӻ����״̬�ǡ�����ļ�¼
		List<MPromotion> lstPromotion = db.getPromotion(
				LoyaltyConstants.PROMOTION_SOURCE_ORDER, promotionType,
				LoyaltyConstants.LOYALTY_ACTIVE, order.getPROGRAM_ID());
		for (int i = 0; lstPromotion != null && i < lstPromotion.size(); i++) {
			p.init(lstPromotion.get(i), obj);
			p.run();
		}
		if (LoyaltyConstants.TRANS_TYPE_REFUND.equals(promotionType)) {
			List<MPromotion> lstPromotionItem = db.getPromotion(
					LoyaltyConstants.PROMOTION_SOURCE_ITEM,
					LoyaltyConstants.TRANS_TYPE_REFUND,
					LoyaltyConstants.LOYALTY_ACTIVE, order.getPROGRAM_ID());
			if (lstPromotionItem == null || lstPromotionItem.size() == 0)
				return;
			List<MLoyOrderItem> list = db.getOrderItem(order.getID());
			for (int i = 0; list != null && i < list.size(); i++) {
				ActionObject objItem = new ActionObject(list.get(i), order);
				for (int j = 0; lstPromotionItem != null
						&& j < lstPromotionItem.size(); j++) {
					p.init(lstPromotionItem.get(j), objItem);
					p.run();
				}

			}

		}
	}

	/**
	 * @Title: onQualify
	 * @Description: ���ݽ��ף��ж��Ƿ�������
	 * @param
	 * @param order
	 * @param
	 * @return
	 * @param
	 * @throws Exception
	 * @return boolean
	 * @throws
	 */
	public boolean onQualify(MLoyOrder order) throws Exception {
		boolean isSuccess = false;
		ActionObject obj = new ActionObject(order);
		Promotion p = PromotionImpl.getInstance();
		PromotionService db = PromotionService.getInstance();
		// ��Ա�ж�
		// �����ڶ������������ǡ���Ա�ж�����״̬�ǡ�����ļ�¼
		List<MPromotion> lstPromotion = db.getPromotion(
				LoyaltyConstants.PROMOTION_SOURCE_ORDER,
				LoyaltyConstants.PROMOTION_TYPE_QUALIFY,
				LoyaltyConstants.LOYALTY_ACTIVE, order.getPROGRAM_ID());

		for (int i = 0; lstPromotion != null && i < lstPromotion.size(); i++) {
			p.init(lstPromotion.get(i), obj);
			if (p.run()) {
				// ���ɹ�
				isSuccess = true;
				return isSuccess;
			}
		}
		List<MPromotion> lstPromotionItem = db.getPromotion(
				LoyaltyConstants.PROMOTION_SOURCE_ITEM,
				LoyaltyConstants.PROMOTION_TYPE_QUALIFY,
				LoyaltyConstants.LOYALTY_ACTIVE, order.getPROGRAM_ID());
		if (lstPromotionItem == null || lstPromotionItem.size() == 0)
			return isSuccess;
		List<MLoyOrderItem> list = db.getOrderItem(order.getID());
		for (int i = 0; list != null && i < list.size(); i++) {
			ActionObject objItem = new ActionObject(list.get(i), order);
			for (int j = 0; lstPromotionItem != null
					&& j < lstPromotionItem.size(); j++) {
				p.init(lstPromotionItem.get(j), objItem);
				if (p.run()) {
					// ���ɹ�
					isSuccess = true;
					return isSuccess;
				}
			}

		}
		return isSuccess;
	}

	// /**
	// * @Title: onOrderReDeemItem
	// * @Description: ��������Ƕһ��Ķ����Ĵ���
	// * @param
	// * @param order
	// * @return void
	// * @throws Exception
	// * @throws
	// */
	// public void onOrderReDeemItem(MLoyOrder order) throws Exception {
	// Promotion p = PromotionImpl.getInstance();
	// PromotionService db = PromotionService.getInstance();
	// // ȡ�ý�����ϸ
	// List<MLoyOrderItem> list = db.getOrderItem(order.getID());
	// // ȡ�öһ���promotion
	// List<MPromotion> promotionList = (List<MPromotion>) db.getPromotion(
	// LoyaltyConstants.PROMOTION_SOURCE_ITEM,
	// LoyaltyConstants.PROMOTION_TYPE_REDEEM,
	// LoyaltyConstants.LOYALTY_ACTIVE, order.getPROGRAM_ID());
	//
	// for (int i = 0; list != null && i < list.size(); i++) {
	// ActionObject obj = new ActionObject(list.get(i), order);
	//
	// for (int j = 0; promotionList != null && j < promotionList.size(); j++) {
	// // �һ�
	// p.init(promotionList.get(j), obj);
	// p.run();
	// }
	// }
	// }

	/**
	 * @Title: generateMaxValue
	 * @Description: promotion�����ֵ����
	 * @param
	 * @param programId
	 * @param
	 * @param orderId
	 * @return void
	 * @throws
	 */
	@SuppressWarnings("unchecked")
	public void generateMaxValue(String programId, String orderId) {
		PromotionService db = PromotionService.getInstance();
		List<Map<String, String>> lstMax = (List<Map<String, String>>) db
				.selectMMaxvalueByProgram(programId, orderId);
		String judgeMaxId = "";

		for (int i = 0; lstMax != null && i < lstMax.size(); i++) {
			HashMap mRela = (HashMap) lstMax.get(i);
			String currMaxId = (String) mRela.get("MAX_VALUE_ID");

			if (i == 0) {
				judgeMaxId = (String) mRela.get("MAX_VALUE_ID");
			}
			if (judgeMaxId.equals(currMaxId)) {
				if (i != 0) {
					if (mRela.get("POINTS") != null) {
						db.updateMorderDetailStatus((String) mRela
								.get("DETAIL_ID"),
								LoyaltyConstants.ORDER_DETAIL_INVALID);
					}
				}
			} else {
				judgeMaxId = currMaxId;
			}
		}

	}

	/**
	 * @Title: onBaseItem
	 * @Description: ������ϸ�Ļ����ۼƵĴ���
	 * @param
	 * @param item
	 * @param
	 * @param order
	 * @param
	 * @throws Exception
	 * @return void
	 * @throws
	 */
	private void onBaseItem(ActionObject obj) throws Exception {
		// Base Promotion
		Promotion p = PromotionImpl.getInstance();
		PromotionService db = PromotionService.getInstance();
		List<MPromotion> promotionList = (List<MPromotion>) db.getPromotion(
				LoyaltyConstants.PROMOTION_SOURCE_ITEM,
				LoyaltyConstants.PROMOTION_TYPE_BASE,
				LoyaltyConstants.LOYALTY_ACTIVE, obj.getEnv().getProgramId());

		for (int i = 0; promotionList != null && i < promotionList.size(); i++) {
			p.init(promotionList.get(i), obj);
			p.run();
		}

	}

	/**
	 * @Title: onBonusItem
	 * @Description: ������ϸ�Ľ����ִ���
	 * @param
	 * @param item
	 * @param
	 * @param order
	 * @param
	 * @throws Exception
	 * @return void
	 * @throws
	 */
	private void onBonusItem(ActionObject obj) throws Exception {
		// Tier

		Promotion p = PromotionImpl.getInstance();
		PromotionService db = PromotionService.getInstance();
		List<MPromotion> promotionList = (List<MPromotion>) db.getPromotion(
				LoyaltyConstants.PROMOTION_SOURCE_ITEM,
				LoyaltyConstants.PROMOTION_TYPE_BONUS,
				LoyaltyConstants.LOYALTY_ACTIVE, obj.getEnv().getProgramId());

		for (int i = 0; promotionList != null && i < promotionList.size(); i++) {
			p.init(promotionList.get(i), obj);
			p.run();
		}
	}

	/**
	 * @Title: onTierItem
	 * @Description: ������ϸ����������
	 * @param
	 * @param item
	 * @param
	 * @param order
	 * @param
	 * @throws Exception
	 * @return void
	 * @throws
	 */
	private void onTierItem(ActionObject obj) throws Exception {
		// titer

		Promotion p = PromotionImpl.getInstance();
		PromotionService db = PromotionService.getInstance();
		List<MPromotion> promotionList = (List<MPromotion>) db.getPromotion(
				LoyaltyConstants.PROMOTION_SOURCE_ITEM,
				LoyaltyConstants.PROMOTION_TYPE_TIER,
				LoyaltyConstants.LOYALTY_ACTIVE, obj.getEnv().getProgramId());

		for (int i = 0; promotionList != null && i < promotionList.size(); i++) {
			p.init(promotionList.get(i), obj);
			p.run();
		}
	}

	/**
	 * @Title: onValidPeriodItem
	 * @Description: ������ϸ����Ч�ڴ���
	 * @param
	 * @param item
	 * @param
	 * @param order
	 * @param
	 * @throws Exception
	 * @return void
	 * @throws
	 */
	private void onValidPeriodItem(ActionObject obj) throws Exception {

		PromotionService db = PromotionService.getInstance();
		Promotion p = PromotionImpl.getInstance();
		List<MPromotion> promotionList = (List<MPromotion>) db.getPromotion(
				LoyaltyConstants.PROMOTION_SOURCE_ITEM,
				LoyaltyConstants.PROMOTION_TYPE_VALIDPERIOD,
				LoyaltyConstants.LOYALTY_ACTIVE, obj.getEnv().getProgramId());

		for (int i = 0; promotionList != null && i < promotionList.size(); i++) {
			p.init(promotionList.get(i), obj);
			p.run();
		}
	}

	/**
	 * @Title: onBaseOrder
	 * @Description: ���׵Ļ����ۼƵĴ���
	 * @param
	 * @param order
	 * @param
	 * @throws Exception
	 * @return void
	 * @throws
	 */
	private void onBaseOrder(ActionObject obj) throws Exception {
		// Base Promotion

		Promotion p = PromotionImpl.getInstance();
		PromotionService db = PromotionService.getInstance();
		List<MPromotion> promotionList = (List<MPromotion>) db.getPromotion(
				LoyaltyConstants.PROMOTION_SOURCE_ORDER,
				LoyaltyConstants.PROMOTION_TYPE_BASE,
				LoyaltyConstants.LOYALTY_ACTIVE, obj.getEnv().getProgramId());
		for (int i = 0; promotionList != null && i < promotionList.size(); i++) {
			p.init(promotionList.get(i), obj);
			p.run();
		}
	}

	/**
	 * @Title: onTierOrder
	 * @Description: ���׵���������
	 * @param
	 * @param order
	 * @param
	 * @throws Exception
	 * @return void
	 * @throws
	 */
	private void onTierOrder(ActionObject obj) throws Exception {
		// Bonus
		Promotion p = PromotionImpl.getInstance();
		PromotionService db = PromotionService.getInstance();
		List<MPromotion> promotionList = (List<MPromotion>) db.getPromotion(
				LoyaltyConstants.PROMOTION_SOURCE_ORDER,
				LoyaltyConstants.PROMOTION_TYPE_TIER,
				LoyaltyConstants.LOYALTY_ACTIVE, obj.getEnv().getProgramId());
		for (int i = 0; promotionList != null && i < promotionList.size(); i++) {
			p.init(promotionList.get(i), obj);
			p.run();
		}
	}

	/**
	 * @Title: onBonusOrder
	 * @Description: ���׵Ľ����ִ���
	 * @param
	 * @param order
	 * @param
	 * @throws Exception
	 * @return void
	 * @throws
	 */
	private void onBonusOrder(ActionObject obj, List<String> exclusiveList)
			throws Exception {
		// bonus
		Promotion p = PromotionImpl.getInstance();
		PromotionService db = PromotionService.getInstance();
		List<MPromotion> promotionList = (List<MPromotion>) db.getPromotion(
				LoyaltyConstants.PROMOTION_SOURCE_ORDER,
				LoyaltyConstants.PROMOTION_TYPE_BONUS,
				LoyaltyConstants.LOYALTY_ACTIVE, obj.getEnv().getProgramId());

		for (int i = 0; promotionList != null && i < promotionList.size(); i++) {
			if (!(exclusiveList.contains(promotionList.get(i).getID()))) {
				p.init(promotionList.get(i), obj);
				p.run();
			}
		}
	}

	/**
	 * @Title: onValidPeriodOrder
	 * @Description: ���׵���Ч�ڴ���
	 * @param
	 * @param order
	 * @param
	 * @throws Exception
	 * @return void
	 * @throws
	 */
	private void onValidPeriodOrder(ActionObject obj) throws Exception {
		Promotion p = PromotionImpl.getInstance();
		PromotionService db = PromotionService.getInstance();
		List<MPromotion> promotionList = (List<MPromotion>) db.getPromotion(
				LoyaltyConstants.PROMOTION_SOURCE_ORDER,
				LoyaltyConstants.PROMOTION_TYPE_VALIDPERIOD,
				LoyaltyConstants.LOYALTY_ACTIVE, obj.getEnv().getProgramId());

		for (int i = 0; promotionList != null && i < promotionList.size(); i++) {
			p.init(promotionList.get(i), obj);
			p.run();
		}
	}

	// /**
	// * @Title: onBaseMember
	// * @Description: ��Ա�Ļ����ۻ�����
	// * @param
	// * @param member
	// * @param
	// * @throws Exception
	// * @return void
	// * @throws
	// */
	// private void onBaseMember(ActionObject obj) throws Exception {
	//
	// Promotion p = PromotionImpl.getInstance();
	// PromotionService db = PromotionService.getInstance();
	// List<MPromotion> promotionList = (List<MPromotion>) db.getPromotion(
	// LoyaltyConstants.PROMOTION_SOURCE_MEMBER,
	// LoyaltyConstants.PROMOTION_TYPE_BASE,
	// LoyaltyConstants.LOYALTY_ACTIVE, obj.getEnv().getProgramId());
	// for (int i = 0; promotionList != null && i < promotionList.size(); i++) {
	// p.init(promotionList.get(i), obj);
	// p.run();
	// }
	// }
	/**
	 * @Title: onQuitMember
	 * @Description: TODO
	 * @param
	 * @param obj
	 * @param
	 * @throws Exception
	 * @return void
	 * @throws
	 */
	private void onQuitMember(ActionObject obj) throws Exception {
		Promotion p = PromotionImpl.getInstance();
		PromotionService db = PromotionService.getInstance();
		List<MPromotion> promotionList = (List<MPromotion>) db.getPromotion(
				LoyaltyConstants.PROMOTION_SOURCE_MEMBER,
				LoyaltyConstants.PROMOTION_TYPE_DISQUALIFY,
				LoyaltyConstants.LOYALTY_ACTIVE, obj.getEnv().getProgramId());
		for (int i = 0; promotionList != null && i < promotionList.size(); i++) {
			p.init(promotionList.get(i), obj);
			p.run();
		}
	}

	//add start 2014/04/16 liuxingya
	/**
	 * ����ʵʱ��
	 */
	private void onPointTimly(ActionObject obj) throws Exception {
		FluentTimlyImpl p = new FluentTimlyImpl();
		PromotionService db = PromotionService.getInstance();
		List<PromotionInfo> proms = (List<PromotionInfo>) db.getActivityPromotions(
			obj.getEnv().getProgramId(), "M_REAL_TIME");
		
		PromotionInfo[] exec = null;
		/*if (!obj.getEnv().getMember().isBind()) {
			exec = CollectionUtil.toArray(proms, FILTER_PROMTYPE_QUALIFY);
			if (exec.length > 0)
				for (PromotionInfo prom : exec) {
					p.init(prom, obj);
					p.run();
				}
		}
		
		if (obj.getEnv().getMember().isBind()) {*/
			exec = CollectionUtil.toArray(proms, FILTER_PROMTYPE_BONUS);
			if (exec.length > 0)
				for (PromotionInfo prom : exec) {
					p.init(prom, obj);
					p.run();
				}
			
			exec = CollectionUtil.toArray(proms, FILTER_PROMTYPE_TIER);
			if (exec.length > 0)
				for (PromotionInfo prom : exec) {
					p.init(prom, obj);
					p.run();
				}
		//}
	}
	//add end 2014/04/16 liuxingya
	
	/**
	 * ����ʵʱ��
	 */
	private void onOrderToPoint(ActionObject obj) throws Exception {
		FluentTimlyImpl p = new FluentTimlyImpl();
		PromotionService db = PromotionService.getInstance();
		List<PromotionInfo> proms = (List<PromotionInfo>) db.getActivityPromotions(
			obj.getEnv().getProgram().getId(), "M_ORDER_POINT");
		
		PromotionInfo[] exec = CollectionUtil.toArray(proms, FILTER_PROMTYPE_QUALIFY);
		if (exec.length > 0)
			for (PromotionInfo prom : exec) {
				p.init(prom, obj);
				p.run();
			}
	
		exec = CollectionUtil.toArray(proms, FILTER_PROMTYPE_BONUS);
		if (exec.length > 0)
			for (PromotionInfo prom : exec) {
				p.init(prom, obj);
				p.run();
			}
		
		exec = CollectionUtil.toArray(proms, FILTER_PROMTYPE_TIER);
		if (exec.length > 0)
			for (PromotionInfo prom : exec) {
				p.init(prom, obj);
				p.run();
			}
	}
	
	/**
	 * ����ʵʱ��
	 */
	private void onPointTimly(ActionObject obj, String type) throws Exception {
		Promotion p = TimlyImpl.getInstance();
		PromotionService db = PromotionService.getInstance();
		List<MPromotion> promotionList = (List<MPromotion>) db.getPromotion(
				LoyaltyConstants.PROMOTION_SOURCE_REAL_TIME,
				type,
				LoyaltyConstants.LOYALTY_ACTIVE, obj.getEnv().getProgramId());
		for (int i = 0; promotionList != null && i < promotionList.size(); i++) {
			p.init(promotionList.get(i), obj);
			p.run();
		}
	}
	
	/**
	 * @Title: onBonusMember
	 * @Description: ��Ա�Ľ����ִ���
	 * @param
	 * @param member
	 * @param
	 * @throws Exception
	 * @return void
	 * @throws
	 */
	private void onBonusMember(ActionObject obj) throws Exception {
		Promotion p = PromotionImpl.getInstance();
		PromotionService db = PromotionService.getInstance();
		List<MPromotion> promotionList = (List<MPromotion>) db.getPromotion(
				LoyaltyConstants.PROMOTION_SOURCE_MEMBER,
				LoyaltyConstants.PROMOTION_TYPE_BONUS,
				LoyaltyConstants.LOYALTY_ACTIVE, obj.getEnv().getProgramId());
		for (int i = 0; promotionList != null && i < promotionList.size(); i++) {
			p.init(promotionList.get(i), obj);
			p.run();
		}
	}

	/**
	 * @Title: onTierMember
	 * @Description: ��Ա�����Ĵ���
	 * @param
	 * @param member
	 * @param
	 * @throws Exception
	 * @return void
	 * @throws
	 */
	private void onTierMember(ActionObject obj) throws Exception {
		Promotion p = PromotionImpl.getInstance();
		PromotionService db = PromotionService.getInstance();
		List<MPromotion> promotionList = (List<MPromotion>) db.getPromotion(
				LoyaltyConstants.PROMOTION_SOURCE_MEMBER,
				LoyaltyConstants.PROMOTION_TYPE_TIER,
				LoyaltyConstants.LOYALTY_ACTIVE, obj.getEnv().getProgramId());
		for (int i = 0; promotionList != null && i < promotionList.size(); i++) {
			p.init(promotionList.get(i), obj);
			p.run();
		}

	}

	/**
	 * @Title: onValidPeriodMember
	 * @Description: ��Ա��Ч�ڵĴ���
	 * @param
	 * @param member
	 * @param
	 * @throws Exception
	 * @return void
	 * @throws
	 */
	private void onValidPeriodMember(ActionObject obj) throws Exception {
		Promotion p = PromotionImpl.getInstance();
		PromotionService db = PromotionService.getInstance();
		List<MPromotion> promotionList = (List<MPromotion>) db.getPromotion(
				LoyaltyConstants.PROMOTION_SOURCE_MEMBER,
				LoyaltyConstants.PROMOTION_TYPE_VALIDPERIOD,
				LoyaltyConstants.LOYALTY_ACTIVE, obj.getEnv().getProgramId());
		for (int i = 0; promotionList != null && i < promotionList.size(); i++) {
			p.init(promotionList.get(i), obj);
			p.run();
		}
	}
}
