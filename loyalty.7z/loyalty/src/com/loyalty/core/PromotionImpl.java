package com.loyalty.core;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.log4j.Logger;

import com.loyalty.bean.PromotionInfo;
import com.loyalty.dto.MCriteria;
import com.loyalty.dto.MCustCriteria;

import com.loyalty.dto.MLoyOrderItem;
import com.loyalty.dto.MMemberTier;
import com.loyalty.dto.MPromotion;
import com.loyalty.dto.MRule;
import com.loyalty.util.LoyaltyConstants;
import com.ruixue.rfw.util.CollectionUtil;

/**
 * @ClassName: PromotionImpl
 * @Description: promotion��ʵ����
 * @author
 * @date Oct 9, 2009 4:30:52 PM
 * 
 */
public class PromotionImpl implements Promotion {
	private LoyaltyContext ctx;
	private MPromotion mp;

	private static Promotion impl = null;
	private final static Object objLock = new Object();
	static Logger logger = Logger.getLogger(PromotionImpl.class.getName());

	private PromotionImpl() {
		ctx = new LoyaltyContext();
		mp = new MPromotion();
	}

	public static Promotion getInstance() {
		if (impl == null) {
			synchronized (objLock) {
				if (impl == null)
					impl = new PromotionImpl();
			}
		}
		return (Promotion) impl;
	}

	public void init(MPromotion mp, ActionObject obj) {
		this.mp = mp;
		this.ctx = obj.getEnv();
		ctx.setPromotionId(mp.getID());
	}

	/**
	 * @Title: isValid
	 * @Description: �ж�һ��promotion�Ƿ���Ч
	 * @param
	 * @return
	 * @return boolean
	 * @throws
	 */
	private boolean isValid(MPromotion mp, Date ctxDate) {
		Date start = mp.getSTART_DATE();
		Date end = mp.getEND_DATE();
		Date now = ctxDate;

		boolean blnOk = true;
		if (now == null)
			return false;
		if (start != null) {
			if (start.after(now)) {
				blnOk = false;
				return blnOk;
			}

		}
		if (end != null) {
			if (end.before(now))
				blnOk = false;
		}
		return blnOk;
	}

	/**
	 * @Title: judgeProduct
	 * @Description: �ж�һ��promotion�Ƿ������Ʒ
	 * @param
	 * @param product
	 * @param
	 * @return
	 * @return boolean
	 * @throws
	 */
	private boolean judgeProduct(MPromotion mp, String product) {
		String productType = mp.getINCLUDE_PRODUCT();

		if (LoyaltyConstants.PROMOTION_ALLPRODUCT.equals(productType)) {
			return true;
		} else if (LoyaltyConstants.PROMOTION_INCLUDEPRODUCT
				.equals(productType)) {
			PromotionService db = PromotionService.getInstance();
			List<String> lst = db.getIncludeProductList(mp.getID());
			if (lst.contains(product)) {
				return true;
			}
		} else if (LoyaltyConstants.PROMOTION_EXCLUDEPRODUCT
				.equals(productType)) {
			PromotionService db = PromotionService.getInstance();
			List<String> lst = db.getIncludeProductList(mp.getID());
			if (!lst.contains(product)) {
				return true;
			}
		}
		return false;
	}

	/**
	 * @Title: judgeTier
	 * @Description: �ж�һ��promotion�����ĵ��û��ȼ�
	 * @param
	 * @param tier
	 * @param
	 * @return
	 * @return boolean
	 * @throws
	 */
	private boolean judgeTier(MPromotion mp, String memberId) {
		PromotionService db = PromotionService.getInstance();
		List<MMemberTier> tier = db.selectTierByMember(memberId,
				LoyaltyConstants.LOYALTY_ACTIVE);
		String tierType = mp.getINCLUDE_TIER();
		if (LoyaltyConstants.PROMOTION_ALLTIER.equals(tierType)) {
			return true;
		} else if (LoyaltyConstants.PROMOTION_INCLUDETIER.equals(tierType)) {

			List<String> lst = db.getIncludeTierList(mp.getID());
			if (lst == null || lst.size() == 0)
				return false;
			if (tier == null || tier.size() == 0)
				return false;
			for (int i = 0; i < tier.size(); i++) {
				if (lst.contains(tier.get(i).getTIER())) {
					return true;
				}
			}
		} else if (LoyaltyConstants.PROMOTION_EXCLUDETIER.equals(tierType)) {

			List<String> lst = db.getIncludeTierList(mp.getID());
			if (lst == null || lst.size() == 0)
				return true;
			if (tier == null || tier.size() == 0)
				return false;
			for (int i = 0; i < tier.size(); i++) {
				if (lst.contains(tier.get(i).getTIER())) {
					return false;
				}
			}
			return true;
		}
		return false;
	}

	/**
	 * @Title: decideCriteria
	 * @Description: �ж�һ���ǿͻ���������
	 * @param
	 * @param cr
	 * @param
	 * @return
	 * @return boolean
	 * @throws
	 */
	private boolean decideCriteria(MCriteria cr) {
		CriteriaImpl crImpl = new CriteriaImpl(cr, ctx);
		return crImpl.checkCriteria();
	}

	/**
	 * @Title: decideCriteria
	 * @Description: �ж�һ���ͻ�������
	 * @param
	 * @param custCr
	 * @param
	 * @return
	 * @return boolean
	 * @throws
	 */
	private boolean decideCriteria(MCustCriteria custCr) {
		CustCriteriaImpl impl = new CustCriteriaImpl(custCr, ctx);
		return impl.checkCriteria();
	}

	/**
	 * @Title: runActions
	 * @Description: ��������
	 * @param
	 * @param rule
	 * @param
	 * @throws Exception
	 * @return void
	 * @throws
	 */
	private void runActions(MRule rule) throws Exception {

		ctx.setRuleId(rule.getID());
		Action run = new Action(ctx);
		run.onAction();
	}

	/**
	 * @Title: isMemberActivity
	 * @Description: �жϵ�ǰ�Ļ�Ա�Ƿ�����promotion�û�����
	 * @param
	 * @param mp
	 * @param
	 * @param ctx
	 * @param
	 * @return
	 * @return boolean
	 * @throws
	 */
	private boolean isMemberActivity(MPromotion mp, LoyaltyContext ctx) {

		if (judgeTier(mp, ctx.getMemberId()))
			return true;
		else
			return false;
	}

	/**
	 * @Title: isOrderItemActivity
	 * @Description: �ж϶���������item�Ķ����Ƿ���������
	 * @param
	 * @param mp
	 * @param
	 * @param ctx
	 * @param
	 * @return
	 * @return boolean
	 * @throws
	 */
	private boolean isOrderItemActivity(MPromotion mp, LoyaltyContext ctx) {
		boolean blnOk = isOrderActivity(mp, ctx);
		if (blnOk) {
			String product = ctx.getProductId();
			if (product == null || product.length() == 0)
				return false;
			else {
				if (judgeProduct(mp, product))
					return true;
				else
					return false;
			}
		} else
			return false;
	}

	/**
	 * @Title: isOrderActivity
	 * @Description: �ж϶���������order�Ķ����Ƿ���������
	 * @param
	 * @param mp
	 * @param
	 * @param ctx
	 * @param
	 * @return
	 * @return boolean
	 * @throws
	 */
	private boolean isOrderActivity(MPromotion mp, LoyaltyContext ctx) {
		String member = ctx.getMemberId();
		if (member == null || member.length() == 0) {
			if (LoyaltyConstants.PROMOTION_TYPE_QUALIFY.equals(mp.getTYPE())) {
				return true;
			} else {
				return false;
			}
		}
		if (judgeTier(mp, member))
			return true;
		else
			return false;
	}

	public Boolean isOrderActivityByProductAndTier(MPromotion mp,
			LoyaltyContext ctx) {
		String member = ctx.getMemberId();
		if (member == null || member.length() == 0) {
			if (LoyaltyConstants.PROMOTION_TYPE_QUALIFY.equals(mp.getTYPE())) {
				return true;
			} else {
				return false;
			}
		}
		Boolean isTierInclude = judgeTier(mp, member);
		String orderId = ctx.getOrderId();
		PromotionService db = PromotionService.getInstance();
		List<MLoyOrderItem> loyOrderItems = db.getOrderItem(orderId);
		Boolean isProductInclude = false;
		String productType = mp.getINCLUDE_PRODUCT();
		if (LoyaltyConstants.PROMOTION_ALLPRODUCT.equals(productType)) {
			isProductInclude = true;
		}
		if (!isProductInclude) {
			for (MLoyOrderItem item : loyOrderItems) {
				String product = item.getPRODUCT_ID();
				isProductInclude = judgeProduct(mp, product);
				if (isProductInclude) {
					break;
				}
			}
		}
		return isTierInclude && isProductInclude;
	}

	/**
	 * @Title: isActivity
	 * @Description: �ж϶��ڶ�������promotion�Ƿ���Ч
	 * @param
	 * @return
	 * @return boolean
	 * @throws
	 */
	private boolean isActivity(MPromotion mp, LoyaltyContext ctx) {
		if (LoyaltyConstants.ACTIONOBJECT_ORDER.equals(ctx.getObjType())) {
			return isOrderActivityByProductAndTier(mp, ctx);
		} else if (LoyaltyConstants.ACTIONOBJECT_ITEM.equals(ctx.getObjType())) {
			return isOrderItemActivity(mp, ctx);
		} else {
			return isMemberActivity(mp, ctx);
		}
	}

	/*
	 * (non-Javadoc) <p>Title: run</p> <p>Description: ִ�е�ǰpromotion</p>
	 * @return @throws Exception
	 * 
	 * @see com.loyalty.core.Promotion#run()
	 */

	public boolean run() throws Exception {
		boolean blnOk = false;
		logger.info("--promotion--" + mp.getNAME() + "��ʼִ��");
		if (!isValid(mp, ctx.getCtxDate())) {
			logger.info("--promotion--" + mp.getNAME()
							+ "ʧ��:���promotion��Ч��ʧ��.");
			return blnOk;
		}
		if (!isActivity(mp, ctx)) {
			logger.info("--promotion--" + mp.getNAME() + "û�б�����");
			return blnOk;
		}

		logger.info("--promotion--" + mp.getNAME() + "��Ч");
		logger.info("--promotion--" + mp.getNAME() + "����");
		PromotionService db = PromotionService.getInstance();
		
		List<MRule> list = db.selectRuleByPromotion(mp.getID());
// change start 2014/05/14 xuning		
		RULE_LOOP:for (int i = 0; list != null && i < list.size(); i++) {
			boolean isValid = true;
			Rule rule = new Rule((MRule) list.get(i));
			List<MCriteria> lstCr = rule.getCriteria();
			boolean hasMatchCrt = false;
			//���promotion������"���ֽ���"�򡰵ȼ����������ôֻ�й���������Ҫ��Ļ�Ա�ȼ��뵱ǰ��Ա�ȼ������ʱ��Żᱻִ��
			for(MCriteria crt : lstCr){
				if(crt.getCRITERIA_VALUE_NAME().equals(ctx.getTierName()) && (mp.getTYPE().equals(LoyaltyConstants.PROMOTION_TYPE_BONUS)) || mp.getTYPE().equals(LoyaltyConstants.PROMOTION_TYPE_TIER) 
						|| (!mp.getTYPE().equals(LoyaltyConstants.PROMOTION_TYPE_BONUS)) && !mp.getTYPE().equals(LoyaltyConstants.PROMOTION_TYPE_TIER)){
					hasMatchCrt = true;
				}
			}
			if(!hasMatchCrt){
				continue RULE_LOOP;
			}
// change end 2014/05/14 xuning
			
			
			for (int a = 0; lstCr != null && a < lstCr.size(); a++) {
				if (decideCriteria(lstCr.get(a))) {
					isValid = true;
					logger.info("--criteria--" + lstCr.get(a).getNAME() + "����");
				} else {
					logger.info("--criteria--" + lstCr.get(a).getNAME()
									+ "������");
					isValid = false;
					break;
				}
			}
			if (isValid) {
				List<MCustCriteria> lstCustCr = rule.getCustCriteria();
				for (int b = 0; lstCustCr != null && b < lstCustCr.size(); b++) {

					if (decideCriteria(lstCustCr.get(b))) {
						logger.info("--Custcriteria--" + lstCr.get(b).getNAME()+ "����");
						isValid = true;
					} else {
						logger.info("--Custcriteria--" + lstCr.get(b).getNAME()+ "������");
						isValid = false;
						break;
					}
				}
				if (isValid) {
					logger.info("--action--" + "��ʼִ�ж���");
					runActions(rule.getRule());
					blnOk = true;
				}
			}
		}
		logger.info("--promotion--" + mp.getNAME() + "����");
		return blnOk;
	}
}
