package com.loyalty.core;


import com.loyalty.dto.MPromotion;


/**
* @ClassName: Promotion
* @Description: ��һ��promotion�Ľӿ�
* @author 
* @date Oct 9, 2009 4:31:43 PM
* 
*/
public interface Promotion {
	public void init(MPromotion mp,ActionObject obj);
    public boolean run() throws Exception;
}
