package com.loyalty.core;

import java.util.Date;
import java.util.Map;

import com.loyalty.bean.MemberInfo;
import com.loyalty.bean.OrderInfo;
import com.loyalty.bean.OrganizationInfo;
import com.loyalty.bean.ProgramInfo;
import com.loyalty.bean.PromotionInfo;


/**
* @ClassName: LoyaltyContext
* @Description: һ��promotion�����л���
* @author 
* @date Oct 9, 2009 4:32:03 PM
* 
*/
public class LoyaltyContext {
    //��������
	private String objType;
	private String promotionId;
	private Date ctxDate;
	private String programId;
	private String ruleId;
	private String orderId;
    private String orderItemId;
    private String productId;//��Ʒ���
	private String memberId;
	private String customerId;
//add start 2014/05/13 xuning	
	private String tierName;
	private String promotionType;
//add end 2014/05/13 xuning	
	//add start 2014/04/16 liuxingya
	// ����ʵʱ����
	private Map<String, Object> params;
	//add end 2014/04/16 liuxingya
	/** ��Ա��Ϣ */
	private MemberInfo member;
	/** ������Ϣ */
	private PromotionInfo promotion;
	/** ��֯��Ϣ */
	private OrganizationInfo org;
	/** ���ֲ���Ϣ */
	private ProgramInfo program;
	/** ������Ϣ */
	private OrderInfo orderInfo;

	public String getProductId() {
		return productId;
	}

	public void setProductId(String productId) {
		this.productId = productId;
	}

	public String getOrderItemId() {
		return orderItemId;
	}

	public void setOrderItemId(String orderItemId) {
		this.orderItemId = orderItemId;
	}

	public String getPromotionId() {
		return promotionId;
	}

	public void setPromotionId(String promotionId) {
		this.promotionId = promotionId;
	}

	public String getProgramId() {
		return programId;
	}

	public void setProgramId(String programId) {
		this.programId = programId;
	}

	public String getOrderId() {
		return orderId;
	}

	public void setOrderId(String orderId) {
		this.orderId = orderId;
	}

	public String getCustomerId() {
		return customerId;
	}

	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}

	public String getMemberId() {
		return memberId;
	}

	public void setMemberId(String memberId) {
		this.memberId = memberId;
	}

	public Date getCtxDate() {
		return ctxDate;
	}

	public void setCtxDate(Date ctxDate) {
		this.ctxDate = ctxDate;
	}

	public String getRuleId() {
		return ruleId;
	}

	public void setRuleId(String ruleId) {
		this.ruleId = ruleId;
	}

	public String getObjType() {
		return objType;
	}

	public void setObjType(String objType) {
		this.objType = objType;
	}

	//add start 2014/04/16 liuxingya
	
	
	public Map<String, Object> getParams() {
		return params;
	}

	public void setParams(Map<String, Object> params) {
		this.params = params;
	}
	//add end 2014/04/16 liuxingya

	/**
	 * ȡ��member
	 * @return member member
	 */
	public MemberInfo getMember() {
		return member;
	}

	/**
	 * ����member
	 * @param member member
	 */
	public void setMember(MemberInfo member) {
		this.member = member;
	}
	
//add start 2014/05/13 xuning	
	public String getTierName() {
		return tierName;
	}

	public String getPromotionType() {
		return promotionType;
	}

	public void setPromotionType(String promotionType) {
		this.promotionType = promotionType;
	}

	public void setTierName(String tierName) {
		this.tierName = tierName;
	}
//add end 2014/05/13 xuning

	/**
	 * ȡ�ù�����Ϣ
	 * @return promotion ������Ϣ
	 */
	public PromotionInfo getPromotion() {
		return promotion;
	}

	/**
	 * ���ù�����Ϣ
	 * @param promotion ������Ϣ
	 */
	public void setPromotion(PromotionInfo promotion) {
		this.promotion = promotion;
	}

	/**
	 * ��ȡ��֯��Ϣ  
	 * @return org ��֯��Ϣ
	 */
	public OrganizationInfo getOrg() {
		return org;
	}

	/**
	 * ������֯��Ϣ  
	 * @param org ��֯��Ϣ 
	 */
	public void setOrg(OrganizationInfo org) {
		this.org = org;
	}

	/**
	 * ��ȡ���ֲ���Ϣ  
	 * @return program ���ֲ���Ϣ
	 */
	public ProgramInfo getProgram() {
		return program;
	}

	/**
	 * ���þ��ֲ���Ϣ  
	 * @param program ���ֲ���Ϣ 
	 */
	public void setProgram(ProgramInfo program) {
		this.program = program;
	}

	/**
	 * ȡ�ö�����Ϣ
	 * @return orderInfo ������Ϣ
	 */
	public OrderInfo getOrderInfo() {
		return orderInfo;
	}

	/**
	 * ���ö�����Ϣ
	 * @param orderInfo ������Ϣ
	 */
	public void setOrderInfo(OrderInfo orderInfo) {
		this.orderInfo = orderInfo;
	}
	
}
