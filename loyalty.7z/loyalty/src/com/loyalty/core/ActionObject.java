package com.loyalty.core;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import com.loyalty.bean.MemberInfo;
import com.loyalty.bean.OrderInfo;
import com.loyalty.bean.OrganizationInfo;
import com.loyalty.bean.ProgramInfo;
import com.loyalty.dto.MLoyOrder;
import com.loyalty.dto.MLoyOrderItem;
import com.loyalty.dto.MMember;
import com.loyalty.util.LoyaltyConstants;

/**
 * @ClassName: ActionObject
 * @Description: �����������Լ�
 * @author
 * @date Oct 20, 2009 4:38:59 PM
 * 
 */
public class ActionObject {

	private static final String ACT_TYPE = "����";
	private static final String SUB_ACT_TYPE = "����ת����";
	private LoyaltyContext ctx = new LoyaltyContext();


	/**
	* <p>Title: ��ʼ��</p>
	* <p>Description: ��ʼ��һ�����ڶ����Ķ�������</p>
	* @param order
	*/
	public ActionObject(MLoyOrder order) {
		ctx.setObjType(LoyaltyConstants.ACTIONOBJECT_ORDER);
		ctx.setOrderId(order.getID());
		ctx.setMemberId(order.getMEMBER_ID());
		ctx.setCustomerId(order.getCUSTOMER_ID());
		ctx.setProgramId(order.getPROGRAM_ID());
		ctx.setCtxDate(order.getTRANS_DATE());
	}


	/**
	* <p>Title:��ʼ�� </p>
	* <p>Description: ��ʼ��һ�����ڶ�����Ķ�������</p>
	* @param item
	* @param order
	*/
	public ActionObject(MLoyOrderItem item, MLoyOrder order) {
		// order
		ctx.setObjType(LoyaltyConstants.ACTIONOBJECT_ITEM);
		ctx.setOrderId(order.getID());
		ctx.setMemberId(order.getMEMBER_ID());
		ctx.setCustomerId(order.getCUSTOMER_ID());
		ctx.setProgramId(order.getPROGRAM_ID());
		ctx.setCtxDate(order.getTRANS_DATE());
		// item
		ctx.setOrderItemId(item.getID());
		ctx.setProductId(item.getPRODUCT_ID());

	}


	/**
	* <p>Title:��ʼ�� </p>
	* <p>Description: ��ʼ��һ�������û��Ķ�������</p>
	* @param member
	*/
	public ActionObject(MMember member,Date sysDate) {
		ctx.setObjType(LoyaltyConstants.ACTIONOBJECT_MEMBER);
		ctx.setMemberId(member.getID());
		ctx.setCustomerId(member.getCUSTOMER_ID());
		ctx.setProgramId(member.getPROGRAM_ID());
		ctx.setCtxDate(sysDate);
//add start 2014/05/13 xuning
		ctx.setTierName(member.getTIER_NAME());
//add end 2014/05/13 xuning

	}
	//add start 2014/04/16 liuxingya
	/**
	 * ����ʵʱ��
	 */
	public ActionObject(MMember member, Date sysDate, Map<String, Object> params) {
		ctx.setObjType(LoyaltyConstants.ACTIONOBJECT_MEMBER);
		ctx.setMemberId(member.getID());
		ctx.setCustomerId(member.getCUSTOMER_ID());
		ctx.setProgramId(member.getPROGRAM_ID());
		ctx.setCtxDate(sysDate);
		ctx.setParams(params);
		ctx.setOrderId("0");
//add start 2014/05/13 xuning
		ctx.setTierName(member.getTIER_NAME());
//add end 2014/05/13 xuning		
	}
	//add end 2014/04/16 liuxingya
	
	/**
	 * ����ʵʱ��
	 */
	public ActionObject(MemberInfo member, Date sysDate, Map<String, Object> params) {
		ctx.setObjType(LoyaltyConstants.ACTIONOBJECT_MEMBER);
		ctx.setMember(member);
		ctx.setMemberId(member.getId());
		ctx.setCustomerId(member.getCustomerId());
		ctx.setProgramId(member.getProgramId());
		ctx.setCtxDate(sysDate);

		ctx.setParams(params);
		ctx.setOrderId("0");
//add start 2014/05/19 xuning		
		ctx.setTierName(member.getTiers().get(0).getName());
//add end 2014/05/19 xuning		
	}
	
	/**
	 * �������ת��������
	 */
	public ActionObject(OrganizationInfo org, Date sysDate) {
		ctx.setObjType(LoyaltyConstants.ACTIONOBJECT_ORDER);
		ctx.setOrg(org);
		for (ProgramInfo p : org.getPrograms()) {
			if (p.isActivity()) {
				ctx.setProgram(p);
				break;
			}
		}
		ctx.setCtxDate(sysDate);	
	}
	
	/**
	 * �������ת��������
	 */
	public ActionObject(OrganizationInfo org, OrderInfo ord, Date sysDate) {
		ctx.setObjType(LoyaltyConstants.ACTIONOBJECT_ORDER);
		ctx.setOrg(org);
		ctx.setProgram(org.getPrograms().get(0));
		ctx.setProgramId(ctx.getProgram().getId());
		ctx.setMember(ord.getMember());
		ctx.setOrderInfo(ord);
		ctx.setCtxDate(sysDate);
		Map<String, String> params = new HashMap<String, String>();
		params.put("p1", ACT_TYPE);
		params.put("p2", SUB_ACT_TYPE);
	}
	
	/**
	* @Title: getEnv
	* @Description: �õ�������������л���
	* @param @return   
	* @return LoyaltyContext    
	* @throws
	*/
	public LoyaltyContext getEnv() {
		return ctx;
	}
}
