package com.loyalty.core;

import java.util.List;
import com.loyalty.dto.MCriteria;
import com.loyalty.dto.MCustCriteria;
import com.loyalty.dto.MRule;

/**
* @ClassName: Rule
* @Description: �������
* @author 
* @date Oct 9, 2009 4:24:27 PM
* 
*/
public class Rule {
	private MRule  rule ;
	/**
	* <p>Title:Rule </p>
	* <p>Description:���캯�� </p>
	* @param rule
	*/
	public Rule(MRule rule){
		this.rule = rule;
	}
    /**
    * @Title: getCriteria
    * @Description: �õ������µ���������
    * @param @return   
    * @return List<MCriteria>    
    * @throws
    */
    public List<MCriteria> getCriteria()
    {
    	PromotionService db = PromotionService.getInstance();
    	return  db.selectCriteriaByRule(rule.getID());
    }
    /**
    * @Title: getCustCriteria
    * @Description: �õ���������Ŀͻ�����
    * @param @return   
    * @return List<MCustCriteria>    
    * @throws
    */
    public List<MCustCriteria> getCustCriteria()
    {
    	PromotionService db = PromotionService.getInstance();
    	return  db.selectCustCriteriaByRule(rule.getID());
    }
    
    /**
    * @Title: getRule
    * @Description: �õ��������
    * @param @return   
    * @return MRule    
    * @throws
    */
    public MRule getRule()
    {
    	return rule;
    }
 }
