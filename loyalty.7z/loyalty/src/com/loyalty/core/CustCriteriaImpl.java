package com.loyalty.core;

import com.loyalty.dto.MCustCriteria;

/**
* @ClassName: CustCriteriaImpl
* @Description: �ͻ�������ʵʩ
* @author 
* @date Oct 9, 2009 4:39:42 PM
* 
*/
public class CustCriteriaImpl implements Criteria{
    protected MCustCriteria custCr;
    private String memberId;
    private String orderId;
    /**
    * <p>Title: </p>
    * <p>Description: </p>
    * @param custCr
    * @param memberId
    */
    public  CustCriteriaImpl(MCustCriteria custCr,LoyaltyContext ctx){
    	this.custCr =custCr;
    	this.memberId=ctx.getMemberId();
    	this.orderId=ctx.getOrderId();
    }

	/*  (non-Javadoc)
	* <p>Title: һ���ͻ�������</p>
	* <p>Description: </p>
	* @return
	* @see com.loyalty.core.Criteria#checkCriteria()
	*/
	
	public boolean checkCriteria() {
		PromotionService db = PromotionService.getInstance();
		int i=db.callMCustCriteria(custCr.getMETHOD_NAME(), memberId,orderId);
		if(i==0)
			return true;
		else
		    return false;
	}
}
