package com.loyalty.core;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import com.loyalty.action.main.AttributeReviseAct;
import com.loyalty.action.main.CustomizationAct;
import com.loyalty.action.main.MemberAct;
import com.loyalty.action.main.QuitClubAct;
import com.loyalty.action.main.ReclaimDealAct;
import com.loyalty.action.main.RenewalAct;
import com.loyalty.bean.ActionInfo;
import com.loyalty.bean.RuleInfo;
import com.loyalty.dto.MAction;
import com.loyalty.dto.MCustAction;
import com.loyalty.exception.LoyaltyException;
import com.loyalty.exception.action.LoyaltyActionException;
import com.loyalty.service.ActionService;
import com.loyalty.util.LoyaltyConstants;
import com.loyalty.util.ObjectUtil;
import com.ruixue.rfw.util.StringUtil;

/**
 * 
 * @author Administrator
 */
public class Action {

	private ActionService as;
	private LoyaltyContext ctx;

	public Action(LoyaltyContext ctx) {
		as = (ActionService) ObjectUtil.getAction(ActionService.class);
		this.ctx = ctx;
	}

	/**
	 * ִ�ж���
	 * 
	 * @throws Exception
	 */
	public void onAction() throws Exception {
		if (ctx.getRuleId() == null) {
			throw new LoyaltyActionException("ִ�ж���:" + "ruleId is null.");
		}
		List<MAction> actions = this.as.getMActionsByRuleId(ctx.getRuleId());
		List<MCustAction> custActions = as.getCustActionsByRuleId(ctx
				.getRuleId());
		List<Object> allActions = sort(actions, custActions);

		for (Object o : allActions) {
			if (o instanceof MAction) {
				exacuteAction((MAction) o);
			}
			if (o instanceof MCustAction) {
				exacuteCustAction((MCustAction) o);
			}
		}
	}
	
	/**
	 * ִ�ж���
	 * 
	 * @throws Exception
	 */
	public void onAction(RuleInfo rule) throws LoyaltyException {

		List<ActionInfo> actions = this.as.getActionsByRuleId(rule.getId());
		
		//List<MCustAction> custActions = as.getCustActionsByRuleId(rule.getId());
		//List<Object> allActions = sort(actions, custActions);

		for (ActionInfo action : actions) {
			action.setRule(rule);
			execute(action);
		}
	}
	
	private void execute(ActionInfo a) throws LoyaltyException {
		
		boolean isSuccess = false;
		if (StringUtil.isEmpty(a.getType())) {
			throw new LoyaltyActionException("�޷��ж���Ҫִ�еĶ�������������Ϊ��.");
		}
		
		if (LoyaltyConstants.ACTION_ACTIONTYPE_M_ASSIGNPOINTS
			.equalsIgnoreCase(a.getType())) {
			isSuccess = ((MemberAct) ObjectUtil.getAction(MemberAct.class))
				.addRealTimePoints(a, ctx);
		} else if (LoyaltyConstants.ACTION_ACTIONTYPE_M_REDEEMPOINTS
				.equalsIgnoreCase(a.getType())) {
			isSuccess = ((ReclaimDealAct) ObjectUtil
					.getAction(ReclaimDealAct.class)).consumeRealTime(a, ctx);
	
		} else if (LoyaltyConstants.ACTION_ACTIONTYPE_M_QUALIFYMEMBER
				.equalsIgnoreCase(a.getType())) {
			isSuccess = ((MemberAct) ObjectUtil
				.getAction(MemberAct.class)).isMember(a, ctx);

		} else {
			// TODO
			ctx.setRuleId(a.getRule().getId());
			MAction ac = this.as.getActionById(a.getId());
			
			try {
				if (LoyaltyConstants.ACTION_ACTIONTYPE_M_DEGRADE
					.equalsIgnoreCase(a.getType())
					|| LoyaltyConstants.ACTION_ACTIONTYPE_M_UPGRADE
							.equalsIgnoreCase(a.getType())) {
					isSuccess = ((MemberAct) ObjectUtil.getAction(MemberAct.class))
							.adjustTier(ac, ctx);
	
				} else if (LoyaltyConstants.ACTION_ACTIONTYPE_M_UPDATEATTR
						.equalsIgnoreCase(a.getType())) {
					isSuccess = ((AttributeReviseAct) ObjectUtil
							.getAction(AttributeReviseAct.class)).revise(ac, ctx);
		
				} else if (LoyaltyConstants.ACTION_ACTIONTYPE_M_RENEWAL
						.equalsIgnoreCase(a.getType())) {
					isSuccess = ((RenewalAct) ObjectUtil.getAction(RenewalAct.class))
							.refreshTier(ac, ctx);
				} else if (LoyaltyConstants.ACTION_ACTIONTYPE_M_QUIT
						.equalsIgnoreCase(a.getType())) {
					isSuccess = ((QuitClubAct) ObjectUtil.getAction(QuitClubAct.class))
							.quit(ctx);
				}
			} catch (Exception e) {
				throw new LoyaltyActionException(e.getMessage(), e);
			}
		}
		
		if (!isSuccess) {
			throw new LoyaltyActionException(String.format("����ִ��ʧ��.[action=%s]", a.getName()));
		}
	}

	private void exacuteAction(MAction ac) throws Exception {
		Boolean doSuccess = false;
		String operation = ac.getTYPE().trim();
		if (operation == null) {
			throw new LoyaltyActionException("ִ�ж���:" + "operation is null.");
		}

		if (LoyaltyConstants.ACTION_ACTIONTYPE_M_ASSIGNPOINTS
				.equalsIgnoreCase(operation)) {
			// �ͷַ���
			doSuccess = ((MemberAct) ObjectUtil.getAction(MemberAct.class))
					.addBasicPoints(ac, ctx);

		} else if (LoyaltyConstants.ACTION_ACTIONTYPE_M_REDEEMPOINTS
				.equalsIgnoreCase(operation)) {
			// �۷ַ���
			doSuccess = ((ReclaimDealAct) ObjectUtil
					.getAction(ReclaimDealAct.class)).reclaim(ac, ctx);

		} else if (LoyaltyConstants.ACTION_ACTIONTYPE_M_DEGRADE
				.equalsIgnoreCase(operation)
				|| LoyaltyConstants.ACTION_ACTIONTYPE_M_UPGRADE
						.equalsIgnoreCase(operation)) {
			doSuccess = ((MemberAct) ObjectUtil.getAction(MemberAct.class))
					.adjustTier(ac, ctx);

		} else if (LoyaltyConstants.ACTION_ACTIONTYPE_M_QUALIFYMEMBER
				.equalsIgnoreCase(operation)) {
			doSuccess = ((MemberAct) ObjectUtil.getAction(MemberAct.class))
					.isMember(ac, ctx);

		} else if (LoyaltyConstants.ACTION_ACTIONTYPE_M_UPDATEATTR
				.equalsIgnoreCase(operation)) {
			doSuccess = ((AttributeReviseAct) ObjectUtil
					.getAction(AttributeReviseAct.class)).revise(ac, ctx);

		} else if (LoyaltyConstants.ACTION_ACTIONTYPE_M_RENEWAL
				.equalsIgnoreCase(operation)) {
			doSuccess = ((RenewalAct) ObjectUtil.getAction(RenewalAct.class))
					.refreshTier(ac, ctx);
		} else if (LoyaltyConstants.ACTION_ACTIONTYPE_M_QUIT
				.equalsIgnoreCase(operation)) {
			doSuccess = ((QuitClubAct) ObjectUtil.getAction(QuitClubAct.class))
					.quit(ctx);
		}

		if (!doSuccess) {
			throw new LoyaltyActionException("ִ�ж���:" + ObjectUtil.toString(ac));
		}
	}

	private void exacuteCustAction(MCustAction cac) throws Exception {
		Boolean doSuccess = false;
		doSuccess = ((CustomizationAct) ObjectUtil
				.getAction(CustomizationAct.class)).toCustomization(cac, ctx);
		if (!doSuccess) {
			throw new LoyaltyActionException("ִ�д洢����:"
					+ ObjectUtil.toString(cac));
		}
	}

	private List<Object> sort(List<?> actions, List custActions) {
		List<Object> all = new ArrayList();
		all.addAll(actions);
		all.addAll(custActions);
		Collections.sort(all, new Comparator<Object>() {
			public int compare(Object arg0, Object arg1) {
				Integer arg0_int = arg0 instanceof MAction ? ((MAction) arg0)
						.getSERIAL_NUM() : ((MCustAction) arg0).getSERIAL_NUM();
				Integer arg1_int = arg1 instanceof MAction ? ((MAction) arg1)
						.getSERIAL_NUM() : ((MCustAction) arg1).getSERIAL_NUM();
				if (null == arg0_int || null == arg1_int) {
					return 0;
				}
				if (arg0_int > arg1_int)
					return 1;

				if (arg0_int < arg1_int)
					return -1;

				if (arg0_int == arg1_int) {
					return 0;
				}
				return 0;
			}
		});
		return all;
	}
}
