package com.loyalty.core;

import java.util.List;

import org.apache.log4j.Logger;

import com.loyalty.bean.CriteriaInfo;
import com.loyalty.bean.PromotionInfo;
import com.loyalty.bean.RuleInfo;
import com.loyalty.bean.TierInfo;
import com.loyalty.dto.MCustCriteria;
import com.loyalty.dto.MLoyOrderItem;
import com.loyalty.util.LoyaltyConstants;
import com.ruixue.rfw.util.LogUtil;

public class FluentTimlyImpl {
	
	private static final Logger logger = LogUtil.getLogger();
	
	private LoyaltyContext ctx;
	private PromotionInfo prom;
	
	public FluentTimlyImpl() {}
	
	public void init(PromotionInfo promotion, ActionObject obj) {
		this.prom = promotion;
		this.ctx = obj.getEnv();
		ctx.setPromotionId(this.prom.getId());
//add start 2014/05/16 xuning
		ctx.setPromotionType(this.prom.getType());
//add end 2014/05/16 xuning
		ctx.setPromotion(this.prom);
	}

	private boolean isValid() {
		if (ctx.getCtxDate() == null) return false;
		
		if (prom.getStartDt() != null && prom.getStartDt().after(ctx.getCtxDate())) {
			return false;
		}
		
		if (prom.getEndDt() != null && prom.getEndDt().before(ctx.getCtxDate())) {
			return false;
		}
		
		return true;
	}

	private boolean judgeProduct(String product) {
		String productType = this.prom.getProductMode();

		if (LoyaltyConstants.PROMOTION_ALLPRODUCT.equals(productType)) {
			return true;
		} else if (LoyaltyConstants.PROMOTION_INCLUDEPRODUCT
				.equals(productType)) {
			PromotionService db = PromotionService.getInstance();
			List<String> lst = db.getIncludeProductList(this.prom.getId());
			if (lst.contains(product)) {
				return true;
			}
		} else if (LoyaltyConstants.PROMOTION_EXCLUDEPRODUCT
				.equals(productType)) {
			PromotionService db = PromotionService.getInstance();
			List<String> lst = db.getIncludeProductList(this.prom.getId());
			if (!lst.contains(product)) {
				return true;
			}
		}
		return false;
	}

	private boolean judgeTier() {
		
		if (LoyaltyConstants.PROMOTION_ALLTIER.equals(this.prom.getTierMode())) {
			
			return true;
		} else {
			
			if (ctx.getMember().getTiers().isEmpty()) return false;
			
			if (this.prom.getTiers().isEmpty()) return false;
			
			if (LoyaltyConstants.PROMOTION_INCLUDETIER.equals(this.prom.getTierMode())) {
				
				for (TierInfo mt : ctx.getMember().getTiers()) {
					if (this.prom.getTiers().contains(mt.getId())) return true;
				}
				
			} else if (LoyaltyConstants.PROMOTION_EXCLUDETIER.equals(this.prom.getTierMode())) {

				for (TierInfo mt : ctx.getMember().getTiers()) {
					if (this.prom.getTiers().contains(mt.getId())) return false;
				}
				return true;
			}
		}
		return false;
	}

	private boolean decideCriteria(CriteriaInfo c) {
		Criteria criteria = new FluentCriteriaImpl(c, ctx);
		return criteria.checkCriteria();
	}

	private boolean decideCriteria(MCustCriteria custCr) {
		CustCriteriaImpl impl = new CustCriteriaImpl(custCr, ctx);
		return impl.checkCriteria();
	}

	private void runActions(RuleInfo rule) throws Exception {
		
		//ctx.setRuleId(rule.getId());
		Action run = new Action(ctx);
		run.onAction(rule);
	}

	private boolean isMemberActivity() {

		return judgeTier();
	}

	private boolean isOrderItemActivity() {
		boolean blnOk = isOrderActivity();
		if (blnOk) {
			String product = ctx.getProductId();
			if (product == null || product.length() == 0)
				return false;
			else {
				if (judgeProduct(product))
					return true;
				else
					return false;
			}
		} else
			return false;
	}

	private boolean isOrderActivity() {
		if (ctx.getMember() == null) {
			return LoyaltyConstants.PROMOTION_TYPE_QUALIFY.equals(this.prom.getType());
		}
		return judgeTier();
	}

	public Boolean isOrderActivityByProductAndTier() {

		if (ctx.getMember() == null) {
			return LoyaltyConstants.PROMOTION_TYPE_QUALIFY.equals(this.prom.getType());
		}
		
		Boolean isTierInclude = judgeTier();
		String orderId = ctx.getOrderId();
		PromotionService db = PromotionService.getInstance();
		List<MLoyOrderItem> loyOrderItems = db.getOrderItem(orderId);
		Boolean isProductInclude = false;
		String productType = this.prom.getProductMode();
		if (LoyaltyConstants.PROMOTION_ALLPRODUCT.equals(productType)) {
			isProductInclude = true;
		}
		if (!isProductInclude) {
			for (MLoyOrderItem item : loyOrderItems) {
				String product = item.getPRODUCT_ID();
				isProductInclude = judgeProduct(product);
				if (isProductInclude) {
					break;
				}
			}
		}
		return isTierInclude && isProductInclude;
	}

	private boolean isActivity() {
		if (LoyaltyConstants.ACTIONOBJECT_ORDER.equals(ctx.getObjType())) {
			return isOrderActivityByProductAndTier();
		} else if (LoyaltyConstants.ACTIONOBJECT_ITEM.equals(ctx.getObjType())) {
			return isOrderItemActivity();
		} else {
			return isMemberActivity();
		}
	}

	public boolean run() throws Exception {
		boolean blnOk = false;
		try {
			logger.info("��������  ���� ��" + this.prom.getName() + "�� ��ʼʵʩ  ��������");
			if (!isValid()) {
				logger.error("!!!! ��ǰ�����Ѿ�ʧЧ.");
				return blnOk;
			}
			if (!isActivity()) {
				logger.error("!!!! ��ǰ���򼯻�û�м���.");
				return blnOk;
			}
			
			logger.info(">>>> ��ȡ���������й���.");
			PromotionService db = PromotionService.getInstance();
			List<RuleInfo> rules = db.selectRulesAllByPromotion(this.prom.getId());
			
			logger.info(">>>> ��ÿ������ִ���жϣ���ȡ����ִ�������Ĺ���.");
			OUT:for (RuleInfo r : rules) {
				for (CriteriaInfo c : r.getCriterias()) {
					if (!c.isActivity()) {
						logger.debug("�� �ж�������Ч");
						continue;
					}
					if (!decideCriteria(c)) {
						logger.debug("�� �ж� --> �����Ϲ�������");
						continue OUT;
					}
					logger.debug("�� �ж� --> ���Ϲ�������");
				}
				
				List<MCustCriteria> lstCustCr = db.selectCustCriteriaByRule(r.getId());
				if (lstCustCr != null && !lstCustCr.isEmpty()) {
					for (MCustCriteria cc : lstCustCr) {
						if (!decideCriteria(cc)) {
							logger.debug("�� �ж� --> �����Ϲ�������");
							continue OUT;
						}
						logger.debug("�� �ж� --> ���Ϲ�������");
					}
				}
				
				logger.info(">>>> ���� ��" + r.getName() + "�� ����ִ������.");
	
				runActions(r);
				blnOk = true;
			}
		} finally {
			logger.info("��������  ���� ��" + this.prom.getName() + "�� ʵʩ���  ��������");
		}
		return blnOk;
	}
}
