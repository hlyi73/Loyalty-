package com.loyalty.core;

/**
* @ClassName: Attribute
* @Description: �������ԵĽӿ�
* @author 
* @date Oct 9, 2009 4:44:12 PM
* 
*/
public interface Attribute {
    
	public Object getAttributes();
}
