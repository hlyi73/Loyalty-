package com.loyalty.core;

public interface RuleQueue{

	Iterable<Rule> list(String programId, String promotionId);
	void updateFromDb(String programId, String promotionId);
}
