package com.loyalty.core;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.loyalty.bean.MemberInfo;
import com.loyalty.bean.OrderInfo;
import com.loyalty.bean.OrganizationInfo;
import com.loyalty.bean.PromotionInfo;
import com.loyalty.bean.RuleInfo;
import com.loyalty.dao.FluentPromotionDAO;
import com.loyalty.dao.LoyaltyCriteriaDAO;
import com.loyalty.dao.MAttributesDAO;
import com.loyalty.dao.MCustomerDAO;
import com.loyalty.dao.MLoyOrderDAO;
import com.loyalty.dao.MLoyProgramDAO;
import com.loyalty.dao.MMemberDAO;
import com.loyalty.dao.MOrderDetailDAO;
import com.loyalty.dao.MSqlDAO;
import com.loyalty.dao.MTierDAO;
import com.loyalty.dao.TaskCommonDAO;
import com.loyalty.dto.MAttributes;
import com.loyalty.dto.MCriteria;
import com.loyalty.dto.MCustCriteria;
import com.loyalty.dto.MCustomer;
import com.loyalty.dto.MExclusiveCondition;
import com.loyalty.dto.MIncludeProduct;
import com.loyalty.dto.MIncludeTier;
import com.loyalty.dto.MLoyOrder;
import com.loyalty.dto.MLoyOrderItem;
import com.loyalty.dto.MLoyProgram;
import com.loyalty.dto.MMember;
import com.loyalty.dto.MMemberTier;
import com.loyalty.dto.MOrderDetail;
import com.loyalty.dto.MPromotion;
import com.loyalty.dto.MRule;
import com.loyalty.dto.MTier;
import com.loyalty.dto.MValueList;
import com.loyalty.system.DAOConfig;
import com.loyalty.util.DAOUtil;

/**
 * @ClassName: PromotionService
 * @Description: ���ݿ���ʺ����ļ���
 * @author
 * @date Oct 9, 2009 4:28:05 PM
 * 
 */
public class PromotionService {

	private static PromotionService ps = null;
	private final static Object key = new Object();
	private TaskCommonDAO taskDao = null;

	/**
	 * <p>
	 * Title: PromotionService
	 * </p>
	 * <p>
	 * Description: ������
	 * </p>
	 */
	private PromotionService() {
		taskDao = DAOUtil.getDao(TaskCommonDAO.class);
	}

	/**
	 * @Title: getInstance
	 * @Description: �õ�ʵ��
	 * @param
	 * @return
	 * @return PromotionService
	 * @throws
	 */
	public static PromotionService getInstance() {
		if (ps == null) {
			synchronized (key) {
				if (null == ps) {
					ps = new PromotionService();
				}
			}
		}
		return ps;
	}

	/**
	 * @Title: getTier
	 * @Description: ȡ�õȼ�
	 * @param
	 * @param TierId
	 * @param
	 * @return
	 * @return MTier
	 * @throws
	 */
	public MTier getTier(String TierId) {
		MTierDAO dao = (MTierDAO) DAOConfig.getDaoManager().getDao(
				MTierDAO.class);
		return dao.selectByPrimaryKey(TierId);
	}

	/**
	 * @Title: getOrder
	 * @Description: ���ݶ����ţ��õ�����
	 * @param
	 * @param orderId
	 * @param
	 * @return
	 * @return MLoyOrder
	 * @throws
	 */
	public MLoyOrder getOrder(String orderId) {
		MLoyOrderDAO dao = (MLoyOrderDAO) DAOConfig.getDaoManager().getDao(
				MLoyOrderDAO.class);
		return dao.selectByPrimaryKey(orderId);
	}

	/**
	 * @Title: getProgram
	 * @Description: ������Ŀ�ţ��õ���Ŀ����
	 * @param
	 * @param programId
	 * @param
	 * @return
	 * @return MLoyProgram
	 * @throws
	 */
	public MLoyProgram getProgram(String programId) {
		// ��Ŀ�Ĵ�����
		MLoyProgramDAO dao = (MLoyProgramDAO) DAOConfig.getDaoManager().getDao(
				MLoyProgramDAO.class);
		return dao.selectByPrimaryKey(programId);

	}

	/**
	 * @Title: getMember
	 * @Description: �����û��ţ��õ��û�
	 * @param
	 * @param MemberId
	 * @param
	 * @return
	 * @return MMember
	 * @throws
	 */
	public MMember getMember(String MemberId) {

		MMemberDAO dao = (MMemberDAO) DAOConfig.getDaoManager().getDao(
				MMemberDAO.class);
		return dao.selectByPrimaryKey(MemberId);
	}

	/**
	 * @Title: getPromotion
	 * @Description: �����������õ������promotion
	 * @param
	 * @param source
	 * @param
	 * @param type
	 * @param
	 * @param status
	 * @param
	 * @param PROGRAM_ID
	 * @param
	 * @return
	 * @return List<MPromotion>
	 * @throws
	 */
	public List<MPromotion> getPromotion(String source, String type,
			Integer status, String PROGRAM_ID) {
		LoyaltyCriteriaDAO dao = (LoyaltyCriteriaDAO) DAOConfig.getDaoManager()
				.getDao(LoyaltyCriteriaDAO.class);
		return dao.selectPromotion(source, type, status, PROGRAM_ID);

	}

	/**
	 * @Title: getOrderItem
	 * @Description: ���ݶ�����ϸid,ȡ�ö�����ϸ
	 * @param
	 * @param orderId
	 * @param
	 * @return
	 * @return List<MLoyOrderItem>
	 * @throws
	 */
	public List<MLoyOrderItem> getOrderItem(String orderId) {
		LoyaltyCriteriaDAO dao = (LoyaltyCriteriaDAO) DAOConfig.getDaoManager()
				.getDao(LoyaltyCriteriaDAO.class);
		return dao.selectOrderItem(orderId);
	}

	/**
	 * @Title: selectTierByMember
	 * @Description: ȡ��promotion�������û��ȼ�
	 * @param
	 * @param memberId
	 * @param
	 * @param status
	 * @param
	 * @return
	 * @return List<MMemberTier>
	 * @throws
	 */
	public List<MMemberTier> selectTierByMember(String memberId, Integer status) {
		LoyaltyCriteriaDAO dao = (LoyaltyCriteriaDAO) DAOConfig.getDaoManager()
				.getDao(LoyaltyCriteriaDAO.class);
		return dao.selectTierByMember(memberId, status);
	}

	/**
	 * @Title: selectIncludeTierByPromotion
	 * @Description: ȡ��promotion�������û��ȼ�
	 * @param
	 * @param PROMOTION_ID
	 * @param
	 * @return
	 * @return List<MIncludeTier>
	 * @throws
	 */
	public List<MIncludeTier> selectIncludeTierByPromotion(String PROMOTION_ID) {
		LoyaltyCriteriaDAO dao = (LoyaltyCriteriaDAO) DAOConfig.getDaoManager()
				.getDao(LoyaltyCriteriaDAO.class);
		return dao.selectIncludeTierByPromotion(PROMOTION_ID);
	}

	/**
	 * @Title: getIncludeTierList
	 * @Description: ȡ��promotion�������û��ȼ�
	 * @param
	 * @param PROMOTION_ID
	 * @param
	 * @return
	 * @return List<String>
	 * @throws
	 */
	public List<String> getIncludeTierList(String PROMOTION_ID) {
		List<String> lst = new ArrayList<String>();
		List<MIncludeTier> lstTier = selectIncludeTierByPromotion(PROMOTION_ID);
		for (int i = 0; lstTier != null && i < lstTier.size(); i++) {
			lst.add(lstTier.get(i).getTIER_ID());
		}
		return lst;
	}

	/**
	 * @Title: selectIncludeProductByPromotion
	 * @Description: ȡ��promotion�Ĳ�Ʒ
	 * @param
	 * @param PROMOTION_ID
	 * @param
	 * @return
	 * @return List<MIncludeProduct>
	 * @throws
	 */
	public List<MIncludeProduct> selectIncludeProductByPromotion(
			String PROMOTION_ID) {
		LoyaltyCriteriaDAO dao = (LoyaltyCriteriaDAO) DAOConfig.getDaoManager()
				.getDao(LoyaltyCriteriaDAO.class);
		return dao.selectIncludeProductByPromotion(PROMOTION_ID);
	}

	/**
	 * @Title: getIncludeProductList
	 * @Description: ȡ��promotion�Ĳ�Ʒ
	 * @param
	 * @param PROMOTION_ID
	 * @param
	 * @return
	 * @return List<String>
	 * @throwsl
	 */
	public List<String> getIncludeProductList(String PROMOTION_ID) {
		List<String> lst = new ArrayList<String>();
		List<MIncludeProduct> lstProduct = selectIncludeProductByPromotion(PROMOTION_ID);
		for (int i = 0; lstProduct != null && i < lstProduct.size(); i++) {
			lst.add(lstProduct.get(i).getPRODUCT_ID());
		}
		return lst;
	}

	/**
	 * @Title: selectRuleByPromotion
	 * @Description: ȡ��promotion�µĹ���
	 * @param
	 * @param PROMOTION_ID
	 * @param
	 * @return
	 * @return List<MRule>
	 * @throws
	 */
	public List<MRule> selectRuleByPromotion(String PROMOTION_ID) {
		LoyaltyCriteriaDAO dao = (LoyaltyCriteriaDAO) DAOConfig.getDaoManager()
				.getDao(LoyaltyCriteriaDAO.class);
		return dao.selectRuleByPromotion(PROMOTION_ID);
	}

	/**
	 * @Title: selectCriteriaByRule
	 * @Description: ȡ�÷ǿͻ�������
	 * @param
	 * @param RULE_ID
	 * @param
	 * @return
	 * @return List<MCriteria>
	 * @throws
	 */
	public List<MCriteria> selectCriteriaByRule(String RULE_ID) {
		LoyaltyCriteriaDAO dao = (LoyaltyCriteriaDAO) DAOConfig.getDaoManager()
				.getDao(LoyaltyCriteriaDAO.class);
		return dao.selectCriteriaByRule(RULE_ID);
	}

	/**
	 * @Title: selectCustCriteriaByRule
	 * @Description: ȡ�ÿͻ�������
	 * @param
	 * @param RuleId
	 * @param
	 * @return
	 * @return List<MCustCriteria>
	 * @throws
	 */
	public List<MCustCriteria> selectCustCriteriaByRule(String RuleId) {
		LoyaltyCriteriaDAO dao = (LoyaltyCriteriaDAO) DAOConfig.getDaoManager()
				.getDao(LoyaltyCriteriaDAO.class);
		return dao.selectCustCriteriaByRule(RuleId);
	}

	/**
	 * @Title: selectForDate
	 * @Description: ���ݾ����sql,ȡ��һ��Date
	 * @param
	 * @param sql
	 * @param
	 * @return
	 * @return Map<String,Date>
	 * @throws
	 */
	public Map<String, Date> selectForDate(String sql) {
		MSqlDAO dao = (MSqlDAO) DAOConfig.getDaoManager().getDao(MSqlDAO.class);
		HashMap<String, Date> record = (HashMap<String, Date>) dao
				.selectForDate(sql);
		return record;
	}

	/**
	 * @Title: selectForInteger
	 * @Description: ���ݾ����sql,ȡ��һ��integerֵ
	 * @param
	 * @param sql
	 * @param
	 * @return
	 * @return Map<String,Integer>
	 * @throws
	 */
	public Map<String, Integer> selectForInteger(String sql) {
		MSqlDAO dao = (MSqlDAO) DAOConfig.getDaoManager().getDao(MSqlDAO.class);
		HashMap<String, Integer> record = (HashMap<String, Integer>) dao
				.selectForInteger(sql);
		return record;
	}

	/**
	 * @Title: selectForDouble
	 * @Description: ���ݾ����sql,ȡ��һ��doubleֵ
	 * @param
	 * @param sql
	 * @param
	 * @return
	 * @return Map<String,Double>
	 * @throws
	 */
	public Map<String, Double> selectForDouble(String sql) {
		MSqlDAO dao = (MSqlDAO) DAOConfig.getDaoManager().getDao(MSqlDAO.class);
		HashMap<String, Double> record = (HashMap<String, Double>) dao
				.selectForDouble(sql);
		return record;
	}

	/**
	 * @Title: selectForString
	 * @Description: ���ݾ����sql,ȡ��һ���ִ�
	 * @param
	 * @param sql
	 * @param
	 * @return
	 * @return Map<String,String>
	 * @throws
	 */
	public Map<String, String> selectForString(String sql) {
		MSqlDAO dao = (MSqlDAO) DAOConfig.getDaoManager().getDao(MSqlDAO.class);
		HashMap<String, String> record = (HashMap<String, String>) dao
				.selectForString(sql);
		return record;
	}

	/**
	 * @Title: getCustomer
	 * @Description: ���ݿͻ�id,ȡ�ÿͻ�
	 * @param
	 * @param customId
	 * @param
	 * @return
	 * @return MCustomer
	 * @throws
	 */
	public MCustomer getCustomer(String customId) {
		MCustomerDAO dao = (MCustomerDAO) DAOConfig.getDaoManager().getDao(
				MCustomerDAO.class);
		MCustomer record = dao.selectByPrimaryKey(customId);
		return record;
	}

	/**
	 * @Title: getMAttributes
	 * @Description: ��������id,ȡ������
	 * @param
	 * @param attr_id
	 * @param
	 * @return
	 * @return MAttributes
	 * @throws
	 */
	public MAttributes getMAttributes(String attr_id) {
		MAttributesDAO dao = (MAttributesDAO) DAOConfig.getDaoManager().getDao(
				MAttributesDAO.class);
		MAttributes record = dao.selectByPrimaryKey(attr_id);
		return record;
	}

	/**
	 * @Title: selectValuebyCriteria
	 * @Description: ȡ��������ֵ
	 * @param
	 * @param ID
	 * @param
	 * @return
	 * @return List<MValueList>
	 * @throws
	 */
	public List<MValueList> selectValuebyCriteria(String ID) {
		LoyaltyCriteriaDAO dao = (LoyaltyCriteriaDAO) DAOConfig.getDaoManager()
				.getDao(LoyaltyCriteriaDAO.class);
		List<MValueList> record = (List<MValueList>) dao
				.selectValuebyCriteria(ID);
		return record;
	}

	/**
	 * @Title: selectMExclusivebyProgram
	 * @Description: ȡ�û���
	 * @param
	 * @param programId
	 * @param
	 * @return
	 * @return List<String>
	 * @throws
	 */
	public List<String> selectMExclusivebyProgram(String programId) {
		LoyaltyCriteriaDAO dao = (LoyaltyCriteriaDAO) DAOConfig.getDaoManager()
				.getDao(LoyaltyCriteriaDAO.class);
		List<String> record = (List<String>) dao
				.selectExclusiveByProgram(programId);
		return record;
	}

	/**
	 * @Title: selectMExclusiveConditionByME
	 * @Description: ȡ�û�������
	 * @param
	 * @param EXCLUSIVE_ID
	 * @param
	 * @return
	 * @return List<MExclusiveCondition>
	 * @throws
	 */
	public List<MExclusiveCondition> selectMExclusiveConditionByME(
			String EXCLUSIVE_ID) {
		LoyaltyCriteriaDAO dao = (LoyaltyCriteriaDAO) DAOConfig.getDaoManager()
				.getDao(LoyaltyCriteriaDAO.class);
		List<MExclusiveCondition> record = (List<MExclusiveCondition>) dao
				.selectMExclusiveConditionByME(EXCLUSIVE_ID);
		return record;
	}

	/**
	 * @Title: selectPromotionbyMExclusive
	 * @Description: ȡ����Ŀ��promotion
	 * @param
	 * @param PROGRAM_ID
	 * @param
	 * @param EXCLUSIVE_ID
	 * @param
	 * @param CONDITION_TYPE
	 * @param
	 * @return
	 * @return List<String>
	 * @throws
	 */
	public List<String> selectPromotionbyMExclusive(String PROGRAM_ID,
			String EXCLUSIVE_ID, String CONDITION_TYPE) {
		LoyaltyCriteriaDAO dao = (LoyaltyCriteriaDAO) DAOConfig.getDaoManager()
				.getDao(LoyaltyCriteriaDAO.class);
		List<String> record = (List<String>) dao.selectPromotionbyMExclusive(
				PROGRAM_ID, EXCLUSIVE_ID, CONDITION_TYPE);
		return record;
	}

	/**
	 * @Title: selectMMaxvalueByProgram
	 * @Description:ȡ�ö�����promotion���ֵ
	 * @param
	 * @param PROGRAM_ID
	 * @param
	 * @param Order_ID
	 * @param
	 * @return
	 * @return List<Map<String,String>>
	 * @throws
	 */
	public List<Map<String, String>> selectMMaxvalueByProgram(
			String PROGRAM_ID, String Order_ID) {
		LoyaltyCriteriaDAO dao = (LoyaltyCriteriaDAO) DAOConfig.getDaoManager()
				.getDao(LoyaltyCriteriaDAO.class);
		List<Map<String, String>> record = (List<Map<String, String>>) dao
				.selectMMaxvalueByProgram(PROGRAM_ID, Order_ID);
		return record;
	}

	/**
	 * @Title: updateMorderDetailStatus
	 * @Description: ���¶���������ϸ��״̬
	 * @param
	 * @param id
	 * @param
	 * @param status
	 * @param
	 * @return
	 * @return int
	 * @throws
	 */
	public int updateMorderDetailStatus(String id, String status) {
		MOrderDetailDAO dao = (MOrderDetailDAO) DAOConfig.getDaoManager()
				.getDao(MOrderDetailDAO.class);
		MOrderDetail orderDetail = dao.selectByPrimaryKey(id);
		orderDetail.setSTATUS(status);
		return dao.updateByPrimaryKey(orderDetail);
	}

	/**
	 * @Title: callMCustCriteria
	 * @Description: ִ�пͻ�������
	 * @param
	 * @param procedureName
	 * @param
	 * @param memberId
	 * @param
	 * @return
	 * @return int
	 * @throws
	 */
	public int callMCustCriteria(String procedureName, String memberId,
			String orderId) {
		MSqlDAO dao = (MSqlDAO) DAOConfig.getDaoManager().getDao(MSqlDAO.class);
		return dao.callMCustCriteria(procedureName, memberId, orderId);
	}

	/**
	 * @Title: getCustomizeAttr_Integer
	 * @Description: TODO
	 * @param
	 * @param procedureName
	 * @param
	 * @param memberId
	 * @param
	 * @param orderId
	 * @param
	 * @return
	 * @return Integer
	 * @throws
	 */
	public Integer getCustomizeAttr_Integer(String procedureName,
			String memberId, String orderId) {
		MSqlDAO dao = (MSqlDAO) DAOConfig.getDaoManager().getDao(MSqlDAO.class);
		return dao.getCustomizeAttr_Integer(procedureName, memberId, orderId);
	}

	/**
	 * @Title: getCustomizeAttr_Double
	 * @Description: TODO
	 * @param
	 * @param procedureName
	 * @param
	 * @param memberId
	 * @param
	 * @param orderId
	 * @param
	 * @return
	 * @return Double
	 * @throws
	 */
	public Double getCustomizeAttr_Double(String procedureName,
			String memberId, String orderId) {
		MSqlDAO dao = (MSqlDAO) DAOConfig.getDaoManager().getDao(MSqlDAO.class);
		return dao.getCustomizeAttr_Double(procedureName, memberId, orderId);
	}

	/**
	 * @Title: getCustomizeAttr_String
	 * @Description: TODO
	 * @param
	 * @param procedureName
	 * @param
	 * @param memberId
	 * @param
	 * @param orderId
	 * @param
	 * @return
	 * @return String
	 * @throws
	 */
	public String getCustomizeAttr_String(String procedureName,
			String memberId, String orderId) {
		MSqlDAO dao = (MSqlDAO) DAOConfig.getDaoManager().getDao(MSqlDAO.class);
		return dao.getCustomizeAttr_String(procedureName, memberId, orderId);
	}

	/**
	 * @Title: getCustomizeAttr_Date
	 * @Description: TODO
	 * @param
	 * @param procedureName
	 * @param
	 * @param memberId
	 * @param
	 * @param orderId
	 * @param
	 * @return
	 * @return Date
	 * @throws
	 */
	public Date getCustomizeAttr_Date(String procedureName, String memberId,
			String orderId) {
		MSqlDAO dao = (MSqlDAO) DAOConfig.getDaoManager().getDao(MSqlDAO.class);
		return dao.getCustomizeAttr_Date(procedureName, memberId, orderId);
	}

	/**
	 * @Title: updateOrderStatus
	 * @Description: ���¶����Ĵ���״̬
	 * @param
	 * @param id
	 * @param
	 * @param status
	 * @param
	 * @return
	 * @return int
	 * @throws
	 */
	public int updateOrderStatus(MLoyOrder order, String status) {
		MLoyOrderDAO dao = (MLoyOrderDAO) DAOConfig.getDaoManager().getDao(
				MLoyOrderDAO.class);
		order.setSTATUS(status);
		return dao.updateByPrimaryKey(order);
	}

	// 20140515 SQL�Ż� liuhui
	/**
	 * @Title: getMember
	 * @Description: �����û��ţ��õ��û���ϸ��Ϣ
	 * @param
	 * @param MemberId
	 * @param
	 * @return
	 * @return MMember
	 * @throws
	 */
	public MemberInfo getMemberDetail(String MemberId) {

		FluentPromotionDAO dao = (FluentPromotionDAO) DAOConfig.getDaoManager().getDao(
			FluentPromotionDAO.class);
		return dao.selectMemberInfoByPrimaryKey(MemberId);
	}
	
	/**
	 * @Title: selectRuleByPromotion
	 * @Description: ȡ��promotion�µĹ���
	 * @param
	 * @param PROMOTION_ID
	 * @param
	 * @return
	 * @return List<MRule>
	 * @throws
	 */
	public List<RuleInfo> selectRulesAllByPromotion(String id) {
		FluentPromotionDAO dao = (FluentPromotionDAO) DAOConfig.getDaoManager()
				.getDao(FluentPromotionDAO.class);
		return dao.selectRulesByPromotion(id);
	}
	
	/**
	 * @Title: getPromotion
	 * @Description: �����������õ������promotion
	 * 
	 * @param programId
	 * @return List<MPromotion>
	 * @throws
	 */
	public List<PromotionInfo> getActivityPromotions(String programId, String source) {
		FluentPromotionDAO dao = (FluentPromotionDAO) DAOConfig.getDaoManager()
				.getDao(FluentPromotionDAO.class);
		return dao.selectPromsByProgramId(programId, source);

	}
	
	/**
	 * @Title: getPromotion
	 * @Description: �����������õ������promotion
	 * 
	 * @param programId
	 * @return List<MPromotion>
	 * @throws
	 */
	public List<String> fetchCustomerGroupByTime() {
		FluentPromotionDAO dao = (FluentPromotionDAO) DAOConfig.getDaoManager()
				.getDao(FluentPromotionDAO.class);
		return dao.selectCustomerGroupByTime();

	}
	
	// 20140515 SQL�Ż� liuhui
	//add start 2014/05/19 hansheng
	// ���˺�ҵ�����
	public int updateMemberBindFlag(String MemberId) {

		FluentPromotionDAO dao = (FluentPromotionDAO) DAOConfig.getDaoManager().getDao(
			FluentPromotionDAO.class);
		return dao.updateMemberBindFlag(MemberId);
	}
	//add start 2014/05/19 hansheng
	
	public OrderInfo getOrderInfo(String orderId, String programId) {
		return taskDao.selectOrderInfoById(orderId, programId);
	}
	
	public OrganizationInfo getOrgInfoByProgram(String programId) {
		return taskDao.selectOrganizationInfoByProgram(programId);
	}
}
