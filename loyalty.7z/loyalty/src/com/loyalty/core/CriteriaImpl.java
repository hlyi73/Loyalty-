package com.loyalty.core;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.List;

import org.apache.log4j.Logger;

import com.loyalty.dto.MAttributes;
import com.loyalty.dto.MCriteria;
import com.loyalty.dto.MCustomer;
import com.loyalty.dto.MValueList;
import com.loyalty.util.DateUtil;
import com.loyalty.util.LoyaltyConstants;

/**
 * @ClassName: CriteriaImpl
 * @Description: �ǿͻ���������ʵ����
 * @author
 * @date Oct 9, 2009 5:00:08 PM
 * 
 */
public class CriteriaImpl implements Criteria {
	protected MCriteria cr;
	protected LoyaltyContext ctx;
	private String attrDataType;
	private String AttributeKey = "KEYVALUE";
	static Logger logger = Logger.getLogger(CriteriaImpl.class.getName());

	/**
	 * <p>
	 * Title:
	 * </p>
	 * <p>
	 * Description: ���캯��
	 * </p>
	 * 
	 * @param cr
	 *            ����
	 * @param context
	 *            �������ݻ���
	 */
	public CriteriaImpl(MCriteria cr, LoyaltyContext context) {
		this.cr = cr;
		this.ctx = context;
	}

	/**
	 * <p>
	 * Title:
	 * </p>
	 * <p>
	 * Description: ���캯��
	 * </p>
	 */
	public CriteriaImpl() {

	}

	/**
	 * @Title: getUseBorn
	 * @Description: �õ��ͻ��ĳ�������
	 * @param
	 * @param customId
	 * @param
	 * @return
	 * @return Date
	 * @throws
	 */
	private Date getUseBorn(String customId) {
		PromotionService db = PromotionService.getInstance();
		MCustomer customer = db.getCustomer(customId);
		return customer.getBIRTHDAY();

	}

	/**
	 * @Title: isMonth
	 * @Description: �ж������Ƿ����յ���
	 * @param
	 * @param bornDate
	 * @param
	 * @return
	 * @return boolean
	 * @throws
	 */
	private boolean isMonth(Date bornDate) {

		GregorianCalendar curr = new GregorianCalendar();
		GregorianCalendar born = new GregorianCalendar();
		born.setTime(bornDate);
		curr.setTime(ctx.getCtxDate());
		int currM = curr.get(Calendar.MONTH);
		int useM = born.get(Calendar.MONTH);
		if (currM == useM)
			return true;
		else
			return false;
	}

	/**
	 * @Title: isWeek
	 * @Description: �ж������Ƿ����յ���
	 * @param
	 * @param bornDate
	 * @param
	 * @return
	 * @return boolean
	 * @throws
	 */
	private boolean isWeek(Date bornDate) {

		GregorianCalendar curr = new GregorianCalendar();
		GregorianCalendar born = new GregorianCalendar();
		curr.setTime(ctx.getCtxDate());
		born.setTime(bornDate);
		born.set(curr.get(Calendar.YEAR), born.get(Calendar.MONTH), born
				.get(Calendar.DATE));
		int currW = curr.get(Calendar.WEEK_OF_YEAR);
		int useW = born.get(Calendar.WEEK_OF_YEAR);
		if (currW == useW)
			return true;
		else
			return false;
	}

	/**
	 * @Title: isDay
	 * @Description: �ж������Ƿ����յ���
	 * @param
	 * @param bornDate
	 * @param
	 * @return
	 * @return boolean
	 * @throws
	 */
	private boolean isDay(Date bornDate) {

		GregorianCalendar curr = new GregorianCalendar();
		GregorianCalendar born = new GregorianCalendar();
		born.setTime(bornDate);
		curr.setTime(ctx.getCtxDate());
		int currD = curr.get(Calendar.DATE);
		int useD = born.get(Calendar.DATE);
		if (currD == useD)
			return true;
		else
			return false;
	}

	/**
	 * @Title: compareAttr
	 * @Description: �Ƚ�����������
	 * @param
	 * @return
	 * @return boolean
	 * @throws
	 */
	private boolean compareAttr() {
		PromotionService db = PromotionService.getInstance();
		String attr_id = (String) cr.getATTR_ID();
		if (attr_id == null || attr_id.length() == 0) {
			return false;
		}
		MAttributes attr = db.getMAttributes(attr_id);
		if (!ctx.getProgramId().equals(attr.getPROGRAM_ID())) {
			return false;
		}
		if (attr == null) {
			return false;
		}
		if (attr.getDATA_TYPE() == null) {
			return false;
		}

		attrDataType = attr.getDATA_TYPE();
		Attribute att = new AttributeImpl(attr, ctx);
		Object attValue = att.getAttributes();

		if (attValue == null) {
			return false;
		}

		String attrCompareId = (String) cr.getCOMPARE_ATTR_ID();

		List<MValueList> list = (List<MValueList>) db.selectValuebyCriteria(cr
				.getID());

		if (attrCompareId == null || attrCompareId.length() == 0) {
			List<Object> attCompareValue = makeCompareValue(list);
			if (attCompareValue == null || attCompareValue.size() == 0)
				return false;
			else {
				return compare(attValue, attCompareValue, cr.getCOMPARE_COND(),
						attrDataType);
			}
		} else {

			MAttributes attrTo = db.getMAttributes(cr.getCOMPARE_ATTR_ID());
			if (attrTo == null)
				return false;
			if (!attrDataType.equals(attrTo.getDATA_TYPE()))
				return false;
			Attribute attTo = new AttributeImpl(attrTo, ctx);
			Object attValueTo = attTo.getAttributes();
			if (attValueTo == null)
				return false;

			String operate = (String) cr.getOPERATE();
			if (cr.getOPERATE() == null || cr.getOPERATE().length() == 0) {
				List<Object> lst = new ArrayList<Object>();
				lst.add(attValueTo);
				return compare(attValue, lst, cr.getCOMPARE_COND(),
						attrDataType);
			} else {
				if (list == null || list.size() == 0)
					return false;
				String value = (String) list.get(0).getCRITERIA_VALUE();
				attValueTo = getOperateResult(attValueTo, value, operate);
				if (attValueTo == null)
					return false;
				List<Object> lst = new ArrayList<Object>();
				lst.add(attValueTo);
				return compare(attValue, lst, cr.getCOMPARE_COND(),
						attrDataType);
			}
		}
	}

	/**
	 * @Title: getOperateResult
	 * @Description: ������ֵת��Ϊһ�����ԱȽϵĶ���
	 * @param
	 * @param value
	 * @param
	 * @param DataType
	 * @param
	 * @return
	 * @return Object
	 * @throws
	 */
	public Object getOperateResult(String value, String DataType) {
		if (LoyaltyConstants.ATTR_DATATYPE_INTEGER.equals(DataType)
				|| LoyaltyConstants.ATTR_DATATYPE_FLOAT.equals(DataType)) {
			return Double.valueOf(value);
		} else if (LoyaltyConstants.ATTR_DATATYPE_DATE.equals(DataType)) {
			Date date = DateUtil.parseStringToDate(value);

			return date;
		} else {
			return value;
		}
	}

	/**
	 * @Title: getOperateResult
	 * @Description: ������������õ�һ���Ƚ�ֵ
	 * @param
	 * @param objTo
	 * @param
	 * @param value
	 * @param
	 * @param operate
	 * @param
	 * @return
	 * @return Object
	 * @throws
	 */
	public Object getOperateResult(Object objTo, String value, String operate) {
		if (LoyaltyConstants.ATTR_DATATYPE_INTEGER.equals(attrDataType)
				|| LoyaltyConstants.ATTR_DATATYPE_FLOAT.equals(attrDataType)) {
			double lngCompareTo;
			double lngOperate;
			if (objTo instanceof Integer)
				lngCompareTo = ((Integer) objTo).doubleValue();
			else
				lngCompareTo = ((Double) objTo).doubleValue();
			lngOperate = Double.valueOf(value);
			if (LoyaltyConstants.CRITERIA_OPERATE_M_PLUS.equals(operate)) {
				return new Double(lngCompareTo + lngOperate);
			} else if (LoyaltyConstants.CRITERIA_OPERATE_M_SUBTRACT
					.equals(operate)) {
				return new Double(lngCompareTo - lngOperate);
			} else if (LoyaltyConstants.CRITERIA_OPERATE_M_MULTIPLE
					.equals(operate)) {
				return new Double(lngCompareTo * lngOperate);
			} else if (LoyaltyConstants.CRITERIA_OPERATE_M_DIVIDE
					.equals(operate)) {
				if (lngOperate == 0)
					return null;
				else
					return new Double(lngCompareTo / lngOperate);
			} else {
				return null;
			}
		} else if (LoyaltyConstants.ATTR_DATATYPE_DATE.equals(attrDataType)) {
			int inday;
			inday = Integer.valueOf(value);
			if (LoyaltyConstants.CRITERIA_OPERATE_M_PLUS.equals(operate)) {
				GregorianCalendar cCompareTo = new GregorianCalendar();
				cCompareTo.setTime((Date) objTo);
				cCompareTo.add(Calendar.DATE, inday);
				return cCompareTo.getTime();
			} else if (LoyaltyConstants.CRITERIA_OPERATE_M_SUBTRACT
					.equals(operate)) {
				GregorianCalendar cCompareTo = new GregorianCalendar();
				cCompareTo.setTime((Date) objTo);
				cCompareTo.add(Calendar.DATE, -1 * inday);
				return cCompareTo.getTime();
			} else if (LoyaltyConstants.CRITERIA_OPERATE_M_MULTIPLE
					.equals(operate)) {
				return null;
			} else if (LoyaltyConstants.CRITERIA_OPERATE_M_DIVIDE
					.equals(operate)) {

				return null;
			} else if (LoyaltyConstants.ATTR_DATATYPE_STRING
					.equals(attrDataType)) {
				return null;
			}
		}
		return null;
	}

	/**
	 * @Title: compare
	 * @Description: ���ݱȽ��������Ƚ�����ֵ
	 * @param
	 * @param objCompare
	 * @param
	 * @param objCompareTo
	 * @param
	 * @param compareCond
	 * @param
	 * @param dataType
	 * @param
	 * @return
	 * @return boolean
	 * @throws
	 */
	public boolean compare(Object objCompare, List<Object> objCompareTo,
			String compareCond, String dataType) {

		logger.info("����ֵ----" + objCompare);
		logger.info("�Ƚ�����----" + objCompareTo.toString());
		if (LoyaltyConstants.CRITERIA_EQUALS.equals(compareCond)) {
			if (LoyaltyConstants.ATTR_DATATYPE_INTEGER.equals(dataType)
					|| LoyaltyConstants.ATTR_DATATYPE_FLOAT.equals(dataType)) {
				double value;

				if (objCompare instanceof Integer)
					value = ((Integer) objCompare).doubleValue();
				else
					value = ((Double) objCompare).doubleValue();
				for (int i = 0; i < objCompareTo.size(); i++) {
					double curr;
					if (objCompareTo.get(i) instanceof Integer)
						curr = ((Integer) objCompareTo.get(i)).doubleValue();
					else
						curr = ((Double) objCompareTo.get(i)).doubleValue();
					if (value == curr)
						return true;
				}
			}

			else if (LoyaltyConstants.ATTR_DATATYPE_DATE.equals(dataType)) {
				Date value = (Date) objCompare;
				DateFormat format = new SimpleDateFormat("yyyy-MM-dd");
				String strValue = format.format(value);
				for (int i = 0; i < objCompareTo.size(); i++) {
					Date curr = ((Date) objCompareTo.get(i));
					String strCurr = format.format(curr);
					if (strValue.equals(strCurr))
						return true;
				}
			} else if (LoyaltyConstants.ATTR_DATATYPE_STRING.equals(dataType)) {
				String value = (String) objCompare;
				for (int i = 0; i < objCompareTo.size(); i++) {
					String curr = ((String) objCompareTo.get(i));
					if (value.equals(curr))
						return true;
				}
			} else {
				return false;
			}
		} else if (LoyaltyConstants.CRITERIA_NOTEQUAL.equals(compareCond)) {
			if (LoyaltyConstants.ATTR_DATATYPE_INTEGER.equals(dataType)
					|| LoyaltyConstants.ATTR_DATATYPE_FLOAT.equals(dataType)) {
				double value;
				if (objCompare instanceof Integer)
					value = ((Integer) objCompare).doubleValue();
				else
					value = ((Double) objCompare).doubleValue();
				boolean blnOk = true;
				for (int i = 0; i < objCompareTo.size(); i++) {
					double curr;
					if (objCompareTo.get(i) instanceof Integer)
						curr = ((Integer) objCompareTo.get(i)).doubleValue();
					else
						curr = ((Double) objCompareTo.get(i)).doubleValue();
					if (value == curr)
						blnOk = false;
				}
				if (blnOk)
					return true;
			} else if (LoyaltyConstants.ATTR_DATATYPE_DATE.equals(dataType)) {
				Date value = (Date) objCompare;
				DateFormat format = new SimpleDateFormat("yyyy-MM-dd");
				String strValue = format.format(value);
				boolean blnOk = true;
				for (int i = 0; i < objCompareTo.size(); i++) {
					Date curr = ((Date) objCompareTo.get(i));
					String strCurr = format.format(curr);
					if (strValue.equals(strCurr))
						blnOk = false;
				}
				if (blnOk)
					return true;
			} else if (LoyaltyConstants.ATTR_DATATYPE_STRING.equals(dataType)) {
				String value = (String) objCompare;
				boolean blnOk = true;
				for (int i = 0; i < objCompareTo.size(); i++) {
					String curr = ((String) objCompareTo.get(i));
					if (value.equals(curr))
						blnOk = false;
				}
				if (blnOk)
					return true;
			} else {
				return false;
			}
		} else if (LoyaltyConstants.CRITERIA_GREATER.equals(compareCond)) {
			if (LoyaltyConstants.ATTR_DATATYPE_INTEGER.equals(dataType)
					|| LoyaltyConstants.ATTR_DATATYPE_FLOAT.equals(dataType)) {
				double value;
				if (objCompare instanceof Integer)
					value = ((Integer) objCompare).doubleValue();
				else
					value = ((Double) objCompare).doubleValue();
				double curr;
				if (objCompareTo.get(0) instanceof Integer)
					curr = ((Integer) objCompareTo.get(0)).doubleValue();
				else
					curr = ((Double) objCompareTo.get(0)).doubleValue();
				if (value > curr)
					return true;
			}

			else if (LoyaltyConstants.ATTR_DATATYPE_DATE.equals(dataType)) {
				Date value = (Date) objCompare;
				Date curr = ((Date) objCompareTo.get(0));
				if (value.compareTo(curr) > 0)
					return true;
			} else if (LoyaltyConstants.ATTR_DATATYPE_STRING.equals(dataType)) {
				return false;
			} else {
				return false;
			}
		} else if (LoyaltyConstants.CRITERIA_GREATERANDEQUAL
				.equals(compareCond)) {
			if (LoyaltyConstants.ATTR_DATATYPE_INTEGER.equals(dataType)
					|| LoyaltyConstants.ATTR_DATATYPE_FLOAT.equals(dataType)) {
				double value;
				if (objCompare instanceof Integer)
					value = ((Integer) objCompare).doubleValue();
				else
					value = ((Double) objCompare).doubleValue();
				double curr;
				if (objCompareTo.get(0) instanceof Integer)
					curr = ((Integer) objCompareTo.get(0)).doubleValue();
				else
					curr = ((Double) objCompareTo.get(0)).doubleValue();
				if (value >= curr)
					return true;
			} else if (LoyaltyConstants.ATTR_DATATYPE_DATE.equals(dataType)) {
				Date value = (Date) objCompare;
				Date curr = ((Date) objCompareTo.get(0));
				if (value.compareTo(curr) >= 0)
					return true;
			} else if (LoyaltyConstants.ATTR_DATATYPE_STRING.equals(dataType)) {
				return false;
			} else {
				return false;
			}
		} else if (LoyaltyConstants.CRITERIA_LESS.equals(compareCond)) {
			if (LoyaltyConstants.ATTR_DATATYPE_INTEGER.equals(dataType)
					|| LoyaltyConstants.ATTR_DATATYPE_FLOAT.equals(dataType)) {
				double value;
				if (objCompare instanceof Integer)
					value = ((Integer) objCompare).doubleValue();
				else
					value = ((Double) objCompare).doubleValue();
				double curr;
				if (objCompareTo.get(0) instanceof Integer)
					curr = ((Integer) objCompareTo.get(0)).doubleValue();
				else
					curr = ((Double) objCompareTo.get(0)).doubleValue();
				if (value < curr)
					return true;
			}

			else if (LoyaltyConstants.ATTR_DATATYPE_DATE.equals(dataType)) {
				Date value = (Date) objCompare;
				Date curr = ((Date) objCompareTo.get(0));
				if (value.compareTo(curr) < 0)
					return true;
			} else if (LoyaltyConstants.ATTR_DATATYPE_STRING.equals(dataType)) {
				return false;
			} else {
				return false;
			}
		} else if (LoyaltyConstants.CRITERIA_LESSANDEQUAL.equals(compareCond)) {
			if (LoyaltyConstants.ATTR_DATATYPE_INTEGER.equals(dataType)
					|| LoyaltyConstants.ATTR_DATATYPE_FLOAT.equals(dataType)) {

				double value;
				if (objCompare instanceof Integer)
					value = ((Integer) objCompare).doubleValue();
				else
					value = ((Double) objCompare).doubleValue();
				double curr;
				if (objCompareTo.get(0) instanceof Integer)
					curr = ((Integer) objCompareTo.get(0)).doubleValue();
				else
					curr = ((Double) objCompareTo.get(0)).doubleValue();
				if (value <= curr)
					return true;
			}

			else if (LoyaltyConstants.ATTR_DATATYPE_DATE.equals(dataType)) {
				Date value = (Date) objCompare;
				Date curr = ((Date) objCompareTo.get(0));
				if (value.compareTo(curr) <= 0)
					return true;
			} else if (LoyaltyConstants.ATTR_DATATYPE_STRING.equals(dataType)) {
				return false;
			} else {
				return false;
			}
		} else {
			return false;
		}
		return false;
	}

	/**
	 * @Title: checkInclude
	 * @Description: ����������ʵ��
	 * @param
	 * @return
	 * @return boolean
	 * @throws
	 */
	private boolean checkInclude() {
		PromotionService db = PromotionService.getInstance();
		// ȡ�ñȽ�����

		MAttributes attrTo = db.getMAttributes(cr.getCOMPARE_ATTR_ID());
		if (attrTo == null)
			return false;
		String table = attrTo.getTABLE_NAME();
		String col = attrTo.getFIELD_NAME();
		// ȡ�ñȽ�ֵ
		List<MValueList> lst = (List<MValueList>) db.selectValuebyCriteria(cr
				.getID());
		if (lst == null || lst.size() == 0)
			return false;
		StringBuffer sbInclude = new StringBuffer();
		for (int i = 0; i < lst.size(); i++) {
			if (i == 0)
				sbInclude.append("'" + lst.get(i).getCRITERIA_VALUE() + "'");
			else
				sbInclude.append(",'" + lst.get(i).getCRITERIA_VALUE() + "'");
		}

		StringBuffer sb = new StringBuffer();
		sb.append(" Select ");
		sb.append(" count(*) " + AttributeKey);
		sb.append(" From ");
		sb.append(" " + LoyaltyConstants.DB_ORDER_TABLE + " B left join "
				+ table + " A");
		sb.append(" on");
		sb.append(" b." + LoyaltyConstants.DB_ORDER_PK + "=" + "A."
				+ LoyaltyConstants.DB_ORDER_FK);
		sb.append(" where B." + LoyaltyConstants.DB_ORDER_PK + "='"
				+ ctx.getOrderId() + "'");
		sb.append(" and A." + col + " in ( " + sbInclude.toString() + " )");

		// �������� Integer
		HashMap<String, Integer> map = (HashMap<String, Integer>) db
				.selectForInteger(sb.toString());
		if (map == null || map.size() == 0)
			return false;
		if ((Integer) map.get(AttributeKey).intValue() > 0)
			return true;
		else
			return false;
	}

	/**
	 * һ���ǿͻ�������
	 * 
	 * @return
	 */
	/*
	 * (non-Javadoc) <p>Title: checkCriteria</p> <p>Description: ����һ������</p>
	 * @return
	 * 
	 * @see com.loyalty.core.Criteria#checkCriteria()
	 */

	public boolean checkCriteria() {
		try {		
			String attr_id = (String) cr.getATTR_ID();
			// ����IdΪ�գ�
			if (attr_id == null || attr_id.length() == 0) {
				String compare_cond = (String) cr.getCOMPARE_COND();
				// ���յ��£�
				if (LoyaltyConstants.CRITERIA_BIRTHMONTH.equals(compare_cond)) {
					Date useBorn = getUseBorn(ctx.getCustomerId());
					return isMonth(useBorn);
				}
				// ���յ��ܣ�
				else if (LoyaltyConstants.CRITERIA_BIRTHWEEK
						.equals(compare_cond)) {
					Date useBorn = getUseBorn(ctx.getCustomerId());
					return isWeek(useBorn);
				}
				// ���յ��죿
				else if (LoyaltyConstants.CRITERIA_BIRTHDAY
						.equals(compare_cond)) {
					Date useBorn = getUseBorn(ctx.getCustomerId());
					return isDay(useBorn);
				} else if (LoyaltyConstants.CRITERIA_INCLUDECOUPON
						.equals(compare_cond)) {
					return checkInclude();
				} else {
					return false;
				}
			} else {
				return compareAttr();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return false;
	}

	/**
	 * @Title: makeCompareValue
	 * @Description: �õ�һ�����ԱȽϵ�����ֵ
	 * @param
	 * @param list
	 * @param
	 * @return
	 * @return List<Object>
	 * @throws
	 */
	private List<Object> makeCompareValue(List<MValueList> list) {
		List<Object> lstR = new ArrayList<Object>();
		for (int i = 0; list != null && i < list.size(); i++) {
			MValueList mValue = list.get(i);
			String crValue = (String) mValue.getCRITERIA_VALUE();
			if (LoyaltyConstants.ATTR_DATATYPE_INTEGER.equals(attrDataType)
					|| LoyaltyConstants.ATTR_DATATYPE_FLOAT
							.equals(attrDataType)) {

				if (crValue == null || crValue.length() == 0)
					return null;
				else
					lstR.add(Double.valueOf(crValue));
			} else if (LoyaltyConstants.ATTR_DATATYPE_DATE.equals(attrDataType)) {
				if (crValue == null || crValue.length() == 0)
					return null;
				else {
					Date date = DateUtil.parseStringToDate(crValue);
					lstR.add(date);
				}
			} else if (LoyaltyConstants.ATTR_DATATYPE_STRING
					.equals(attrDataType)) {
				if (crValue == null || crValue.length() == 0)
					return null;
				else
					lstR.add(crValue);
			} else {
				return null;
			}
		}
		return lstR;
	}

}
