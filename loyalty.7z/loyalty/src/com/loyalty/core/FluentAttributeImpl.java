package com.loyalty.core;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.List;

import org.apache.log4j.Logger;

import com.loyalty.bean.AttrInfo;
import com.loyalty.dto.MMember;
import com.loyalty.dto.MTier;
import com.loyalty.util.CalendarUtil;
import com.loyalty.util.DateUtil;
import com.loyalty.util.LoyaltyConstants;
import com.ruixue.rfw.util.LogUtil;
import com.ruixue.rfw.util.StringUtil;

/**
 * @ClassName: AttributeImpl
 * @Description: ���Ե�ʵ����
 * @author
 * @date Oct 9, 2009 4:45:37 PM
 * 
 */
public class FluentAttributeImpl implements Attribute {

	private static final Logger logger = LogUtil.getLogger();
	private static final String AttributeKey = "KEYVALUE";
	
	private AttrInfo attr;
	private LoyaltyContext ctx;

	/**
	 * <p>
	 * Title:
	 * </p>
	 * <p>
	 * Description:����ʵ����Ĺ��캯��
	 * </p>
	 * 
	 * @param mAttributes
	 * @param ctx
	 */
	public FluentAttributeImpl(AttrInfo attr, LoyaltyContext ctx) {
		this.attr = attr;
		this.ctx = ctx;

	}

	/**
	 * @Title: getAttribute
	 * @Description: �������ݵ��������ͣ�ȡ�����Ե�ֵ
	 * @param
	 * @param sql
	 * @param
	 * @param type
	 * @param
	 * @return
	 * @return Object
	 * @throws
	 */
	private Object getAttribute(String sql, String type) {
		PromotionService db = PromotionService.getInstance();
		// �������� Integer
		if (LoyaltyConstants.ATTR_DATATYPE_INTEGER.equals(type)) {
			HashMap<String, Integer> map = (HashMap<String, Integer>) db
					.selectForInteger(sql);
			if (map == null || map.size() == 0) {
				if (LoyaltyConstants.ATTRTYPE_PROGRAM.equals(attr.getType())
						|| LoyaltyConstants.ATTRTYPE_PROMOTION.equals(attr.getType()))
					return Integer.parseInt(attr.getInitValue());
				else
					return null;

			}
			if (null == map.get(FluentAttributeImpl.AttributeKey)) {
				if (LoyaltyConstants.ATTRTYPE_PROGRAM.equals(attr.getType())
						|| LoyaltyConstants.ATTRTYPE_PROMOTION.equals(attr.getType()))
					return Integer.parseInt(attr.getInitValue());
				else
					return null;
			}
			return (Integer) map.get(FluentAttributeImpl.AttributeKey);
		}
		// Float
		else if (LoyaltyConstants.ATTR_DATATYPE_FLOAT.equals(type)) {
			HashMap<String, Double> map = (HashMap<String, Double>) db
					.selectForDouble(sql);
			if (map == null || map.size() == 0) {
				if (LoyaltyConstants.ATTRTYPE_PROGRAM.equals(attr.getType())
						|| LoyaltyConstants.ATTRTYPE_PROMOTION.equals(attr.getType()))
					return Double.parseDouble(attr.getInitValue());
				else
					return null;
			}
			if (null == map.get(FluentAttributeImpl.AttributeKey)) {
				if (LoyaltyConstants.ATTRTYPE_PROGRAM.equals(attr.getType())
						|| LoyaltyConstants.ATTRTYPE_PROMOTION.equals(attr.getType()))
					return Double.parseDouble(attr.getInitValue());
				else
					return null;
			}
			return (Double) map.get(FluentAttributeImpl.AttributeKey);
		}
		// date
		else if (LoyaltyConstants.ATTR_DATATYPE_DATE.equals(type)) {
			HashMap<String, Date> map = (HashMap<String, Date>) db
					.selectForDate(sql);
			if (map == null || map.size() == 0) {
				if (LoyaltyConstants.ATTRTYPE_PROGRAM.equals(attr.getType())
						|| LoyaltyConstants.ATTRTYPE_PROMOTION.equals(attr.getType()))
					return DateUtil.parseStringToDate(attr.getInitValue());
				else
					return null;
			}
			if (null == map.get(FluentAttributeImpl.AttributeKey)) {
				if (LoyaltyConstants.ATTRTYPE_PROGRAM.equals(attr.getType())
						|| LoyaltyConstants.ATTRTYPE_PROMOTION.equals(attr.getType()))
					return DateUtil.parseStringToDate(attr.getInitValue());
				else
					return null;
			}
			return (Date) map.get(FluentAttributeImpl.AttributeKey);
		}
		// string
		else if (LoyaltyConstants.ATTR_DATATYPE_STRING.equals(type)) {
			HashMap<String, String> map = (HashMap<String, String>) db
					.selectForString(sql);
			if (map == null || map.size() == 0) {
				if (LoyaltyConstants.ATTRTYPE_PROGRAM.equals(attr.getType())
						|| LoyaltyConstants.ATTRTYPE_PROMOTION.equals(attr.getType()))
					return attr.getInitValue();
				else
					return null;
			}
			if (null == map.get(FluentAttributeImpl.AttributeKey)) {
				if (LoyaltyConstants.ATTRTYPE_PROGRAM.equals(attr.getType())
						|| LoyaltyConstants.ATTRTYPE_PROMOTION.equals(attr.getType()))
					return attr.getInitValue();
				else
					return null;
			}
			return (String) map.get(FluentAttributeImpl.AttributeKey);
		}
		// 20140520 Boolean���� liuhui
		else if (LoyaltyConstants.ATTR_DATATYPE_BOOLEAN.equals(type)) {
			HashMap<String, String> map = (HashMap<String, String>) db
				.selectForString(sql);
			if (map == null || map.size() == 0 || null == map.get(FluentAttributeImpl.AttributeKey)) {
				if (LoyaltyConstants.ATTRTYPE_PROGRAM.equals(attr.getType())
						|| LoyaltyConstants.ATTRTYPE_PROMOTION.equals(attr.getType())) {
					if (StringUtil.isEmpty(attr.getInitValue())) {
						return false;
					}
					// TODO
					if ("0".equals(StringUtil.lrTrimFullSpace(attr.getInitValue()))) {
						return false;
					} else {
						return true;
					}
				}
				else return false;
			}
			String value = (String) map.get(FluentAttributeImpl.AttributeKey);
			if (StringUtil.isEmpty(value)) {
				return false;
			}
			// TODO
			if ("0".equals(StringUtil.lrTrimFullSpace(value))) {
				return false;
			} else {
				return true;
			} 
		}
		return null;

	}

	/*
	 * (non-Javadoc) <p>Title: getAttributes</p> <p>Description: ȡ������ֵ</p>
	 * @return
	 * 
	 * @see com.loyalty.core.Attribute#getAttributes()
	 */

	public Object getAttributes() {
		// ��������
		String attr_type = attr.getType();
		String table = attr.getTableName();
		String col = attr.getFieldName();
		StringBuffer sb = new StringBuffer();
		// ����ϵͳ����
		if (LoyaltyConstants.ATTRTYPE_SYSTEM.equals(attr_type)) {
			if (LoyaltyConstants.SYSTEM_DATE.equals(col)) {
				return DateUtil.getSysDate(ctx.getCtxDate());
			}
			if (LoyaltyConstants.SYSTEM_MONTH.equals(col)) {
				return CalendarUtil.getMonth(CalendarUtil
						.getCalendarInstance(ctx.getCtxDate()));
			}
			if (LoyaltyConstants.SYSTEM_DAY.equals(col)) {
				return CalendarUtil.getDayFromSpecifiedDate(CalendarUtil
						.getCalendarInstance(ctx.getCtxDate()));
			}
		} else if (LoyaltyConstants.ATTRTYPE_CUSTOMIZE.equals(attr_type)) {
			Object objReturn = null;
			try {
				PromotionService db = PromotionService.getInstance();
				if (LoyaltyConstants.ATTR_DATATYPE_INTEGER.equals(attr
						.getDataType())) {
					objReturn = db.getCustomizeAttr_Integer(attr
							.getProcedureName(), ctx.getMemberId(), ctx
							.getOrderId());
				} else if (LoyaltyConstants.ATTR_DATATYPE_FLOAT.equals(attr
						.getDataType())) {
					objReturn = db.getCustomizeAttr_Double(attr
							.getProcedureName(), ctx.getMemberId(), ctx
							.getOrderId());
				} else if (LoyaltyConstants.ATTR_DATATYPE_STRING.equals(attr
						.getDataType())) {
					objReturn = db.getCustomizeAttr_String(attr
							.getProcedureName(), ctx.getMemberId(), ctx
							.getOrderId());
				} else if (LoyaltyConstants.ATTR_DATATYPE_DATE.equals(attr
						.getDataType())) {
					objReturn = db.getCustomizeAttr_Date(attr
							.getProcedureName(), ctx.getMemberId(), ctx
							.getOrderId());
				} else {
					logger.info("����������" + attr.getDataType());
				}
			} catch (Exception e) {
				e.printStackTrace();
				logger.info("ȡ����ʧ�ܣ�");
			}
			return objReturn;
		}
		// �������=��Ա�ȼ�
		else if (LoyaltyConstants.ATTRTYPE_MEMBERTIER.equals(attr_type)) {
			//add start 2014/04/27 liuxingya
			if ("M_TIER".equals(table)) {
				/*sb.append(" Select ");
				sb.append(" B." + col + " " + AttributeImpl.AttributeKey);
				sb.append(" From ");
				sb.append(" " + table + " B");
				sb.append(" left join M_MEMBER_TIER mmt ON(mmt.TIER = B.ID) ");
				sb.append(" where B.ACTIVE_FLAG = "
						+ LoyaltyConstants.LOYALTY_ACTIVE);
				sb.append("  and  mmt." + LoyaltyConstants.DB_MEMBER_FK + "='"
						+ ctx.getMemberId() + "'");
				sb
						.append("  and  B.TIER_CLASS_ID = '" + attr.getTIER_CLASS_ID()
								+ "'");*/
				if (ctx.getMember().getTiers().isEmpty()) {
					return "";
				} else {
					return ctx.getMember().getTiers().get(0).getName();
				}
			} else {
			//add end 2014/04/27 liuxingya
			sb.append(" Select ");
			sb.append(" B." + col + " " + FluentAttributeImpl.AttributeKey);
			sb.append(" From ");
			sb.append(" " + table + " B");
			sb.append(" where B.ACTIVE_FLAG = "
					+ LoyaltyConstants.LOYALTY_ACTIVE);
			sb.append("  and  B." + LoyaltyConstants.DB_MEMBER_FK + "='"
					+ ctx.getMemberId() + "'");
			sb
					.append("  and  B.TIER_CLASS = '" + attr.getTierClassId()
							+ "'");
			//add start 2014/04/27 liuxingya
			}
			//add end 2014/04/27 liuxingya
		}
		// �������=��Ա����
		else if (LoyaltyConstants.ATTRTYPE_MEMBERPOINTS.equals(attr_type)) {

			String memId = ctx.getMemberId();
			if (StringUtil.isEmpty(memId)) {
				memId = ctx.getMember().getId();
			}
			
			sb.append(" Select ");
			sb.append(" B." + col + " " + FluentAttributeImpl.AttributeKey);
			sb.append(" From ");
			sb.append(" " + table + " B");
			sb.append("  where  B." + LoyaltyConstants.DB_MEMBER_FK + "='"
					+ memId + "'");
			sb.append("  and  B.POINT_TYPE_ID = '" + attr.getPointTypeId()
					+ "'");
		}
		// ��������=����Ա����
		else if (LoyaltyConstants.ATTRTYPE_MEMBER.equals(attr_type)) {
			if ("BIND_FLAG".equals(col)) {
				return ctx.getMember().isBind();
			}
			sb.append(" Select ");
			sb.append("B." + col + " " + FluentAttributeImpl.AttributeKey);
			sb.append(" From ");
			if (LoyaltyConstants.DB_MEMBER_TABLE.equalsIgnoreCase(table)) {

				sb.append(" " + LoyaltyConstants.DB_MEMBER_TABLE + " B");
				sb.append(" Where");
				sb.append("  B." + LoyaltyConstants.DB_MEMBER_PK + "='"
						+ ctx.getMemberId() + "'");
			} else if (LoyaltyConstants.DB_CUSTOMER_TABLE
					.equalsIgnoreCase(table)) {

				sb.append(" " + LoyaltyConstants.DB_CUSTOMER_TABLE + " B");
				sb.append(" Where");
				sb.append("  B." + LoyaltyConstants.DB_CUSTOMER_PK + "='"
						+ ctx.getCustomerId() + "'");
			} else {
				sb.append(" " + table + " B,"
						+ LoyaltyConstants.DB_MEMBER_TABLE + " A");
				sb.append(" Where");
				sb.append(" A." + LoyaltyConstants.DB_MEMBER_PK + "=" + "B."
						+ LoyaltyConstants.DB_MEMBER_FK);
				sb.append(" and A." + LoyaltyConstants.DB_MEMBER_PK + "='"
						+ ctx.getMemberId() + "'");
			}
		}
		// ��������=�����ס���
		else if (LoyaltyConstants.ATTRTYPE_TRANSACTION.equals(attr_type)) {
			if (LoyaltyConstants.DB_EXTERNAL_ORDER_TABLE.equals(table)) {
				String paramName = attr.getFieldName();
				if ("ORI_ORDER_AMOUNT".equals(paramName)) {
					return ctx.getOrderInfo().getAmount();
				}
				if ("CONVERT_POINT_FLG".equals(paramName)) {
					return ctx.getOrderInfo().getConvertPointFlg();
				}
			}
			sb.append(" Select ");
			sb.append("B." + col + " " + FluentAttributeImpl.AttributeKey);
			sb.append(" From ");
			// ������ϸ��
			if (LoyaltyConstants.DB_ORDER_ITEM_TABLE.equalsIgnoreCase(table)) {

				sb.append(" " + LoyaltyConstants.DB_ORDER_ITEM_TABLE + " B");
				sb.append(" Where");
				sb.append("  B." + LoyaltyConstants.DB_ORDER_ITEM_PK + "='"
						+ ctx.getOrderItemId() + "'");
			}
			// ���ױ�
			else if (LoyaltyConstants.DB_ORDER_TABLE.equalsIgnoreCase(table)) {
				sb.append(" " + LoyaltyConstants.DB_ORDER_TABLE + " B");
				sb.append(" Where");
				sb.append("  B." + LoyaltyConstants.DB_ORDER_PK + "='"
						+ ctx.getOrderId() + "'");
			} else {
				sb.append(" " + table + " B , "
						+ LoyaltyConstants.DB_ORDER_TABLE + " A");
				sb.append(" Where");
				sb.append(" A." + LoyaltyConstants.DB_ORDER_PK + "=" + "B."
						+ LoyaltyConstants.DB_ORDER_FK);
				sb.append(" and A." + LoyaltyConstants.DB_ORDER_PK + "='"
						+ ctx.getOrderId() + "'");
			}

		}
		// ��������=��Program��
		else if (LoyaltyConstants.ATTRTYPE_PROGRAM.equals(attr_type)) {
			sb.append(" Select ");
			sb.append("A." + col + " " + FluentAttributeImpl.AttributeKey);
			sb.append(" From ");
			sb.append(" " + table + " A");
			sb.append(" Where");
			sb.append(" A.PROGRAM_ID='" + ctx.getProgramId() + "'");
			sb.append(" and A.MEMBER_ID='" + ctx.getMemberId() + "'");
		}
		// ��������=��Promotion��
		else if (LoyaltyConstants.ATTRTYPE_PROMOTION.equals(attr_type)) {
			sb.append(" Select ");
			sb.append("A." + col + " " + FluentAttributeImpl.AttributeKey);
			sb.append(" From ");
			sb.append(" " + table + " A");
			sb.append(" Where");
			sb.append(" A.PROGRAM_ID='" + ctx.getProgramId() + "'");
			sb.append(" and A.PROMOTION_ID='" + ctx.getPromotionId() + "'");
			sb.append(" and A.MEMBER_ID='" + ctx.getMemberId() + "'");
		}
		// ��������=���ۼơ���
		else if (LoyaltyConstants.ATTRTYPE_TOTAL.equals(attr_type)) {
			String total_type = attr.getTotalType();
			Integer period = attr.getPeriod();
			StringBuffer sql = new StringBuffer();

			if (LoyaltyConstants.TOTALATTR_YEAR.equals(attr.getUom())) {
				//change start 2014/04/29 liuxingya
//				sql
//					.append(" and B.TRANS_DATE> dateadd(day,1,dateadd(year,(-1)*"
//							+ period.intValue()
//							+ ",Convert(varchar(10),'"
//							+ DateUtil.pareFormateDate(ctx.getCtxDate())
//							+ "',120)))");
				sql.append(" and B.TRANS_DATE> adddate(DATE_ADD("
					+ "DATE_FORMAT('"
					+ DateUtil.pareFormateDate(ctx.getCtxDate()) 
					+ "', '%Y-%m-%d'), INTERVAL (-1)*" + period.intValue() + " YEAR), 1)");
				//change end 2014/04/29 liuxingya
				if (LoyaltyConstants.ACTIONOBJECT_MEMBER.equals(ctx
						.getObjType())) {
					//change start 2014/04/29 liuxingya
//					sql
//							.append(" and B.TRANS_DATE<dateadd(day,1,Convert(varchar(10),'"
//									+ DateUtil
//											.pareFormateDate(ctx.getCtxDate())
//									+ "',120))");
					sql.append(" and DATE_FORMAT(B.TRANS_DATE,'%Y-%m-%d')<adddate(DATE_FORMAT('"
								+ DateUtil.pareFormateDate(ctx.getCtxDate())
								+ "','%Y-%m-%d'), 1)");
					//change end 2014/04/29 liuxingya
				} else {
					//change start 2014/04/29 liuxingya
//					sql.append(" and  B.TRANS_DATE<=Convert(varchar(19),'"
//							+ DateUtil.pareFormateDate(ctx.getCtxDate())
//							+ "',120)");
					sql.append(" and  DATE_FORMAT(B.TRANS_DATE,'%Y-%m-%d')<=DATE_FORMAT('"
							+ DateUtil.pareFormateDate(ctx.getCtxDate())
							+ "','%Y-%m-%d')");
					//change end 2014/04/29 liuxingya
				}
			} else if (LoyaltyConstants.TOTALATTR_MONTH.equals(attr.getUom())) {
				//change start 2014/04/29 liuxingya
//				sql
//						.append(" and B.TRANS_DATE> dateadd(day,1,dateadd(month,(-1)*"
//								+ period.intValue()
//								+ ",Convert(varchar(10),'"
//								+ DateUtil.pareFormateDate(ctx.getCtxDate())
//								+ "',120)))");
				sql.append(" and DATE_FORMAT(B.TRANS_DATE,'%Y-%m-%d')> adddate(DATE_ADD("
						+ ",DATE_FORMAT('"
						+ DateUtil.pareFormateDate(ctx.getCtxDate())
						+ "','%Y-%m-%d'), INTERVAL (-1)*" + period.intValue() + " MONTH), 1)");
				//change end 2014/04/29 liuxingya
				if (LoyaltyConstants.ACTIONOBJECT_MEMBER.equals(ctx
						.getObjType())) {
					//change start 2014/04/29 liuxingya
//					sql
//							.append(" and B.TRANS_DATE<dateadd(day,1,Convert(varchar(10),'"
//									+ DateUtil
//											.pareFormateDate(ctx.getCtxDate())
//									+ "',120))");
					sql.append(" and DATE_FORMAT(B.TRANS_DATE,'%Y-%m-%d')<adddate(DATE_FORMAT('"
							+ DateUtil.pareFormateDate(ctx.getCtxDate())
							+ "','%Y-%m-%d'), 1)");
					//change end 2014/04/29 liuxingya
				} else {
					//change start 2014/04/29 liuxingya
//					sql.append(" and  B.TRANS_DATE<=Convert(varchar(19),'"
//							+ DateUtil.pareFormateDate(ctx.getCtxDate())
//							+ "',120)");
					sql.append(" and  DATE_FORMAT(B.TRANS_DATE,'%Y-%m-%d')<=DATE_FORMAT('"
							+ DateUtil.pareFormateDate(ctx.getCtxDate())
							+ "','%Y-%m-%d')");
					//change end 2014/04/29 liuxingya
				}
			} else if (LoyaltyConstants.TOTALATTR_DAY.equals(attr.getUom())) {
				//change start 2014/04/29 liuxingya
//				sql.append(" and B.TRANS_DATE> dateadd(day,(-1)*"
//						+ (period.intValue() - 1) + ",Convert(varchar(10),'"
//						+ DateUtil.pareFormateDate(ctx.getCtxDate())
//						+ "',120))");
				sql.append(" and DATE_FORMAT(B.TRANS_DATE,'%Y-%m-%d')> adddate("
						+ "DATE_FORMAT('"
						+ DateUtil.pareFormateDate(ctx.getCtxDate())
						+ "','%Y-%m-%d'), (-1)*" + (period.intValue() - 1) + ")");
				//change end 2014/04/29 liuxingya
				if (LoyaltyConstants.ACTIONOBJECT_MEMBER.equals(ctx
						.getObjType())) {
					//change start 2014/04/29 liuxingya
//					sql
//							.append(" and B.TRANS_DATE<dateadd(day,1,Convert(varchar(10),'"
//									+ DateUtil
//											.pareFormateDate(ctx.getCtxDate())
//									+ "',120))");
					sql.append(" and DATE_FORMAT(B.TRANS_DATE,'%Y-%m-%d')<adddate(DATE_FORMAT('"
							+ DateUtil.pareFormateDate(ctx.getCtxDate())
							+ "','%Y-%m-%d'), 1)");
					//change end 2014/04/29 liuxingya
				} else {
					//change start 2014/04/29 liuxingya
//					sql.append(" and  B.TRANS_DATE<=Convert(varchar(19),'"
//							+ DateUtil.pareFormateDate(ctx.getCtxDate())
//							+ "',120)");
					sql.append(" and  DATE_FORMAT(B.TRANS_DATE,'%Y-%m-%d')<=DATE_FORMAT('"
							+ DateUtil.pareFormateDate(ctx.getCtxDate())
							+ "','%Y-%m-%d')");
					//change end 2014/04/29 liuxingya
				}
			} else if (LoyaltyConstants.TOTALATTR_MEMBER_PERIOD.equals(attr
					.getUom())) {
				PromotionService db = PromotionService.getInstance();
				MMember member = db.getMember(ctx.getMemberId());
				DateFormat format = new SimpleDateFormat("yyyy-MM-dd");
				String start = format.format(member.getSTART_DATE());
				String end = format.format(member.getEND_DATE());
				//change start 2014/04/29 liuxingya
//				sql
//						.append(" and B.TRANS_DATE>=Convert(varchar(10),'"
//								+ start
//								+ "',120) and B.TRANS_DATE<dateadd(day,1,Convert(varchar(10),'"
//								+ end + "',120))");
				sql.append(" and DATE_FORMAT(B.TRANS_DATE,'%Y-%m-%d')>=DATE_FORMAT('"
						+ start
						+ "','%Y-%m-%d') and B.TRANS_DATE<adddate(DATE_FORMAT('"
						+ end + "','%Y-%m-%d'), 1)");
				//change end 2014/04/29 liuxingya
			} else {
				return null;
			}

			// ������ϸ��
			if (LoyaltyConstants.DB_ORDER_ITEM_TABLE.equalsIgnoreCase(table)) {
				// ���
				if (LoyaltyConstants.TOTALATTR_AMOUNT.equals(total_type)) {
					sb.append(" Select ");
					sb.append(" sum(A." + col + ") "
							+ FluentAttributeImpl.AttributeKey);
					sb.append(" From ");
				}
				// ����
				else if (LoyaltyConstants.TOTALATTR_COUNT.equals(total_type)) {
					sb.append(" Select ");
					sb.append(" count(*) " + FluentAttributeImpl.AttributeKey);
					sb.append(" From ");
				}
				PromotionService db = PromotionService.getInstance();
				List<String> lst = db.getIncludeProductList(ctx
						.getPromotionId());
				StringBuffer sbProduct = new StringBuffer();
				for (int i = 0; lst != null && i < lst.size(); i++) {
					if (i == 0)
						sbProduct.append("'" + lst.get(i) + "'");
					else
						sbProduct.append(",'" + lst.get(i) + "'");
				}
				if (ctx.getMemberId() == null
						|| ctx.getMemberId().length() == 0) {
					sb.append(" " + LoyaltyConstants.DB_ORDER_TABLE
							+ " B left join " + table + " A");
					sb.append(" on");
					sb.append(" b." + LoyaltyConstants.DB_ORDER_PK + "=" + "A."
							+ LoyaltyConstants.DB_ORDER_FK);
					sb.append(" where B.CUSTOMER_ID='" + ctx.getCustomerId()
							+ "'");
					sb.append(" and B.PROGRAM_ID='" + ctx.getProgramId() + "'");
					sb.append(" and B.type='" + LoyaltyConstants.TRANS_TYPE_BUY
							+ "'");
					sb.append(" and A.PRODUCT_ID in (" + sbProduct.toString()
							+ ")");
					sb.append(sql);
					sb.append(" group by B.CUSTOMER_ID,B.PROGRAM_ID");
				} else {
					sb.append(" " + LoyaltyConstants.DB_ORDER_TABLE
							+ " B left join " + table + " A");
					sb.append(" on");
					sb.append(" b." + LoyaltyConstants.DB_ORDER_PK + "=" + "A."
							+ LoyaltyConstants.DB_ORDER_FK);
					sb.append(" where B." + LoyaltyConstants.DB_MEMBER_FK
							+ "='" + ctx.getMemberId() + "'");
					sb.append(" and B.PROGRAM_ID='" + ctx.getProgramId() + "'");
					sb.append(" and B.type='" + LoyaltyConstants.TRANS_TYPE_BUY
							+ "'");
					sb.append(" and A.PRODUCT_ID in (" + sbProduct.toString()
							+ ")");
					sb.append(sql);
					sb.append(" group by B." + LoyaltyConstants.DB_MEMBER_FK);
				}
			}
			// ���ױ�
			else if (LoyaltyConstants.DB_ORDER_TABLE.equalsIgnoreCase(table)) {
				// ���
				if (LoyaltyConstants.TOTALATTR_AMOUNT.equals(total_type)) {
					sb.append(" Select ");
					sb.append(" sum(B." + col + ") "
							+ FluentAttributeImpl.AttributeKey);
					sb.append(" From ");
					sb.append(" " + table + " B ");
				}
				// ����
				else if (LoyaltyConstants.TOTALATTR_COUNT.equals(total_type)) {
					sb.append(" Select ");
					sb.append(" count(*) " + FluentAttributeImpl.AttributeKey);
					sb.append(" From ");
					sb.append(" " + table + " B ");
				}
				if (ctx.getMemberId() == null
						|| ctx.getMemberId().length() == 0) {
					sb.append(" Where");
					sb.append(" B.CUSTOMER_ID='" + ctx.getCustomerId() + "'");
					sb.append(" and B.PROGRAM_ID='" + ctx.getProgramId() + "'");
					sb.append(" and B.type='" + LoyaltyConstants.TRANS_TYPE_BUY
							+ "'");
					sb.append(sql);
					sb.append(" group by B.CUSTOMER_ID,B.PROGRAM_ID");
				} else {
					sb.append(" Where");
					sb.append(" B." + LoyaltyConstants.DB_MEMBER_FK + "='"
							+ ctx.getMemberId() + "'");
					sb.append(" and B.PROGRAM_ID='" + ctx.getProgramId() + "'");
					sb.append(" and B.type='" + LoyaltyConstants.TRANS_TYPE_BUY
							+ "'");
					sb.append(sql);
					sb.append(" group by B." + LoyaltyConstants.DB_MEMBER_FK);
				}

			} else {
				logger.info("ȡ�ۼ�����ʧ�ܣ�" + table);
			}
		//add start 2014/04/18 liuxingya
		} else if (LoyaltyConstants.PROMOTION_SOURCE_REAL_TIME.equals(attr_type)) {
			String paramName = attr.getFieldName();
			Object objReturn = ctx.getParams().get(paramName);
			return objReturn;
		//add end 2014/04/18 liuxingya
		} else {
			logger.info("��������ʧ�ܣ�" + attr_type);
			return null;
		}

		logger.info("member:" + ctx.getMemberId());
		logger.info(attr_type + ":" + sb.toString());

		Object objReturn = null;

		try {
			objReturn = getAttribute(sb.toString(), attr.getDataType());
			if (LoyaltyConstants.ATTRTYPE_MEMBERTIER.equals(attr_type)) {
				if (objReturn != null) {
					PromotionService db = PromotionService.getInstance();
					MTier mtier = db.getTier((String) objReturn);
					return mtier.getTIER_NAME();
				}
			} else if (LoyaltyConstants.ATTRTYPE_TOTAL.equals(attr_type)) {
				if (objReturn == null) {
					if (LoyaltyConstants.TOTALATTR_AMOUNT.equals(attr
							.getTotalType()))
						return new Double(0);
					else
						return new Integer(0);
				}
			}
		} catch (Exception e) {
			logger.info("ȡ����ʧ�ܣ�" + sb.toString());
		}
		return objReturn;
	}
}
