package com.loyalty.core;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.List;

import org.apache.log4j.Logger;

import com.loyalty.bean.CriteriaInfo;
import com.loyalty.bean.ValueInfo;
import com.loyalty.dto.MCustomer;
import com.loyalty.util.DateUtil;
import com.loyalty.util.LoyaltyConstants;
import com.ruixue.rfw.util.LogUtil;
import com.ruixue.rfw.util.StringUtil;

/**
 * @ClassName: CriteriaImpl
 * @Description: �ǿͻ���������ʵ����
 * @author
 * @date Oct 9, 2009 5:00:08 PM
 * 
 */
public class FluentCriteriaImpl implements Criteria {
	
	private static Logger logger = LogUtil.getLogger();
	
	protected CriteriaInfo c;
	protected LoyaltyContext ctx;
	private String attrDataType;
	private String AttributeKey = "KEYVALUE";

	/**
	 * <p>
	 * Title:
	 * </p>
	 * <p>
	 * Description: ���캯��
	 * </p>
	 * 
	 * @param cr
	 *            ����
	 * @param context
	 *            �������ݻ���
	 */
	public FluentCriteriaImpl(CriteriaInfo c, LoyaltyContext context) {
		this.c = c;
		this.ctx = context;
	}

	/**
	 * <p>
	 * Title:
	 * </p>
	 * <p>
	 * Description: ���캯��
	 * </p>
	 */
	public FluentCriteriaImpl() {

	}

	/**
	 * @Title: getUseBorn
	 * @Description: �õ��ͻ��ĳ�������
	 * @param
	 * @param customId
	 * @param
	 * @return
	 * @return Date
	 * @throws
	 */
	private Date getUseBorn(String customId) {
		PromotionService db = PromotionService.getInstance();
		MCustomer customer = db.getCustomer(customId);
		return customer.getBIRTHDAY();

	}

	/**
	 * @Title: isMonth
	 * @Description: �ж������Ƿ����յ���
	 * @param
	 * @param bornDate
	 * @param
	 * @return
	 * @return boolean
	 * @throws
	 */
	private boolean isMonth(Date bornDate) {

		GregorianCalendar curr = new GregorianCalendar();
		GregorianCalendar born = new GregorianCalendar();
		born.setTime(bornDate);
		curr.setTime(ctx.getCtxDate());
		int currM = curr.get(Calendar.MONTH);
		int useM = born.get(Calendar.MONTH);
		if (currM == useM)
			return true;
		else
			return false;
	}

	/**
	 * @Title: isWeek
	 * @Description: �ж������Ƿ����յ���
	 * @param
	 * @param bornDate
	 * @param
	 * @return
	 * @return boolean
	 * @throws
	 */
	private boolean isWeek(Date bornDate) {

		GregorianCalendar curr = new GregorianCalendar();
		GregorianCalendar born = new GregorianCalendar();
		curr.setTime(ctx.getCtxDate());
		born.setTime(bornDate);
		born.set(curr.get(Calendar.YEAR), born.get(Calendar.MONTH), born
				.get(Calendar.DATE));
		int currW = curr.get(Calendar.WEEK_OF_YEAR);
		int useW = born.get(Calendar.WEEK_OF_YEAR);
		if (currW == useW)
			return true;
		else
			return false;
	}

	/**
	 * @Title: isDay
	 * @Description: �ж������Ƿ����յ���
	 * @param
	 * @param bornDate
	 * @param
	 * @return
	 * @return boolean
	 * @throws
	 */
	private boolean isDay(Date bornDate) {

		GregorianCalendar curr = new GregorianCalendar();
		GregorianCalendar born = new GregorianCalendar();
		born.setTime(bornDate);
		curr.setTime(ctx.getCtxDate());
		int currD = curr.get(Calendar.DATE);
		int useD = born.get(Calendar.DATE);
		if (currD == useD)
			return true;
		else
			return false;
	}

	/**
	 * @Title: compareAttr
	 * @Description: �Ƚ�����������
	 * @param
	 * @return
	 * @return boolean
	 * @throws
	 */
	private boolean compareAttr() {
		
		if (c.getAttr() == null) return false;
		if (StringUtil.isEmpty(c.getAttr().getDataType())) return false;
		if (!ctx.getProgramId().equals(c.getAttr().getProgramId())) return false;

		attrDataType = c.getAttr().getDataType();
		Attribute att = new FluentAttributeImpl(c.getAttr(), ctx);
		Object attValue = att.getAttributes();

		if (attValue == null) {
			return false;
		}
		// 20140520 Boolean���� liuhui
		if (LoyaltyConstants.ATTR_DATATYPE_BOOLEAN.equals(attrDataType)) {
			return (Boolean) attValue;
		}

		if (!c.getCompareAttr().isActivity()) {
			List<Object> attCompareValue = makeCompareValue(c.getValues());
			if (attCompareValue == null || attCompareValue.size() == 0)
				return false;
			else {
				return compare(attValue, attCompareValue, c.getCompareMode(), attrDataType);
			}
		} else {

			if (!attrDataType.equals(c.getCompareAttr().getDataType())) return false;
			
			Attribute attTo = new FluentAttributeImpl(c.getCompareAttr(), ctx);
			Object attValueTo = attTo.getAttributes();
			if (attValueTo == null) return false;

			if (StringUtil.isEmpty(c.getOperate())) {
				
				List<Object> lst = Collections.singletonList(attValueTo);
				return compare(attValue, lst, c.getCompareMode(), attrDataType);
			} else {
				if (c.getValues() == null || c.getValues().isEmpty()) return false;
				
				attValueTo = getOperateResult(attValueTo, c.getValues().get(0).getValue(),
					c.getOperate());
				
				if (attValueTo == null) return false;
				List<Object> lst = Collections.singletonList(attValueTo);
				return compare(attValue, lst, c.getCompareMode(),
						attrDataType);
			}
		}
	}

	/**
	 * @Title: getOperateResult
	 * @Description: ������ֵת��Ϊһ�����ԱȽϵĶ���
	 * @param
	 * @param value
	 * @param
	 * @param DataType
	 * @param
	 * @return
	 * @return Object
	 * @throws
	 */
	public Object getOperateResult(String value, String DataType) {
		if (LoyaltyConstants.ATTR_DATATYPE_INTEGER.equals(DataType)
				|| LoyaltyConstants.ATTR_DATATYPE_FLOAT.equals(DataType)) {
			return Double.valueOf(value);
		} else if (LoyaltyConstants.ATTR_DATATYPE_DATE.equals(DataType)) {
			Date date = DateUtil.parseStringToDate(value);

			return date;
		} else {
			return value;
		}
	}

	/**
	 * @Title: getOperateResult
	 * @Description: ������������õ�һ���Ƚ�ֵ
	 * @param
	 * @param objTo
	 * @param
	 * @param value
	 * @param
	 * @param operate
	 * @param
	 * @return
	 * @return Object
	 * @throws
	 */
	public Object getOperateResult(Object objTo, String value, String operate) {
		if (LoyaltyConstants.ATTR_DATATYPE_INTEGER.equals(attrDataType)
				|| LoyaltyConstants.ATTR_DATATYPE_FLOAT.equals(attrDataType)) {
			double lngCompareTo;
			double lngOperate;
			if (objTo instanceof Integer)
				lngCompareTo = ((Integer) objTo).doubleValue();
			else
				lngCompareTo = ((Double) objTo).doubleValue();
			lngOperate = Double.valueOf(value);
			if (LoyaltyConstants.CRITERIA_OPERATE_M_PLUS.equals(operate)) {
				return new Double(lngCompareTo + lngOperate);
			} else if (LoyaltyConstants.CRITERIA_OPERATE_M_SUBTRACT
					.equals(operate)) {
				return new Double(lngCompareTo - lngOperate);
			} else if (LoyaltyConstants.CRITERIA_OPERATE_M_MULTIPLE
					.equals(operate)) {
				return new Double(lngCompareTo * lngOperate);
			} else if (LoyaltyConstants.CRITERIA_OPERATE_M_DIVIDE
					.equals(operate)) {
				if (lngOperate == 0)
					return null;
				else
					return new Double(lngCompareTo / lngOperate);
			} else {
				return null;
			}
		} else if (LoyaltyConstants.ATTR_DATATYPE_DATE.equals(attrDataType)) {
			int inday;
			inday = Integer.valueOf(value);
			if (LoyaltyConstants.CRITERIA_OPERATE_M_PLUS.equals(operate)) {
				GregorianCalendar cCompareTo = new GregorianCalendar();
				cCompareTo.setTime((Date) objTo);
				cCompareTo.add(Calendar.DATE, inday);
				return cCompareTo.getTime();
			} else if (LoyaltyConstants.CRITERIA_OPERATE_M_SUBTRACT
					.equals(operate)) {
				GregorianCalendar cCompareTo = new GregorianCalendar();
				cCompareTo.setTime((Date) objTo);
				cCompareTo.add(Calendar.DATE, -1 * inday);
				return cCompareTo.getTime();
			} else if (LoyaltyConstants.CRITERIA_OPERATE_M_MULTIPLE
					.equals(operate)) {
				return null;
			} else if (LoyaltyConstants.CRITERIA_OPERATE_M_DIVIDE
					.equals(operate)) {

				return null;
			} else if (LoyaltyConstants.ATTR_DATATYPE_STRING
					.equals(attrDataType)) {
				return null;
			}
		}
		return null;
	}

	/**
	 * @Title: compare
	 * @Description: ���ݱȽ��������Ƚ�����ֵ
	 * @param
	 * @param objCompare
	 * @param
	 * @param objCompareTo
	 * @param
	 * @param compareCond
	 * @param
	 * @param dataType
	 * @param
	 * @return
	 * @return boolean
	 * @throws
	 */
	public boolean compare(Object objCompare, List<Object> objCompareTo,
			String compareCond, String dataType) {

		logger.debug("++++ �����ж�:ֵ�Ƚ�[����:�ȶ�] (" + objCompare + " <-> " + objCompareTo.toString() + ")");
		
		if (LoyaltyConstants.CRITERIA_EQUALS.equals(compareCond)) {
			if (LoyaltyConstants.ATTR_DATATYPE_INTEGER.equals(dataType)
					|| LoyaltyConstants.ATTR_DATATYPE_FLOAT.equals(dataType)) {
				double value;

				if (objCompare instanceof Integer)
					value = ((Integer) objCompare).doubleValue();
				else
					value = ((Double) objCompare).doubleValue();
				for (int i = 0; i < objCompareTo.size(); i++) {
					double curr;
					if (objCompareTo.get(i) instanceof Integer)
						curr = ((Integer) objCompareTo.get(i)).doubleValue();
					else
						curr = ((Double) objCompareTo.get(i)).doubleValue();
					if (value == curr)
						return true;
				}
			}

			else if (LoyaltyConstants.ATTR_DATATYPE_DATE.equals(dataType)) {
				Date value = (Date) objCompare;
				DateFormat format = new SimpleDateFormat("yyyy-MM-dd");
				String strValue = format.format(value);
				for (int i = 0; i < objCompareTo.size(); i++) {
					Date curr = ((Date) objCompareTo.get(i));
					String strCurr = format.format(curr);
					if (strValue.equals(strCurr))
						return true;
				}
			} else if (LoyaltyConstants.ATTR_DATATYPE_STRING.equals(dataType)) {
				String value = (String) objCompare;
				for (int i = 0; i < objCompareTo.size(); i++) {
					String curr = ((String) objCompareTo.get(i));
					if (value.equals(curr))
						return true;
				}
			} else {
				return false;
			}
		} else if (LoyaltyConstants.CRITERIA_NOTEQUAL.equals(compareCond)) {
			if (LoyaltyConstants.ATTR_DATATYPE_INTEGER.equals(dataType)
					|| LoyaltyConstants.ATTR_DATATYPE_FLOAT.equals(dataType)) {
				double value;
				if (objCompare instanceof Integer)
					value = ((Integer) objCompare).doubleValue();
				else
					value = ((Double) objCompare).doubleValue();
				boolean blnOk = true;
				for (int i = 0; i < objCompareTo.size(); i++) {
					double curr;
					if (objCompareTo.get(i) instanceof Integer)
						curr = ((Integer) objCompareTo.get(i)).doubleValue();
					else
						curr = ((Double) objCompareTo.get(i)).doubleValue();
					if (value == curr)
						blnOk = false;
				}
				if (blnOk)
					return true;
			} else if (LoyaltyConstants.ATTR_DATATYPE_DATE.equals(dataType)) {
				Date value = (Date) objCompare;
				DateFormat format = new SimpleDateFormat("yyyy-MM-dd");
				String strValue = format.format(value);
				boolean blnOk = true;
				for (int i = 0; i < objCompareTo.size(); i++) {
					Date curr = ((Date) objCompareTo.get(i));
					String strCurr = format.format(curr);
					if (strValue.equals(strCurr))
						blnOk = false;
				}
				if (blnOk)
					return true;
			} else if (LoyaltyConstants.ATTR_DATATYPE_STRING.equals(dataType)) {
				String value = (String) objCompare;
				boolean blnOk = true;
				for (int i = 0; i < objCompareTo.size(); i++) {
					String curr = ((String) objCompareTo.get(i));
					if (value.equals(curr))
						blnOk = false;
				}
				if (blnOk)
					return true;
			} else {
				return false;
			}
		} else if (LoyaltyConstants.CRITERIA_GREATER.equals(compareCond)) {
			if (LoyaltyConstants.ATTR_DATATYPE_INTEGER.equals(dataType)
					|| LoyaltyConstants.ATTR_DATATYPE_FLOAT.equals(dataType)) {
				double value;
				if (objCompare instanceof Integer)
					value = ((Integer) objCompare).doubleValue();
				else
					value = ((Double) objCompare).doubleValue();
				double curr;
				if (objCompareTo.get(0) instanceof Integer)
					curr = ((Integer) objCompareTo.get(0)).doubleValue();
				else
					curr = ((Double) objCompareTo.get(0)).doubleValue();
				if (value > curr)
					return true;
			}

			else if (LoyaltyConstants.ATTR_DATATYPE_DATE.equals(dataType)) {
				Date value = (Date) objCompare;
				Date curr = ((Date) objCompareTo.get(0));
				if (value.compareTo(curr) > 0)
					return true;
			} else if (LoyaltyConstants.ATTR_DATATYPE_STRING.equals(dataType)) {
				return false;
			} else {
				return false;
			}
		} else if (LoyaltyConstants.CRITERIA_GREATERANDEQUAL
				.equals(compareCond)) {
			if (LoyaltyConstants.ATTR_DATATYPE_INTEGER.equals(dataType)
					|| LoyaltyConstants.ATTR_DATATYPE_FLOAT.equals(dataType)) {
				double value;
				if (objCompare instanceof Integer)
					value = ((Integer) objCompare).doubleValue();
				else
					value = ((Double) objCompare).doubleValue();
				double curr;
				if (objCompareTo.get(0) instanceof Integer)
					curr = ((Integer) objCompareTo.get(0)).doubleValue();
				else
					curr = ((Double) objCompareTo.get(0)).doubleValue();
				if (value >= curr)
					return true;
			} else if (LoyaltyConstants.ATTR_DATATYPE_DATE.equals(dataType)) {
				Date value = (Date) objCompare;
				Date curr = ((Date) objCompareTo.get(0));
				if (value.compareTo(curr) >= 0)
					return true;
			} else if (LoyaltyConstants.ATTR_DATATYPE_STRING.equals(dataType)) {
				return false;
			} else {
				return false;
			}
		} else if (LoyaltyConstants.CRITERIA_LESS.equals(compareCond)) {
			if (LoyaltyConstants.ATTR_DATATYPE_INTEGER.equals(dataType)
					|| LoyaltyConstants.ATTR_DATATYPE_FLOAT.equals(dataType)) {
				double value;
				if (objCompare instanceof Integer)
					value = ((Integer) objCompare).doubleValue();
				else
					value = ((Double) objCompare).doubleValue();
				double curr;
				if (objCompareTo.get(0) instanceof Integer)
					curr = ((Integer) objCompareTo.get(0)).doubleValue();
				else
					curr = ((Double) objCompareTo.get(0)).doubleValue();
				if (value < curr)
					return true;
			}

			else if (LoyaltyConstants.ATTR_DATATYPE_DATE.equals(dataType)) {
				Date value = (Date) objCompare;
				Date curr = ((Date) objCompareTo.get(0));
				if (value.compareTo(curr) < 0)
					return true;
			} else if (LoyaltyConstants.ATTR_DATATYPE_STRING.equals(dataType)) {
				return false;
			} else {
				return false;
			}
		} else if (LoyaltyConstants.CRITERIA_LESSANDEQUAL.equals(compareCond)) {
			if (LoyaltyConstants.ATTR_DATATYPE_INTEGER.equals(dataType)
					|| LoyaltyConstants.ATTR_DATATYPE_FLOAT.equals(dataType)) {

				double value;
				if (objCompare instanceof Integer)
					value = ((Integer) objCompare).doubleValue();
				else
					value = ((Double) objCompare).doubleValue();
				double curr;
				if (objCompareTo.get(0) instanceof Integer)
					curr = ((Integer) objCompareTo.get(0)).doubleValue();
				else
					curr = ((Double) objCompareTo.get(0)).doubleValue();
				if (value <= curr)
					return true;
			}

			else if (LoyaltyConstants.ATTR_DATATYPE_DATE.equals(dataType)) {
				Date value = (Date) objCompare;
				Date curr = ((Date) objCompareTo.get(0));
				if (value.compareTo(curr) <= 0)
					return true;
			} else if (LoyaltyConstants.ATTR_DATATYPE_STRING.equals(dataType)) {
				return false;
			} else {
				return false;
			}
		} else {
			return false;
		}
		return false;
	}

	/**
	 * @Title: checkInclude
	 * @Description: ����������ʵ��
	 * @param
	 * @return
	 * @return boolean
	 * @throws
	 */
	private boolean checkInclude() {
		
		// ȡ�ñȽ�����
		if (c.getCompareAttr() == null) return false;
		if (c.getValues() == null || c.getValues().isEmpty()) return false;
		
		String table = c.getCompareAttr().getTableName();
		String col = c.getCompareAttr().getFieldName();
		
		// ȡ�ñȽ�ֵ
		StringBuffer sbInclude = new StringBuffer();
		for (ValueInfo v : c.getValues()) {
			sbInclude.append(",'").append(v.getValue()).append("'");
		}
		sbInclude.deleteCharAt(0);

		StringBuffer sb = new StringBuffer();
		sb.append(" Select ");
		sb.append(" count(*) " + AttributeKey);
		sb.append(" From ");
		sb.append(" " + LoyaltyConstants.DB_ORDER_TABLE + " B left join "
				+ table + " A");
		sb.append(" on");
		sb.append(" b." + LoyaltyConstants.DB_ORDER_PK + "=" + "A."
				+ LoyaltyConstants.DB_ORDER_FK);
		sb.append(" where B." + LoyaltyConstants.DB_ORDER_PK + "='"
				+ ctx.getOrderId() + "'");
		sb.append(" and A." + col + " in ( " + sbInclude.toString() + " )");

		PromotionService db = PromotionService.getInstance();
		// �������� Integer
		HashMap<String, Integer> map = (HashMap<String, Integer>) db
				.selectForInteger(sb.toString());
		if (map == null || map.size() == 0)
			return false;
		if ((Integer) map.get(AttributeKey).intValue() > 0)
			return true;
		else
			return false;
	}

	/**
	 * һ���ǿͻ�������
	 * 
	 * @return
	 */
	/*
	 * (non-Javadoc) <p>Title: checkCriteria</p> <p>Description: ����һ������</p>
	 * @return
	 * 
	 * @see com.loyalty.core.Criteria#checkCriteria()
	 */

	public boolean checkCriteria() {
		try {
//add start 2014/05/19 xuning
//			String criteriaValueName = c.getValues().get(0).getValue();
//			if(!(criteriaValueName.equals(ctx.getTierName()) && (ctx.getPromotionType().equals(LoyaltyConstants.PROMOTION_TYPE_BONUS)) || ctx.getPromotionType().equals(LoyaltyConstants.PROMOTION_TYPE_TIER) 
//					|| (!ctx.getPromotionType().equals(LoyaltyConstants.PROMOTION_TYPE_BONUS)) && !ctx.getPromotionType().equals(LoyaltyConstants.PROMOTION_TYPE_TIER))){
//				return false;
//			}
//add end 2014/05/19 xuning					
			// ����IdΪ�գ�
			if (c.getAttr() == null) {
				String compare_cond = (String) c.getCompareMode();
				// ���յ��£�
				if (LoyaltyConstants.CRITERIA_BIRTHMONTH.equals(compare_cond)) {
					Date useBorn = getUseBorn(ctx.getCustomerId());
					return isMonth(useBorn);
				}
				// ���յ��ܣ�
				else if (LoyaltyConstants.CRITERIA_BIRTHWEEK
						.equals(compare_cond)) {
					Date useBorn = getUseBorn(ctx.getCustomerId());
					return isWeek(useBorn);
				}
				// ���յ��죿
				else if (LoyaltyConstants.CRITERIA_BIRTHDAY
						.equals(compare_cond)) {
					Date useBorn = getUseBorn(ctx.getCustomerId());
					return isDay(useBorn);
				} else if (LoyaltyConstants.CRITERIA_INCLUDECOUPON
						.equals(compare_cond)) {
					return checkInclude();
				} else {
					return false;
				}
			} else {
				return compareAttr();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return false;
	}

	/**
	 * @Title: makeCompareValue
	 * @Description: �õ�һ�����ԱȽϵ�����ֵ
	 * @param
	 * @param list
	 * @param
	 * @return
	 * @return List<Object>
	 * @throws
	 */
	private List<Object> makeCompareValue(List<ValueInfo> values) {
		List<Object> result = new ArrayList<Object>();
		
		for (ValueInfo v : values) {
			
			if (LoyaltyConstants.ATTR_DATATYPE_INTEGER.equals(attrDataType)
					|| LoyaltyConstants.ATTR_DATATYPE_FLOAT
							.equals(attrDataType)) {

				if (StringUtil.isEmpty(v.getValue())) return null;
				else result.add(Double.valueOf(v.getValue()));
				
			} else if (LoyaltyConstants.ATTR_DATATYPE_DATE.equals(attrDataType)) {
				if (StringUtil.isEmpty(v.getValue()))
					return null;
				else {
					Date date = DateUtil.parseStringToDate(v.getValue());
					result.add(date);
				}
			} else if (LoyaltyConstants.ATTR_DATATYPE_STRING
					.equals(attrDataType)) {
				if (StringUtil.isEmpty(v.getValue()))
					return null;
				else
					result.add(v.getValue());
			} else {
				return null;
			}
		}
		return result;
	}

}
