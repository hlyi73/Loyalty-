package com.loyalty.action.sub;

import java.util.Date;
import java.util.List;

import org.apache.log4j.Logger;

import com.loyalty.action.AbstractAction;
import com.loyalty.dto.MMember;
import com.loyalty.dto.MPoints;
import com.loyalty.dto.MPointsHis;
import com.loyalty.exception.action.LoyaltyActionException;
import com.loyalty.generator.PrimaryKeyGenerator;
import com.loyalty.service.ActionService;
import com.loyalty.util.CalendarUtil;
import com.loyalty.util.ObjectUtil;

/**
 * ���»�Ա��Ч��
 * 
 * @author Administrator
 * 
 */
public class UpdateMemberPeriodAct extends AbstractAction {
	static Logger logger = Logger.getLogger(UpdateMemberPeriodAct.class
			.getName());

	public UpdateMemberPeriodAct() {

	}

	public void update(MMember present, Date start, Date end) throws Exception {

		if (null == present || null == start || null == end) {
			throw new LoyaltyActionException("���»�Ա��Ч��:" + "����:<present:"
					+ present + ",start:" + start + ",end:" + end + ">");
		}

		List<MPoints> presentPoints = as.findPointsByMemberId(present.getID());

		present.setSTART_DATE(start);
		present.setEND_DATE(end);

		// ���»�Ա��Ϣ
		as.getMacDao().updateByPrimaryKey(present);

		// ���»���
		logger.info("\n" + "���»��֣����ӻ�����ʷ:<��Աid:" + ObjectUtil.toString(present)
				+ ">");
		for (MPoints point : presentPoints) {
			// ����������ʷ
			MPointsHis newPointHis = new MPointsHis();
			newPointHis.setID(PrimaryKeyGenerator.getInstance().generate());
			newPointHis.setSTART_DATE(present.getSTART_DATE());
			newPointHis.setEND_DATE(present.getEND_DATE());
			newPointHis.setPOINTS_TYPE_ID(point.getPOINT_TYPE_ID());
			newPointHis.setMEMBER_ID(present.getID());
			newPointHis.setTOTAL_POINTS(point.getTOTAL_POINTS());
			newPointHis.setMEMBER_PERIOD(point.getMEMBER_PERIOD());
			// ���û��ּ�¼
			point.setVALID_POINTS(0);
			point.setFOZEN_POINTS(0);
			point.setUPDATE_TIME(CalendarUtil.getCurrentDate());
			// �������ݿ�
			as.updatePointsAndInsertPointsHis(point, newPointHis);
		}
	}
}
