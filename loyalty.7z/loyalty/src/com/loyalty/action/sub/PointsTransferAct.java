package com.loyalty.action.sub;

import java.util.Date;
import com.loyalty.action.AbstractAction;
import com.loyalty.dto.MPoints;
import com.loyalty.enums.MessageEnums;
import com.loyalty.generator.PrimaryKeyGenerator;
import com.loyalty.message.Message;
import com.loyalty.message.PointsTransferMessage;
import com.loyalty.util.CalendarUtil;
import com.loyalty.util.NumberUtils;
import com.loyalty.util.ObjectUtil;
import com.loyalty.util.StringUtil;

/**
 * ����ת��
 * 
 * @author Administrator
 * 
 */
public class PointsTransferAct extends AbstractAction {

	private PointsDetailsRecordAct pdra;

	public PointsTransferAct() {
		pdra = (PointsDetailsRecordAct) (ObjectUtil
				.getAction(PointsDetailsRecordAct.class));
	}

	public Message process(String fromMemId, String toMemId,
			String pointTypeId, Integer transPoints, Date sysDate)
			throws Exception {

		Message msg = new PointsTransferMessage();

		if (StringUtil.nullToWhiteStr(fromMemId).length() == 0) {
			msg.setSuccess(false);
			msg
					.setMsgCode(MessageEnums.SOURCE_POINT_NOT_ASSIGNED_SOURCE_MEMBER);
			msg.setDoInfo("Haven't assigned the source member.");
			return msg;
		}
		if (StringUtil.nullToWhiteStr(toMemId).length() == 0) {
			msg.setSuccess(false);
			msg.setMsgCode(MessageEnums.SOURCE_POINT_NOT_ASSIGNED_AIM_MEMBER);
			msg.setDoInfo("Haven't assigned the aim member.");
			return msg;
		}

		if (StringUtil.nullToWhiteStr(fromMemId).equals(
				StringUtil.nullToWhiteStr(toMemId))) {
			msg.setSuccess(false);
			msg.setMsgCode(MessageEnums.SOURCE_POINT_SELF);
			msg.setDoInfo("Can't transfer points to self.");
			return msg;
		}
		if (StringUtil.nullToWhiteStr(pointTypeId).length() == 0) {
			msg.setSuccess(false);
			msg.setMsgCode(MessageEnums.SOURCE_POINT_NOT_ASSIGNED_POINT_TYPE);
			msg.setDoInfo("Don't assigned the type of point.");
			return msg;
		}

		MPoints fromPoint = as.getMPointsByPointTypeIdAndMemberId(pointTypeId,
				fromMemId);
		MPoints toPoint = as.getMPointsByPointTypeIdAndMemberId(pointTypeId,
				toMemId);
		if (null == fromPoint) {
			msg.setSuccess(false);
			msg.setDoInfo("failure:The points of source are not exist.");
			msg.setMsgCode(MessageEnums.SOURCE_POINT_NOT_EXIST);
			return msg;
		}
		if (NumberUtils.nullToZero(fromPoint.getVALID_POINTS()) < transPoints) {
			msg.setSuccess(false);
			msg.setDoInfo("failure:The points of source are not enough.");
			msg.setMsgCode(MessageEnums.SOURCE_POINT_NOT_ENOUGH);
			return msg;
		}

		if (null == toPoint) {
			toPoint = new MPoints();
			toPoint.setID(PrimaryKeyGenerator.getInstance().generate());
			toPoint.setFOZEN_POINTS(0);
			toPoint.setLAST_BALANCE(0);
			toPoint.setLIFETIME_POINTS(0);
			toPoint.setLIFETIME_VALID_POINTS(0);
			toPoint.setMEMBER_PERIOD(CalendarUtil.getMemberPeriod(toMemId));
			toPoint.setMEMBER_ID(toMemId);
			toPoint.setPOINT_TYPE_ID(pointTypeId);
			toPoint.setTOTAL_POINTS(0);
			toPoint.setVALID_POINTS(0);

			as.getMacDao().insert(toPoint);
		}
		// ���ֵ���
		fromPoint.setVALID_POINTS(NumberUtils.nullToZero(fromPoint
				.getVALID_POINTS())
				- transPoints);
		fromPoint.setLIFETIME_VALID_POINTS(NumberUtils.nullToZero(fromPoint
				.getVALID_POINTS())
				+ NumberUtils.nullToZero(fromPoint.getLAST_BALANCE()));

		toPoint.setVALID_POINTS(NumberUtils.nullToZero(toPoint
				.getVALID_POINTS())
				+ transPoints);
		toPoint.setTOTAL_POINTS(NumberUtils.nullToZero(toPoint
				.getTOTAL_POINTS())
				+ transPoints);
		toPoint.setLIFETIME_VALID_POINTS(NumberUtils.nullToZero(toPoint
				.getVALID_POINTS())
				+ NumberUtils.nullToZero(toPoint.getLAST_BALANCE()));
		toPoint.setLIFETIME_POINTS(NumberUtils.nullToZero(toPoint
				.getLIFETIME_POINTS())
				+ transPoints);
		toPoint.setUPDATE_TIME(CalendarUtil.getCurrentDate());
		fromPoint.setUPDATE_TIME(CalendarUtil.getCurrentDate());
		as.getMacDao().updateByPrimaryKey(fromPoint);
		as.getMacDao().updateByPrimaryKey(toPoint);

		// ����ϸ
		pdra.recordPointTypeAfterReducePoints(pointTypeId, fromMemId,
				-transPoints, "M_TRANSFER", sysDate);
		pdra.recordPointTypeAfterIncreasePoints(pointTypeId, toMemId,
				transPoints, "M_TRANSFER", sysDate);

		msg.setSuccess(true);
		msg.setMsgCode(MessageEnums.SOURCE_POINT_SUCCESS);
		msg.setDoInfo("Success to transfer " + transPoints + " points.");
		return msg;
	}
}
