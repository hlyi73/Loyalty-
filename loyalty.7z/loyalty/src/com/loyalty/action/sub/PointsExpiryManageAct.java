package com.loyalty.action.sub;

import java.util.Date;
import java.util.List;
import com.loyalty.util.CalendarUtil;
import com.loyalty.util.NumberUtils;
import com.loyalty.util.StringUtil;

import org.apache.log4j.Logger;
import com.loyalty.action.AbstractAction;
import com.loyalty.dto.MPointList;
import com.loyalty.dto.MPoints;
import com.loyalty.dto.MPointsHis;
import com.loyalty.message.ExpiryDataHandlerMessage;
import com.loyalty.message.Message;
import com.loyalty.enums.LoyaltyActionEnums;
import com.loyalty.generator.PrimaryKeyGenerator;

/**
 * ���ֵ���<��ʱ����>
 * 
 */
public class PointsExpiryManageAct extends AbstractAction {
	static Logger logger = Logger.getLogger(PointsExpiryManageAct.class);

	public Message process(String id, String date) throws Exception {
		ExpiryDataHandlerMessage message = new ExpiryDataHandlerMessage();
		MPointList expiryPointList = new MPointList();
		Date sysDate = CalendarUtil.convertStringToDate(date);
		expiryPointList.setID(id);
		expiryPointList = (MPointList) as.getMacDao().selectByPrimaryKey(
				expiryPointList);
		// ���һ���
		MPoints currentTimePoints = as.findAdjustedPoints(expiryPointList
				.getMEMBER_ID(), expiryPointList.getPOINT_TYPE_ID(),
				expiryPointList.getMEMBER_PERIOD());

		String pointListMPeriod = StringUtil.nullToWhiteStr(expiryPointList
				.getMEMBER_PERIOD());
		String mPeriod = StringUtil.nullToWhiteStr(CalendarUtil
				.getMemberPeriod(StringUtil.nullToWhiteStr(expiryPointList
						.getMEMBER_ID())));

		Boolean isLastPeriod = false;
		if (!pointListMPeriod.equals(mPeriod)) {
			isLastPeriod = true;
			currentTimePoints = as.getMPointsByPointTypeIdAndMemberId(
					expiryPointList.getPOINT_TYPE_ID(), expiryPointList
							.getMEMBER_ID());
		}
		// ������û���
		Integer adjustPoints = (NumberUtils.nullToZero(expiryPointList
				.getPOINTS()) - NumberUtils.nullToZero(expiryPointList
				.getUSED_VALUE()));

		// ����Ǳ���,��۱��ڿ��û���
		if (!isLastPeriod) {
			currentTimePoints.setVALID_POINTS(NumberUtils
					.nullToZero(currentTimePoints.getVALID_POINTS())
					- adjustPoints);
		} else {
			// ���������,�������ʣ��
			currentTimePoints.setLAST_BALANCE(NumberUtils
					.nullToZero(currentTimePoints.getLAST_BALANCE())
					- adjustPoints);
		}
		currentTimePoints.setLIFETIME_VALID_POINTS(NumberUtils
				.nullToZero(currentTimePoints.getLIFETIME_VALID_POINTS())
				- adjustPoints);
		expiryPointList
				.setPROCESS_FLAG(LoyaltyActionEnums.POINT_LIST_STATUS_HANDLER_SUCCESS);

		currentTimePoints.setUPDATE_TIME(CalendarUtil.getCurrentDate());
		// �������ݿ����
		as.updatePointsAndPointList(currentTimePoints, expiryPointList);
		return message;
	}
}
