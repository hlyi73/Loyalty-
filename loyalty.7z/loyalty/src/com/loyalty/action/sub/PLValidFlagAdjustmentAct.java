package com.loyalty.action.sub;

import com.loyalty.action.AbstractAction;
import com.loyalty.dto.MMember;
import com.loyalty.dto.MPointList;
import com.loyalty.dto.MPoints;
import com.loyalty.dto.MPointsHis;
import com.loyalty.generator.PrimaryKeyGenerator;
import com.loyalty.util.CalendarUtil;
import com.loyalty.util.LoyaltyConstants;
import com.loyalty.util.NumberUtils;
import com.loyalty.util.ObjectUtil;
import com.loyalty.util.StringUtil;

/**
 * ������ϸvalidFlag����<��ʱ����>
 * 
 * @author Administrator
 * 
 */
public class PLValidFlagAdjustmentAct extends AbstractAction {

	private ChangePointAct cpa = null;

	public PLValidFlagAdjustmentAct() {
		cpa = (ChangePointAct) ObjectUtil.getAction(ChangePointAct.class);
	}

	public void process(String id) throws Exception {
		if (StringUtil.nullToWhiteStr(id).length() == 0) {
			throw new Exception("������ϸvalidFlag����:" + "id is null.");
		}
		MPointList record = new MPointList();
		record.setID(id);
		record = (MPointList) as.getMacDao().selectByPrimaryKey(record);

		// ����û�Ա���ڷǻ״̬,���˳�����

		if (null == record) {
			throw new Exception("������ϸvalidFlag����:" + "MPointList<" + id
					+ "> is not exist.");
		}
		String pointListMPeriod = StringUtil.nullToWhiteStr(record
				.getMEMBER_PERIOD());
		String mPeriod = StringUtil.nullToWhiteStr(CalendarUtil
				.getMemberPeriod(StringUtil.nullToWhiteStr(record
						.getMEMBER_ID())));
		// ����
		if (pointListMPeriod.equals(mPeriod)) {
			cpa.adjustPoints(record.getPOINT_TYPE_ID(), record.getMEMBER_ID(),
					record.getPOINTS());
			// ����
		} else {
			MPointsHis his = as.findMPointsHisByMIdAndPidAndMPeriod(record
					.getMEMBER_ID(), record.getPOINT_TYPE_ID(), record
					.getMEMBER_PERIOD()); // ���һ�����ʷ��
			MMember m = new MMember();
			m.setID(record.getMEMBER_ID());
			m = (MMember) as.getMacDao().selectByPrimaryKey(m);
			if (null == his) {
				his = new MPointsHis();
				his.setID(PrimaryKeyGenerator.getInstance().generate());
				his.setMEMBER_ID(record.getMEMBER_ID());
				his.setPOINTS_TYPE_ID(record.getPOINT_TYPE_ID());
				his.setSTART_DATE(m.getSTART_DATE());
				his.setEND_DATE(m.getEND_DATE());
				his.setTOTAL_POINTS(NumberUtils.nullToZero(his
						.getTOTAL_POINTS())
						+ NumberUtils.nullToZero(record.getPOINTS()));
				his.setPOINTS(NumberUtils.nullToZero(his.getPOINTS())
						+ NumberUtils.nullToZero(record.getPOINTS()));
				his.setMEMBER_PERIOD(record.getMEMBER_PERIOD());
				as.getMacDao().insert(his);
			} else {
				his.setMEMBER_ID(record.getMEMBER_ID());
				his.setSTART_DATE(m.getSTART_DATE());
				his.setEND_DATE(m.getEND_DATE());
				his.setTOTAL_POINTS(NumberUtils.nullToZero(his
						.getTOTAL_POINTS())
						+ NumberUtils.nullToZero(record.getPOINTS()));
				his.setPOINTS(NumberUtils.nullToZero(his.getPOINTS())
						+ NumberUtils.nullToZero(record.getPOINTS()));
				as.getMacDao().updateByPrimaryKey(his);
			}

			// �޸ı��ڵ��������
			MPoints mps = as.getMPointsByPointTypeIdAndMemberId(StringUtil
					.nullToWhiteStr(record.getPOINT_TYPE_ID()), StringUtil
					.nullToWhiteStr(record.getMEMBER_ID()));
			if (null == mps) {
				mps = new MPoints();
				mps.setID(PrimaryKeyGenerator.getInstance().generate());
				mps.setPOINT_TYPE_ID(record.getPOINT_TYPE_ID());
				mps.setMEMBER_ID(record.getMEMBER_ID());
				mps.setTOTAL_POINTS(0);
				mps.setVALID_POINTS(0);
				mps.setFOZEN_POINTS(0);
				mps.setLIFETIME_POINTS(NumberUtils.nullToZero(mps
						.getLIFETIME_POINTS())
						+ NumberUtils.nullToZero(record.getPOINTS()));
				mps.setLAST_BALANCE(NumberUtils.nullToZero(mps
						.getLAST_BALANCE())
						+ NumberUtils.nullToZero(record.getPOINTS()));
				mps.setLIFETIME_VALID_POINTS(NumberUtils.nullToZero(mps
						.getVALID_POINTS())
						+ NumberUtils.nullToZero(mps.getLAST_BALANCE()));
				mps.setMEMBER_PERIOD(mPeriod);
				mps.setUPDATE_TIME(CalendarUtil.getCurrentDate());
				as.getMacDao().insert(mps);
			} else {
				mps.setLIFETIME_POINTS(NumberUtils.nullToZero(mps
						.getLIFETIME_POINTS())
						+ NumberUtils.nullToZero(record.getPOINTS()));
				mps.setLAST_BALANCE(NumberUtils.nullToZero(mps
						.getLAST_BALANCE())
						+ NumberUtils.nullToZero(record.getPOINTS()));
				mps.setLIFETIME_VALID_POINTS(NumberUtils.nullToZero(mps
						.getVALID_POINTS())
						+ NumberUtils.nullToZero(mps.getLAST_BALANCE()));
				mps.setMEMBER_PERIOD(mPeriod);
				mps.setUPDATE_TIME(CalendarUtil.getCurrentDate());
				as.getMacDao().updateByPrimaryKey(mps);
			}
		}
		// �Ի��ֱ��ӷ�
		record.setVALID_FLAG(LoyaltyConstants.LOYALTY_ACTIVE);
		// ���»�����ϸ��״̬
		as.getMacDao().updateByPrimaryKey(record);
	}
}
