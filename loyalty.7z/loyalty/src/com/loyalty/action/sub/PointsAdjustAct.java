package com.loyalty.action.sub;

import java.util.Date;

import com.loyalty.action.AbstractAction;
import com.loyalty.dto.MPoints;
import com.loyalty.enums.MessageEnums;
import com.loyalty.generator.PrimaryKeyGenerator;
import com.loyalty.message.Message;
import com.loyalty.message.PointsAdjustMessage;
import com.loyalty.message.PointsTransferMessage;
import com.loyalty.util.CalendarUtil;
import com.loyalty.util.NumberUtils;
import com.loyalty.util.ObjectUtil;
import com.loyalty.util.StringUtil;

public class PointsAdjustAct extends AbstractAction {

	private PointsDetailsRecordAct pdra;

	public PointsAdjustAct() {
		pdra = (PointsDetailsRecordAct) (ObjectUtil
				.getAction(PointsDetailsRecordAct.class));
	}

	public Message process(String memberId, String pointTypeId,
			Integer adjustPoints, String operate, Date sysDate)
			throws Exception {
		Message msg = new PointsAdjustMessage();

		memberId = StringUtil.nullToWhiteStr(memberId);
		if (memberId.length() == 0) {
			msg.setSuccess(false);
			msg.setDoInfo("��������ʧ�� : Member id is null.");
			msg.setMsgCode(MessageEnums.ADJUST_POINT_NOT_ASSIGNED_MEMBER);
			return msg;
		}

		pointTypeId = StringUtil.nullToWhiteStr(pointTypeId);
		if (pointTypeId.length() == 0) {
			msg.setSuccess(false);
			msg.setDoInfo("��������ʧ�� : pointTypeId is null.");
			msg.setMsgCode(MessageEnums.ADJUST_POINT_NOT_ASSIGNED_POINT_TYPE);
			return msg;
		}

		operate = StringUtil.nullToWhiteStr(operate);
		if (operate.length() == 0) {
			msg.setSuccess(false);
			msg.setDoInfo("��������ʧ�� : operate is null.");
			msg.setMsgCode(MessageEnums.ADJUST_POINT_NOT_ASSIGNED_OPERATE);
			return msg;
		}

		adjustPoints = NumberUtils.nullToZero(adjustPoints);
		if (0 == adjustPoints && !operate.equals("M_PURGE")) {
			msg.setSuccess(false);
			msg.setDoInfo("��������ʧ�� : adjustPoints is zero.");
			msg.setMsgCode(MessageEnums.ADJUST_POINT_NOT_ASSIGNED_POINT_NUM);
			return msg;
		}

		MPoints points = as.getMPointsByPointTypeIdAndMemberId(pointTypeId,
				memberId);

		if (operate.equals("M_PLUS")) {
			// MPoints ����Ϊnull
			if (null == points) {
				points = new MPoints();
				points.setID(PrimaryKeyGenerator.getInstance().generate());
				points.setMEMBER_ID(memberId);
				points.setMEMBER_PERIOD(CalendarUtil.getMemberPeriod(memberId));
				points.setPOINT_TYPE_ID(pointTypeId);
				points.setTOTAL_POINTS(0);
				points.setVALID_POINTS(0);
				points.setFOZEN_POINTS(0);
				points.setLAST_BALANCE(0);
				points.setLIFETIME_POINTS(0);
				points.setLIFETIME_VALID_POINTS(0);
				points.setUPDATE_TIME(CalendarUtil.getCurrentDate());
				as.getMacDao().insert(points);
			}
			points.setVALID_POINTS(NumberUtils.nullToZero(points
					.getVALID_POINTS())
					+ adjustPoints);
			points.setTOTAL_POINTS(NumberUtils.nullToZero(points
					.getTOTAL_POINTS())
					+ adjustPoints);
			points.setLIFETIME_VALID_POINTS(NumberUtils.nullToZero(points
					.getVALID_POINTS())
					+ NumberUtils.nullToZero(points.getLAST_BALANCE()));
			points.setLIFETIME_POINTS(NumberUtils.nullToZero(points
					.getLIFETIME_POINTS())
					+ adjustPoints);
			points.setUPDATE_TIME(CalendarUtil.getCurrentDate());
			as.getMacDao().updateByPrimaryKey(points);
			pdra.recordPointTypeAfterIncreasePoints(pointTypeId, memberId,
					adjustPoints, "M_ADJUST", sysDate);
		} else if (operate.equals("M_SUBTRACT")) {
			if (null == points) {
				msg.setSuccess(false);
				msg.setDoInfo("��������ʧ�� : MPoints is not exist.");
				msg.setMsgCode(MessageEnums.ADJUST_POINT_MPOINT_NOT_EXIST);
				return msg;
			}
			if (NumberUtils.nullToZero(points.getVALID_POINTS()) < adjustPoints) {
				msg.setSuccess(false);
				msg.setDoInfo("��������ʧ�� : Balance is not enough.");
				msg.setMsgCode(MessageEnums.ADJUST_POINT_MPOINT_NOT_ENOUGH);
				return msg;
			}

			points.setVALID_POINTS(NumberUtils.nullToZero(points
					.getVALID_POINTS())
					- adjustPoints);
			points.setLIFETIME_VALID_POINTS(NumberUtils.nullToZero(points
					.getVALID_POINTS())
					+ NumberUtils.nullToZero(points.getLAST_BALANCE()));
			points.setUPDATE_TIME(CalendarUtil.getCurrentDate());
			as.getMacDao().updateByPrimaryKey(points);
			pdra.recordPointTypeAfterReducePoints(pointTypeId, memberId,
					-adjustPoints, "M_ADJUST", sysDate);
		} else if (operate.equals("M_PURGE")) {
			Integer vP = points.getVALID_POINTS();
			points.setVALID_POINTS(0);
			points.setLIFETIME_VALID_POINTS(NumberUtils.nullToZero(points
					.getVALID_POINTS())
					+ NumberUtils.nullToZero(points.getLAST_BALANCE()));
			points.setUPDATE_TIME(CalendarUtil.getCurrentDate());
			as.getMacDao().updateByPrimaryKey(points);
			pdra.recordPointTypeAfterReducePoints(pointTypeId, memberId, -vP,
					"M_ADJUST", sysDate);
		}

		msg.setSuccess(true);
		msg.setMsgCode(MessageEnums.ADJUST_POINT_SUCCESS);
		return msg;
	}
}
