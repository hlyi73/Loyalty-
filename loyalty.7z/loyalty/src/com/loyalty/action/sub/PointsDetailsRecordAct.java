package com.loyalty.action.sub;

import java.util.Date;
import java.util.List;
import com.ibatis.dao.client.DaoManager;
import com.loyalty.action.AbstractAction;
import com.loyalty.dto.MLoyOrder;
import com.loyalty.dto.MMember;
import com.loyalty.dto.MPointList;
import com.loyalty.dto.MPointType;
import com.loyalty.dto.MPromotion;
import com.loyalty.enums.LoyaltyActionEnums;
import com.loyalty.exception.PointRecordException;
import com.loyalty.generator.PrimaryKeyGenerator;
import com.loyalty.service.ActionService;
import com.loyalty.util.CalendarUtil;
import com.loyalty.util.LoyaltyConstants;
import com.loyalty.util.NumberUtils;
import com.loyalty.util.StringUtil;

public class PointsDetailsRecordAct extends AbstractAction {

	public PointsDetailsRecordAct() {

	}

	/**
	 * ���ӻ���֮�����ϸ
	 * 
	 * @param pointTypeId
	 * @param memberId
	 * @param adjustedPoint
	 * @param promotionType
	 * @param sysDate
	 * @throws Exception
	 */
	public void recordPointTypeAfterIncreasePoints(String pointTypeId,
			String memberId, Integer adjustedPoint, String promotionId,
			String orderId, Integer validFlag, Date sysDate) throws Exception {
		if (StringUtil.nullToWhiteStr(memberId).length() == 0) {
			throw new PointRecordException("���ӻ�����ϸ�쳣:" + "memberId is null.");
		}
		if (StringUtil.nullToWhiteStr(pointTypeId).length() == 0) {
			throw new PointRecordException("���ӻ�����ϸ�쳣:" + "pointTypeId is null.");
		}
		MPointType pointType = as.findMPointTypeById(pointTypeId);
		if (null == pointType) {
			throw new PointRecordException("���ӻ�����ϸ�쳣:" + "pointType<"
					+ pointTypeId + "> is null.");
		}
		MPromotion promotion = null;
		if (StringUtil.nullToWhiteStr(promotionId).length() != 0) {
			promotion = as.getMPromotionByPromotionId(promotionId);
		}
		MLoyOrder loyOrder = null;
		if (StringUtil.nullToWhiteStr(orderId).length() != 0) {
			loyOrder = as.getMLoyOrderByOrderId(orderId);
		}
		Date valid = calValid(pointType, memberId, sysDate);

		if (null == valid) {
			throw new PointRecordException("���ӻ�����ϸ�쳣:"
					+ "failed to get valid date.");
		}
		Integer freezeDays = pointType.getFREEZE_DAY();
		freezeDays = (freezeDays == null || freezeDays == 0) ? 0 : freezeDays;

		MPointList pointList = new MPointList();
		pointList.setID(PrimaryKeyGenerator.getInstance().generate());
		pointList.setMEMBER_ID(memberId);
		pointList.setORDER_ID(orderId);
		pointList.setPOINT_TYPE_ID(pointTypeId);
		pointList.setPOINTS(adjustedPoint);
		pointList.setUSED_VALUE(0);
		pointList
				.setPROCESS_FLAG(LoyaltyActionEnums.POINT_LIST_STATUS_HANDLER_POINTLIST_DO_NOTHING);
		if (null != promotion) {
			pointList.setPROMOTION_NAME(promotion.getNAME());
			pointList.setPROMOTION_TYPE(promotion.getTYPE());
		}
		pointList.setBORN_DATE(sysDate);
		// ��ʼ���ڼ��϶���ʱ��
		pointList.setSTART_DATE(CalendarUtil.dateToSpecifiedFormat(CalendarUtil
				.increaseTimeByDay(sysDate, freezeDays)));
		pointList.setEND_DATE(CalendarUtil.dateToSpecifiedFormat(valid));
		if (null != loyOrder) {
			pointList.setMEMBER_CARD(loyOrder.getMEMBER_CARD());
		}
		pointList.setMEMBER_PERIOD(CalendarUtil.getMemberPeriod(memberId));
		pointList.setVALID_FLAG(validFlag);
		as.appendNewMPointList(pointList);
	}

	//add start 2014/05/16 hansheng
	/**
	 * �ͷ�ҵ�����
	 */
	public void recordPointTypeAfterIncreasePoints(String pointTypeId,
			String memberId, Integer adjustedPoint, String promotionId,
			String orderId, Integer validFlag, Date sysDate,String p1, String p2) throws Exception {
		if (StringUtil.nullToWhiteStr(memberId).length() == 0) {
			throw new PointRecordException("���ӻ�����ϸ�쳣:" + "memberId is null.");
		}
		if (StringUtil.nullToWhiteStr(pointTypeId).length() == 0) {
			throw new PointRecordException("���ӻ�����ϸ�쳣:" + "pointTypeId is null.");
		}
		MPointType pointType = as.findMPointTypeById(pointTypeId);
		if (null == pointType) {
			throw new PointRecordException("���ӻ�����ϸ�쳣:" + "pointType<"
					+ pointTypeId + "> is null.");
		}
		MPromotion promotion = null;
		if (StringUtil.nullToWhiteStr(promotionId).length() != 0) {
			promotion = as.getMPromotionByPromotionId(promotionId);
		}
		MLoyOrder loyOrder = null;
		if (StringUtil.nullToWhiteStr(orderId).length() != 0) {
			loyOrder = as.getMLoyOrderByOrderId(orderId);
		}
		Date valid = calValid(pointType, memberId, sysDate);

		if (null == valid) {
			throw new PointRecordException("���ӻ�����ϸ�쳣:"
					+ "failed to get valid date.");
		}
		Integer freezeDays = pointType.getFREEZE_DAY();
		freezeDays = (freezeDays == null || freezeDays == 0) ? 0 : freezeDays;

		MPointList pointList = new MPointList();
		pointList.setID(PrimaryKeyGenerator.getInstance().generate());
		pointList.setMEMBER_ID(memberId);
		pointList.setORDER_ID(orderId);
		pointList.setPOINT_TYPE_ID(pointTypeId);
		pointList.setPOINTS(adjustedPoint);
		pointList.setUSED_VALUE(0);
		pointList
				.setPROCESS_FLAG(LoyaltyActionEnums.POINT_LIST_STATUS_HANDLER_POINTLIST_DO_NOTHING);
		if (null != promotion) {
			pointList.setPROMOTION_NAME(promotion.getNAME());
			pointList.setPROMOTION_TYPE(promotion.getTYPE());
		}
		pointList.setBORN_DATE(sysDate);
		// ��ʼ���ڼ��϶���ʱ��
		pointList.setSTART_DATE(CalendarUtil.dateToSpecifiedFormat(CalendarUtil
				.increaseTimeByDay(sysDate, freezeDays)));
		pointList.setEND_DATE(CalendarUtil.dateToSpecifiedFormat(valid));
		if (null != loyOrder) {
			pointList.setMEMBER_CARD(loyOrder.getMEMBER_CARD());
		}
		pointList.setMEMBER_PERIOD(CalendarUtil.getMemberPeriod(memberId));
		pointList.setVALID_FLAG(validFlag);

		pointList.setACT_TYPE(p1);
		pointList.setACT_SUB_TYPE(p2);
		as.appendNewMPointList(pointList);
	}

	//add end 2014/05/16 hansheng
	/**
	 * 
	 * ��������֮�����ϸ
	 * 
	 * @param pointTypeId
	 * @param memberId
	 * @param adjustedPoint
	 * @param promotionId
	 * @param orderId
	 * @throws Exception
	 */
	public void recordPointTypeAfterReducePoints(String pointTypeId,
			String memberId, Integer adjustedPoint, String promotionId,
			String orderId, Date sysDate) throws Exception {
		if (StringUtil.nullToWhiteStr(memberId).length() == 0) {
			throw new PointRecordException("��������ϸ�쳣:" + "memberId is null.");
		}
		if (StringUtil.nullToWhiteStr(pointTypeId).length() == 0) {
			throw new PointRecordException("��������ϸ�쳣:" + "pointTypeId is null.");
		}
		if (null == adjustedPoint) {
			throw new PointRecordException("��������ϸ�쳣:"
					+ "adjustedPoint is null.");
		}
		MPointType pointType = as.findMPointTypeById(pointTypeId);
		if (null == pointType) {
			throw new PointRecordException("��������ϸ�쳣:" + "pointType is null.");
		}
		List<MPointList> pointLists = as
				.findPointListsByTypeIdAndMemberIdThanZeroAndValidStatus(
						pointTypeId, memberId);
		// ���ֹ���
		Integer leftPoint = -adjustedPoint;
		for (MPointList p : pointLists) {
			if (p.getPOINTS() <= 0) {
				continue;
			}
			// �жϸû�����ϸ��û�����ڴ���:��:������Ϊ���ֻ���,��:����ѭ��
			if (LoyaltyActionEnums.POINT_LIST_STATUS_HANDLER_POINTLIST_DO_NOTHING == NumberUtils
					.nullToZero(p.getPROCESS_FLAG())) {
				Integer validPoints = NumberUtils.nullToZero(p.getPOINTS())
						- NumberUtils.nullToZero(p.getUSED_VALUE());
				if (NumberUtils.nullToZero(p.getPOINTS()) <= NumberUtils
						.nullToZero(p.getUSED_VALUE())) {
					continue;
				}
				if (validPoints >= leftPoint) {
					p.setUSED_VALUE(NumberUtils.nullToZero(p.getUSED_VALUE())
							+ leftPoint);
					leftPoint = 0;
					as.updatePointList(p);
					break;
				} else {
					p.setUSED_VALUE(NumberUtils.nullToZero(p.getPOINTS()));
					leftPoint -= validPoints;
				}
				as.updatePointList(p);
			}
		}
		if (leftPoint > 0) {
			throw new Exception("���ּ���ϸʧ��:You have not enough point.");
		}
		MPointList append = appendPointList(pointTypeId, memberId,
				(adjustedPoint), promotionId, orderId, sysDate);
		as.appendNewMPointList(append);
	}

	/**
	 * �۷�ҵ�����
	 * ��������֮�����ϸ(���ֶһ���Ʒר��)
	 * ��M_POINT_LIST������p1��p2�Ĳ���
	 * 2014/05/16  ����
	 */
	public void recordPointTypeAfterReducePoints(String pointTypeId,
			String memberId, Integer adjustedPoint, String promotionId,
			String orderId, Date sysDate, String giftName, String p1,
			String p2) throws Exception {
		if (StringUtil.nullToWhiteStr(memberId).length() == 0) {
			throw new PointRecordException("��������ϸ�쳣:" + "memberId is null.");
		}
		if (StringUtil.nullToWhiteStr(pointTypeId).length() == 0) {
			throw new PointRecordException("��������ϸ�쳣:" + "pointTypeId is null.");
		}
		if (null == adjustedPoint) {
			throw new PointRecordException("��������ϸ�쳣:"
					+ "adjustedPoint is null.");
		}
		MPointType pointType = as.findMPointTypeById(pointTypeId);
		if (null == pointType) {
			throw new PointRecordException("��������ϸ�쳣:" + "pointType is null.");
		}
		List<MPointList> pointLists = as
				.findPointListsByTypeIdAndMemberIdThanZeroAndValidStatus(
						pointTypeId, memberId);
		// ���ֹ���
		Integer leftPoint = -adjustedPoint;
		for (MPointList p : pointLists) {
			if (p.getPOINTS() <= 0) {
				continue;
			}
			// �жϸû�����ϸ��û�����ڴ���:��:������Ϊ���ֻ���,��:����ѭ��
			if (LoyaltyActionEnums.POINT_LIST_STATUS_HANDLER_POINTLIST_DO_NOTHING == NumberUtils
					.nullToZero(p.getPROCESS_FLAG())) {
				Integer validPoints = NumberUtils.nullToZero(p.getPOINTS())
						- NumberUtils.nullToZero(p.getUSED_VALUE());
				if (NumberUtils.nullToZero(p.getPOINTS()) <= NumberUtils
						.nullToZero(p.getUSED_VALUE())) {
					continue;
				}
				if (validPoints >= leftPoint) {
					p.setUSED_VALUE(NumberUtils.nullToZero(p.getUSED_VALUE())
							+ leftPoint);
					leftPoint = 0;
					as.updatePointList(p);
					break;
				} else {
					p.setUSED_VALUE(NumberUtils.nullToZero(p.getPOINTS()));
					leftPoint -= validPoints;
				}
				as.updatePointList(p);
			}
		}
		if (leftPoint > 0) {
			throw new Exception("���ּ���ϸʧ��:You have not enough point.");
		}
		MPointList append = appendPointList(pointTypeId, memberId,
				(adjustedPoint), promotionId, orderId, sysDate);
		// ׷����Ʒ����
		append.setCOMMENTS("gift:" + giftName);
		// ���ֲ���׷��
		append.setACT_TYPE(p1);
		append.setACT_SUB_TYPE(p2);
		as.appendNewMPointList(append);
	}
	protected Date calValid(MPointType pointType, String memberId, Date sysDate)
			throws Exception {
		String basis = pointType.getBASIS();
		if (null == basis) {
			return null;
		}
		Date valid = null;
		if (LoyaltyConstants.POINTTYPE_EXPIRE_M_MEMBERPERIOD
				.equalsIgnoreCase(basis)) {
			valid = memberPeriod(memberId, pointType, sysDate);
		} else if (LoyaltyConstants.POINTTYPE_EXPIRE_M_FIXDATE
				.equalsIgnoreCase(basis)) {
			valid = fixDate(pointType, sysDate);
		} else if (LoyaltyConstants.POINTTYPE_EXPIRE_M_PERIOD
				.equalsIgnoreCase(basis)) {
			valid = period(pointType, sysDate);
		}
		return valid;
	}

	// ��Ա��Ч��
	protected Date memberPeriod(String memberId, MPointType pointType,
			Date sysDate) throws Exception {
		MMember member = as.getMMemberByMemberId(memberId);
		Integer period = pointType.getPERIOD();
		String uom = pointType.getUOM();
		Date result = null;
		if (null == member) {
			throw new PointRecordException("��Ա��Ч��:"
					+ "member is null.<memberId:" + memberId + ">");
		}
		result = member.getEND_DATE();
		if (null != period && period != 0) {// ��ֵ���ӳ�,ûֵ�Ͳ��ӳ�
			if (CalendarUtil.isUOMYear(uom)) {
				result = CalendarUtil.increaseTimeByYear(member.getEND_DATE(),
						period);
			} else if (CalendarUtil.isUOMMonth(uom)) {
				result = CalendarUtil.increaseTimeByMonth(member.getEND_DATE(),
						period);
			}
		}
		return result;
	}

	// �ڼ�������
	protected Date period(final MPointType pointType, Date sysDate) {
		Integer period = pointType.getPERIOD();
		String uom = pointType.getUOM();
		Date currDate = CalendarUtil.increaseTimeByDay(sysDate, pointType
				.getFREEZE_DAY());
		Date result = null;
		if (CalendarUtil.isUOMYear(uom)) {
			result = CalendarUtil.increaseTimeByYear(currDate, period);
		} else if (CalendarUtil.isUOMMonth(uom)) {
			result = CalendarUtil.increaseTimeByMonth(currDate, period);
		}
		return result;
	}

	/*
	 * �̶����ڼ���
	 * 
	 * �ڼ䣺 �������� ��fixDate����
	 */
	private Date fixDate(MPointType pointType, Date sysDate) {
		Integer expireMonth = pointType.getEXPIRE_MONTH();
		Integer expireDay = pointType.getEXPIRE_DAY();
		String uom = pointType.getUOM();
		Date currDate = CalendarUtil.increaseTimeByDay(sysDate, pointType
				.getFREEZE_DAY());
		Date result = null;
		if (null != pointType.getPERIOD() && pointType.getPERIOD() != 0) {
			if (CalendarUtil.isUOMYear(uom)) {
				result = CalendarUtil.resetTimeOnMonthAndDay(CalendarUtil
						.increaseTimeByYear(currDate, pointType.getPERIOD()),
						expireMonth, expireDay);
			} else if (CalendarUtil.isUOMMonth(uom)) {
				Date date = CalendarUtil.increaseTimeByMonth(currDate,
						pointType.getPERIOD());
				if (CalendarUtil.isLargerThanSpecifiedMonthDay(date,
						expireMonth, expireDay)) {
					date = CalendarUtil.increaseTimeByYear(date, 1);
				}
				result = CalendarUtil.resetTimeOnMonthAndDay(date, expireMonth,
						expireDay);
			}
		} else {
			result = CalendarUtil.isLargerThanSpecifiedMonthDay(currDate,
					expireMonth, expireDay) ? CalendarUtil
					.resetTimeOnMonthAndDay(CalendarUtil.increaseTimeByYear(
							currDate, 1), expireMonth, expireDay)
					: CalendarUtil.resetTimeOnMonthAndDay(currDate,
							expireMonth, expireDay);
		}
		return result;
	}

	public MPointList appendPointList(String pointTypeId, String memberId,
			Integer adjustedPoint, String promotionId, String orderId,
			Date sysDate) {

		MPromotion promotion = null;
		if (StringUtil.nullToWhiteStr(promotionId).length() != 0) {
			promotion = as.getMPromotionByPromotionId(promotionId);
		}
		MLoyOrder loyOrder = null;
		if (StringUtil.nullToWhiteStr(orderId).length() != 0) {
			loyOrder = as.getMLoyOrderByOrderId(orderId);
		}
		MPointList appendData = new MPointList();
		appendData.setID(PrimaryKeyGenerator.getInstance().generate());
		appendData.setBORN_DATE(sysDate);
		if (null != loyOrder) {
			appendData.setMEMBER_CARD(loyOrder.getMEMBER_CARD());
			appendData.setORDER_ID(orderId);
		}
		if (null != promotion) {
			appendData.setPROMOTION_ID(promotionId);
			appendData.setPROMOTION_NAME(promotion.getNAME());
			appendData.setPROMOTION_TYPE(promotion.getTYPE());
		}

		appendData.setMEMBER_ID(memberId);
		appendData.setPOINT_TYPE_ID(pointTypeId);
		appendData.setPOINTS(adjustedPoint);
		appendData.setMEMBER_PERIOD(CalendarUtil.getMemberPeriod(memberId));
		appendData.setCOMMENTS("");

		return appendData;
	}

	/**
	 * ת�ƻ��ֺ����ϸ
	 * 
	 * @param pointTypeId
	 * @param memberId
	 * @param adjustedPoint
	 * @param validFlag
	 * @param sysDate
	 * @throws Exception
	 */
	public void recordPointTypeAfterIncreasePoints(String pointTypeId,
			String memberId, Integer adjustedPoint, String promotionType,
			Date sysDate) throws Exception {
		if (StringUtil.nullToWhiteStr(memberId).length() == 0) {
			throw new PointRecordException("���ӻ�����ϸ�쳣:" + "memberId is null.");
		}
		if (StringUtil.nullToWhiteStr(pointTypeId).length() == 0) {
			throw new PointRecordException("���ӻ�����ϸ�쳣:" + "pointTypeId is null.");
		}
		MPointType pointType = as.findMPointTypeById(pointTypeId);
		if (null == pointType) {
			throw new PointRecordException("���ӻ�����ϸ�쳣:" + "pointType<"
					+ pointTypeId + "> is null.");
		}

		Date valid = calValid(pointType, memberId, sysDate);
		if (null == valid) {
			throw new PointRecordException("���ӻ�����ϸ�쳣:"
					+ "failed to get valid date.");
		}
		Integer freezeDays = NumberUtils.nullToZero(pointType.getFREEZE_DAY());

		MPointList pointList = new MPointList();
		pointList.setID(PrimaryKeyGenerator.getInstance().generate());
		pointList.setMEMBER_ID(memberId);
		pointList.setPOINT_TYPE_ID(pointTypeId);
		pointList.setPOINTS(adjustedPoint);
		pointList.setUSED_VALUE(0);
		pointList.setPROMOTION_TYPE(promotionType);
		pointList
				.setPROCESS_FLAG(LoyaltyActionEnums.POINT_LIST_STATUS_HANDLER_POINTLIST_DO_NOTHING);
		pointList.setBORN_DATE(sysDate);
		// ��ʼ���ڼ��϶���ʱ��
		pointList.setSTART_DATE(CalendarUtil.dateToSpecifiedFormat(CalendarUtil
				.increaseTimeByDay(sysDate, freezeDays)));
		pointList.setEND_DATE(CalendarUtil.dateToSpecifiedFormat(valid));
		pointList.setMEMBER_PERIOD(CalendarUtil.getMemberPeriod(memberId));
		pointList.setVALID_FLAG(1);// ת�ƻ������ǿ��õ�
		as.appendNewMPointList(pointList);
	}

	/**
	 * ת�ƻ��ּ��ּ���ϸ
	 * 
	 * @param pointTypeId
	 * @param memberId
	 * @param adjustedPoint
	 * @param promotionType
	 * @param sysDate
	 * @throws Exception
	 */
	public void recordPointTypeAfterReducePoints(String pointTypeId,
			String memberId, Integer adjustedPoint, String promotionType,
			Date sysDate) throws Exception {
		if (StringUtil.nullToWhiteStr(memberId).length() == 0) {
			throw new PointRecordException("��������ϸ�쳣:" + "memberId is null.");
		}
		if (StringUtil.nullToWhiteStr(pointTypeId).length() == 0) {
			throw new PointRecordException("��������ϸ�쳣:" + "pointTypeId is null.");
		}
		if (null == adjustedPoint) {
			throw new PointRecordException("��������ϸ�쳣:"
					+ "adjustedPoint is null.");
		}
		MPointType pointType = as.findMPointTypeById(pointTypeId);
		if (null == pointType) {
			throw new PointRecordException("��������ϸ�쳣:" + "pointType is null.");
		}
		// String basis = pointType.getBASIS();
		// if
		// (!LoyaltyConstants.POINTTYPE_EXPIRE_M_PERIOD.equalsIgnoreCase(basis))
		// {
		// return;
		// }
		List<MPointList> pointLists = as
				.findPointListsByTypeIdAndMemberIdThanZeroAndValidStatus(
						pointTypeId, memberId);
		// ���ֹ���
		Integer leftPoint = -adjustedPoint;
		for (MPointList p : pointLists) {
			if (NumberUtils.nullToZero(p.getPOINTS()) <= 0) {
				continue;
			}
			// �жϸû�����ϸ��û�����ڴ���:��:������Ϊ���ֻ���,��:����ѭ��
			if (LoyaltyActionEnums.POINT_LIST_STATUS_HANDLER_POINTLIST_DO_NOTHING == NumberUtils
					.nullToZero(p.getPROCESS_FLAG())) {
				Integer validPoints = NumberUtils.nullToZero(p.getPOINTS())
						- NumberUtils.nullToZero(p.getUSED_VALUE());
				if (NumberUtils.nullToZero(p.getPOINTS()) <= NumberUtils
						.nullToZero(p.getUSED_VALUE())) {
					continue;
				}
				if (validPoints >= leftPoint) {
					p.setUSED_VALUE(NumberUtils.nullToZero(p.getUSED_VALUE())
							+ leftPoint);
					leftPoint = 0;
					as.updatePointList(p);
					break;
				} else {
					p.setUSED_VALUE(NumberUtils.nullToZero(p.getPOINTS()));
					leftPoint -= validPoints;
				}
				as.updatePointList(p);
			}
		}
		if (leftPoint > 0) {
			throw new Exception("���ּ���ϸʧ��:You have not enough point.");
		}
		MPointList append = appendPointList(pointTypeId, memberId,
				adjustedPoint, promotionType, sysDate);
		as.appendNewMPointList(append);
	}

	public MPointList appendPointList(String pointTypeId, String memberId,
			Integer adjustedPoint, String promotionType, Date sysDate) {

		MPointList appendData = new MPointList();
		appendData.setID(PrimaryKeyGenerator.getInstance().generate());
		appendData.setBORN_DATE(sysDate);

		appendData.setMEMBER_ID(memberId);
		appendData.setPOINT_TYPE_ID(pointTypeId);
		appendData.setPOINTS(adjustedPoint);
		appendData.setMEMBER_PERIOD(CalendarUtil.getMemberPeriod(memberId));
		appendData.setPROMOTION_TYPE(promotionType);
		appendData
				.setPROCESS_FLAG(LoyaltyActionEnums.POINT_LIST_STATUS_HANDLER_POINTLIST_DO_NOTHING);
		appendData.setCOMMENTS("");

		return appendData;
	}
}
