package com.loyalty.action.sub;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.log4j.Logger;

import com.loyalty.action.AbstractAction;
import com.loyalty.dto.MMember;
import com.loyalty.dto.MPoints;
import com.loyalty.dto.MPointsHis;
import com.loyalty.exception.action.LoyaltyActionException;
import com.loyalty.generator.PrimaryKeyGenerator;
import com.loyalty.message.Message;
import com.loyalty.service.ActionService;
import com.loyalty.util.CalendarUtil;
import com.loyalty.util.LoyaltyConstants;

/**
 * @ClassName: MemberExpiryAct
 * @Description: ������<��Ա���ڴ���>
 */
public class MemberExpiryAct extends AbstractAction {
	static Logger logger = Logger.getLogger(MemberExpiryAct.class);

	/**
	 * @Title: process
	 * @Description: ��������
	 * @param memberId
	 * @throws Exception
	 */
	public void process(String memberId) throws Exception {

		if (null == memberId) {
			throw new LoyaltyActionException("��Ա����:" + "memberId is needed.");
		}
		MMember present = as.getMMemberByMemberId(memberId);
		if (null == present) {
			throw new LoyaltyActionException("��Ա����:" + "member<" + memberId
					+ "> is not exist.");
		}
		// ����Ա��״̬��Ϊ�Ǽ���״̬
		present.setACTIVE_FLAG(LoyaltyConstants.LOYALTY_UNACTIVE);
		// ��ȡ�����б�
		List<MPoints> presentPoints = as.findPointsByMemberId(memberId);
		for (MPoints point : presentPoints) {
			// ����һ��������ʷ
			MPointsHis newPointHis = new MPointsHis();
			newPointHis.setID(PrimaryKeyGenerator.getInstance().generate());
			newPointHis.setSTART_DATE(present.getSTART_DATE());
			newPointHis.setEND_DATE(present.getEND_DATE());
			newPointHis.setPOINTS_TYPE_ID(point.getPOINT_TYPE_ID());
			newPointHis.setMEMBER_ID(present.getID());
			newPointHis.setTOTAL_POINTS(point.getTOTAL_POINTS());
			newPointHis.setMEMBER_PERIOD(point.getMEMBER_PERIOD());
			// ���û��ּ�¼
			point.setLIFETIME_VALID_POINTS(point.getVALID_POINTS());
			point.setVALID_POINTS(0);
			point.setTOTAL_POINTS(0);
			point.setFOZEN_POINTS(0);
			point.setUPDATE_TIME(CalendarUtil.getCurrentDate());
			// �����Ҫ���޸�
			as.updatePointsAndInsertPointsHis(point, newPointHis);
		}
	}
}
