package com.loyalty.action.sub;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import com.loyalty.action.AbstractAction;
import com.loyalty.bean.MemberInfo;
import com.loyalty.bean.PointTypeInfo;
import com.loyalty.bean.PointsDetail;
import com.loyalty.core.LoyaltyContext;
import com.loyalty.dto.MPointList;
import com.loyalty.enums.LoyaltyActionEnums;
import com.loyalty.exception.LoyaltyException;
import com.loyalty.exception.PointRecordException;
import com.loyalty.exception.action.LoyaltyPointException;
import com.loyalty.generator.PrimaryKeyGenerator;
import com.loyalty.util.CalendarUtil;
import com.loyalty.util.LoyaltyConstants;
import com.loyalty.util.NumberUtils;
import com.ruixue.rfw.util.StringUtil;

public class FluentPointsDetailsRecordAct extends AbstractAction {

	public FluentPointsDetailsRecordAct() {

	}
	
	// 20140519 SQL�Ż� liuhui
	/**
	 * ���ӻ���֮�����ϸ
	 * 
	 * @param pointTypeId
	 * @param memberId
	 * @param adjustedPoint
	 * @param promotionType
	 * @param sysDate
	 * @throws Exception
	 */
	public void recordPointTypeAfterIncreasePoints(PointTypeInfo type, int point,
		int validFlg, LoyaltyContext ctx) throws LoyaltyException {
		
		if (ctx.getMember() == null) {
			throw new PointRecordException("���ӻ�����ϸ�쳣 : memberId is null.");
		}
		if (!type.isActivity()) {
			throw new PointRecordException("���ӻ�����ϸ�쳣:pointType<" + type.getId() + "> is null.");
		}

		Date valid = calValid(type, ctx.getMember(), ctx.getCtxDate());

		if (null == valid) {
			throw new PointRecordException("���ӻ�����ϸ�쳣 : failed to get valid date.");
		}

		MPointList pointList = new MPointList();
		pointList.setID(PrimaryKeyGenerator.getInstance().generate());
		pointList.setMEMBER_ID(ctx.getMember().getId());
		if (ctx.getOrderInfo() != null) {
			pointList.setORDER_ID(ctx.getOrderInfo().getId());
		} else {
			pointList.setORDER_ID(ctx.getOrderId());
		}
		pointList.setPOINT_TYPE_ID(type.getId());
		pointList.setPOINTS(point);
		pointList.setUSED_VALUE(0);
		pointList.setPROCESS_FLAG(
			LoyaltyActionEnums.POINT_LIST_STATUS_HANDLER_POINTLIST_DO_NOTHING);
		if (ctx.getPromotion() != null) {
			pointList.setPROMOTION_NAME(ctx.getPromotion().getName());
			pointList.setPROMOTION_TYPE(ctx.getPromotion().getType());
		}
		pointList.setBORN_DATE(ctx.getCtxDate());
		// ��ʼ���ڼ��϶���ʱ��
		try {
			pointList.setSTART_DATE(CalendarUtil.dateToSpecifiedFormat(CalendarUtil
					.increaseTimeByDay(ctx.getCtxDate(), type.getFreezeDay())));
			pointList.setEND_DATE(CalendarUtil.dateToSpecifiedFormat(valid));
		} catch (Exception e) {
			throw new LoyaltyException(e.getMessage(), e);
		}
		pointList.setMEMBER_PERIOD(CalendarUtil.getMemberPeriod(ctx.getMember()));
		if (ctx.getParams() != null) {
			// TODO 20140520 ���Ӳ�����ʶ�ֶ�
			pointList.setACT_TYPE((String) ctx.getParams().get("p1"));
			pointList.setACT_SUB_TYPE((String) ctx.getParams().get("p2"));
		}
		
		pointList.setVALID_FLAG(validFlg);
		as.appendNewMPointList(pointList);
	}
	
	// 20140520 SQL�Ż� liuhui
	/**
	 * ��������֮�����ϸ
	 * 
	 * @param pointTypeId
	 * @param memberId
	 * @param adjustedPoint
	 * @param promotionId
	 * @param orderId
	 * @throws Exception
	 */
	public void recordPointTypeAfterReducePoints(PointTypeInfo type,
			int point, LoyaltyContext ctx) throws LoyaltyException {
		if (ctx.getMember() == null) {
			throw new PointRecordException("��������ϸ�쳣:memberId is null.");
		}
		if (!type.isActivity()) {
			throw new PointRecordException("��������ϸ�쳣:pointTypeId is null.");
		}
		if (point == 0) {
			throw new PointRecordException("��������ϸ�쳣:adjustedPoint is null.");
		}
		
//		List<MPointList> pointLists = as
//				.findPointListsByTypeIdAndMemberIdThanZeroAndValidStatus(
//						type.getId(), ctx.getMember().getId());
		
		List<PointsDetail> pointLists = as.getPointDetails(ctx.getMember().getId(), type.getId());
		
		// ���ֹ���
		int leftPoint = Math.abs(point);
		int detailPoints = 0;
		int usedPoints = 0;
		int validPoints = 0;
		List<PointsDetail> upd = new ArrayList<PointsDetail>();
		for (PointsDetail p : pointLists) {
//			if (p.getPoints() <= 0) {
//				continue;
//			}
			// �жϸû�����ϸ��û�����ڴ���:��:������Ϊ���ֻ���,��:����ѭ��
			if (LoyaltyActionEnums.POINT_LIST_STATUS_HANDLER_POINTLIST_DO_NOTHING
					== p.getProcessFlg()) {
				
				detailPoints = p.getPoints();
				usedPoints = p.getUsedPoints();
				
				if (detailPoints <= usedPoints) {
					continue;
				}
				
				validPoints = detailPoints - usedPoints;
				
				if (validPoints >= leftPoint) {
					p.setUsedPoints(usedPoints + leftPoint);
					leftPoint = 0;
					upd.add(p);
					break;
				} else {
					p.setUsedPoints(detailPoints);
					leftPoint -= validPoints;
					upd.add(p);
				}
			}
		}
		if (leftPoint > 0) {
			throw new LoyaltyPointException("���ּ���ϸʧ��:You have not enough point.",
				LoyaltyConstants.ERRCD_POINT_NOT_ENOUGH);
		}
		
		MPointList append = appendPointList(type, point, ctx);
		
		Map<String, Object> params = ctx.getParams();
		String value = null;
		if (params.containsKey("p4") && StringUtil.isNotEmpty(value =
			(String) params.get("p4"))) {
			// ׷����Ʒ����
			append.setCOMMENTS("gift:" + value);
		}
		// ���ֲ���׷��
		append.setACT_TYPE((String) params.get("p1"));
		append.setACT_SUB_TYPE((String) params.get("p2"));
		
		as.updatePointDetails(upd);
		as.appendNewMPointList(append);
	}
	
	// 20140519 SQL�Ż� liuhui
	protected Date calValid(PointTypeInfo type, MemberInfo member, Date sysDate)
		throws LoyaltyException {
		String basis = type.getBasis();
		if (null == basis) {
			return null;
		}
		
		Date valid = null;
		if (LoyaltyConstants.POINTTYPE_EXPIRE_M_MEMBERPERIOD
				.equalsIgnoreCase(basis)) {
			valid = memberPeriod(member, type, sysDate);
		} else if (LoyaltyConstants.POINTTYPE_EXPIRE_M_FIXDATE
				.equalsIgnoreCase(basis)) {
			valid = fixDate(type, sysDate);
		} else if (LoyaltyConstants.POINTTYPE_EXPIRE_M_PERIOD
				.equalsIgnoreCase(basis)) {
			valid = period(type, sysDate);
		}
		return valid;
	}
	
	// TODO 20140519 SQL�Ż� liuhui
	// ��Ա��Ч�� 
	protected Date memberPeriod(MemberInfo member, PointTypeInfo pointType,
			Date sysDate) throws LoyaltyException {
		Integer period = pointType.getPeriod();
		String uom = pointType.getUom();
		Date result = null;
		if (null == member) {
			throw new PointRecordException("��Ա��Ч�� : member is null.");
		}
		result = member.getEndDt();
		if (null != period && period != 0) {// ��ֵ���ӳ�,ûֵ�Ͳ��ӳ�
			if (CalendarUtil.isUOMYear(uom)) {
				result = CalendarUtil.increaseTimeByYear(member.getEndDt(),
						period);
			} else if (CalendarUtil.isUOMMonth(uom)) {
				result = CalendarUtil.increaseTimeByMonth(member.getEndDt(),
						period);
			}
		}
		return result;
	}
	
	// 20140519 SQL�Ż� liuhui
	// �ڼ�������
	protected Date period(PointTypeInfo pointType, Date sysDate) {
		Integer period = pointType.getPeriod();
		String uom = pointType.getUom();
		Date currDate = CalendarUtil.increaseTimeByDay(sysDate, pointType
				.getFreezeDay());
		Date result = null;
		if (CalendarUtil.isUOMYear(uom)) {
			result = CalendarUtil.increaseTimeByYear(currDate, period);
		} else if (CalendarUtil.isUOMMonth(uom)) {
			result = CalendarUtil.increaseTimeByMonth(currDate, period);
		}
		return result;
	}
	
	// 20140519 SQL�Ż� liuhui
	/*
	 * �̶����ڼ���
	 * 
	 * �ڼ䣺 �������� ��fixDate����
	 */
	private Date fixDate(PointTypeInfo pointType, Date sysDate) {
		Integer expireMonth = pointType.getExpireMonth();
		Integer expireDay = pointType.getExpireDay();
		String uom = pointType.getUom();
		Date currDate = CalendarUtil.increaseTimeByDay(sysDate, pointType
				.getFreezeDay());
		Date result = null;
		if (null != pointType.getPeriod() && pointType.getPeriod() != 0) {
			if (CalendarUtil.isUOMYear(uom)) {
				result = CalendarUtil.resetTimeOnMonthAndDay(CalendarUtil
						.increaseTimeByYear(currDate, pointType.getPeriod()),
						expireMonth, expireDay);
			} else if (CalendarUtil.isUOMMonth(uom)) {
				Date date = CalendarUtil.increaseTimeByMonth(currDate,
						pointType.getPeriod());
				if (CalendarUtil.isLargerThanSpecifiedMonthDay(date,
						expireMonth, expireDay)) {
					date = CalendarUtil.increaseTimeByYear(date, 1);
				}
				result = CalendarUtil.resetTimeOnMonthAndDay(date, expireMonth,
						expireDay);
			}
		} else {
			result = CalendarUtil.isLargerThanSpecifiedMonthDay(currDate,
					expireMonth, expireDay) ? CalendarUtil
					.resetTimeOnMonthAndDay(CalendarUtil.increaseTimeByYear(
							currDate, 1), expireMonth, expireDay)
					: CalendarUtil.resetTimeOnMonthAndDay(currDate,
							expireMonth, expireDay);
		}
		return result;
	}
	
	// 20140519 SQL�Ż� liuhui
	public MPointList appendPointList(PointTypeInfo type, int point, LoyaltyContext ctx) {

		MPointList appendData = new MPointList();
		appendData.setID(PrimaryKeyGenerator.getInstance().generate());
		appendData.setBORN_DATE(ctx.getCtxDate());
		appendData.setORDER_ID(ctx.getOrderId());
		
		if (ctx.getPromotion() != null) {
			appendData.setPROMOTION_ID(ctx.getPromotion().getId());
			appendData.setPROMOTION_NAME(ctx.getPromotion().getName());
			appendData.setPROMOTION_TYPE(ctx.getPromotion().getType());
		}
		
		appendData.setMEMBER_ID(ctx.getMember().getId());
		appendData.setPOINT_TYPE_ID(type.getId());
		appendData.setPOINTS(point);
		appendData.setPROCESS_FLAG(LoyaltyActionEnums
			.POINT_LIST_STATUS_HANDLER_POINTLIST_DO_NOTHING);
		appendData.setMEMBER_PERIOD(CalendarUtil.getMemberPeriod(ctx.getMember()));
		appendData.setVALID_FLAG(LoyaltyConstants.LOYALTY_ACTIVE);
		appendData.setCOMMENTS("");
		
		return appendData;
	}
}
