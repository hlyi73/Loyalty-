package com.loyalty.action.sub;

import java.math.BigDecimal;

import org.apache.log4j.Logger;

import com.ibatis.dao.client.DaoManager;
import com.loyalty.action.AbstractAction;
import com.loyalty.action.main.MemberAct;
import com.loyalty.dao.MLoyOrderDAO;
import com.loyalty.dao.MPointsRateDAO;
import com.loyalty.dto.MPointsRate;
import com.loyalty.exception.ExchangeRateException;
import com.loyalty.service.ActionService;
import com.loyalty.util.DAOUtil;
import com.loyalty.util.StringUtil;

/*
 * ����������
 */

public class ExchangeRateAct extends AbstractAction {

	public static Logger logger = Logger.getLogger(ExchangeRateAct.class);

	public ExchangeRateAct() {
	}

	/**
	 * ��ȡ����
	 * 
	 * @param ����
	 */
	public MPointsRate getExchangRate(String currencyType, String orgId)
			throws Exception {

		MPointsRate mpr = as.findMPointsRateByCurrencyType(currencyType, orgId);
		if (null == mpr) {
			mpr = new MPointsRate();
			mpr.setAMOUNT(Long.valueOf("1"));
			mpr.setPOINTS(Long.valueOf("1"));
		}
		return mpr;
	}

	/**
	 * ����ת��
	 * 
	 * @param Դ����;����
	 */
	public Double convert(Double sourceValue, String currencyType, String orgId)
			throws Exception {
		MPointsRate mpr = getExchangRate(currencyType, orgId);
		if (null == mpr.getAMOUNT() || null == mpr.getPOINTS()) {
			throw new ExchangeRateException("����ת����"
					+ "amount || points is null.");
		}
		BigDecimal sourceValueBig = new BigDecimal(Double.toString(sourceValue));
		Double exchangedValue = (sourceValueBig.divide(new BigDecimal(Long
				.toString(mpr.getAMOUNT()))).multiply(new BigDecimal(Long
				.toString(mpr.getPOINTS())))).doubleValue();
		return exchangedValue;
	}
}
