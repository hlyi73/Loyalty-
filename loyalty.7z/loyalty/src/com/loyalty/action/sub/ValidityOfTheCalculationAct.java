package com.loyalty.action.sub;

import java.util.Date;

import com.loyalty.action.AbstractAction;
import com.loyalty.bean.TierInfo;
import com.loyalty.core.LoyaltyContext;
import com.loyalty.dto.MTier;
import com.loyalty.message.ValidityMessage;
import com.loyalty.util.CalendarUtil;
import com.loyalty.util.LoyaltyConstants;
import com.loyalty.util.StringUtil;

/*
 * ������Ч�ڵ�������
 */
public class ValidityOfTheCalculationAct extends AbstractAction {

	public ValidityOfTheCalculationAct() {
	}

	public ValidityMessage doCalculation(MTier mTier, LoyaltyContext ctx,
			String type) {
		ValidityMessage message = null;
		Integer periodOfTime = null;
		String validUnits = null;
		String validMethodOfCalculation = null;
		type = StringUtil.nullToWhiteStr(type);

		if (LoyaltyConstants.ACTION_ACTIONTYPE_M_RENEWAL.equals(type)) {
			periodOfTime = mTier.getNEXT_PERIOD();
			validUnits = mTier.getNEXT_UOM();
		} else {
			periodOfTime = mTier.getPERIOD();
			validUnits = mTier.getUOM();
		}

		validMethodOfCalculation = StringUtil.nullToWhiteStr(mTier
				.getCALCULATE());
		Date sysData = CalendarUtil.resetHMSToZero(ctx.getCtxDate());

		// ������Ч��
		message = calculate(periodOfTime, validUnits, validMethodOfCalculation,
				message, sysData);// ����
		message.setMTier(mTier);
		return message;
	}
	
	public ValidityMessage doCalculation(TierInfo tier, LoyaltyContext ctx, String type) {
		ValidityMessage message = null;
		Integer periodOfTime = null;
		String validUnits = null;
		String validMethodOfCalculation = null;
		type = StringUtil.nullToWhiteStr(type);
	
		if (LoyaltyConstants.ACTION_ACTIONTYPE_M_RENEWAL.equals(type)) {
			periodOfTime = tier.getNextPeriod();
			validUnits = tier.getNextUom();
		} else {
			periodOfTime = tier.getPeriod();
			validUnits = tier.getUom();
		}
	
		validMethodOfCalculation = StringUtil.nullToWhiteStr(tier.getCalc());
		Date sysData = CalendarUtil.resetHMSToZero(ctx.getCtxDate());
	
		// ������Ч��
		message = calculate(periodOfTime, validUnits, validMethodOfCalculation,
				message, sysData);// ����
		return message;
	}

	protected ValidityMessage calculate(Integer periodOfTime,
			String validUnits, String validMethodOfCalculation,
			ValidityMessage message, Date sysDate) {
		if (null == message) {
			message = new ValidityMessage();
		}
		Object result = null;
		if (LoyaltyConstants.TIER_PERIODCALCULATE_M_DAY
				.equalsIgnoreCase(validMethodOfCalculation)) {
			result = CalendarUtil.onDaily(periodOfTime, validUnits, sysDate);
		} else if (LoyaltyConstants.TIER_PERIODCALCULATE_M_MONTH
				.equalsIgnoreCase(validMethodOfCalculation)) {
			result = CalendarUtil.onNaturalMonthCurrent(periodOfTime,
					validUnits, sysDate);
		} else if (LoyaltyConstants.TIER_PERIODCALCULATE_M_NEXTMONTH
				.equalsIgnoreCase(validMethodOfCalculation)) {
			result = CalendarUtil.onNaturalMonthNext(periodOfTime, validUnits,
					sysDate);
		} else if (LoyaltyConstants.TIER_PERIODCALCULATE_M_YEAR
				.equalsIgnoreCase(validMethodOfCalculation)) {
			result = CalendarUtil.onNaturalYearCurrent(periodOfTime,
					validUnits, sysDate);
		} else if (LoyaltyConstants.TIER_PERIODCALCULATE_M_YEARNEXTMONTH
				.equalsIgnoreCase(validMethodOfCalculation)) {
			result = CalendarUtil.onNaturalYearNext(periodOfTime, validUnits,
					sysDate);
		} else if (LoyaltyConstants.TIER_PERIODCALCULATE_M_YEARLASTDAY
				.equalsIgnoreCase(validMethodOfCalculation)) {
			result = CalendarUtil.onNaturalYearEnd(periodOfTime, validUnits,
					sysDate);
		}
		if (null != result) {
			message.setSuccess(true);
		}
		message.setResult(result);
		return message;
	}

}
