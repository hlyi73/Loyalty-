package com.loyalty.action.sub;

import com.loyalty.action.AbstractAction;
import com.loyalty.bean.PointTypeInfo;
import com.loyalty.core.LoyaltyContext;
import com.loyalty.dto.MOrderDetail;
import com.loyalty.dto.MPoints;
import com.loyalty.exception.LoyaltyException;
import com.loyalty.exception.action.LoyaltyActionException;
import com.loyalty.exception.action.LoyaltyPointException;
import com.loyalty.generator.PrimaryKeyGenerator;
import com.loyalty.util.CalendarUtil;
import com.loyalty.util.LoyaltyConstants;
import com.loyalty.util.NumberUtils;
import com.loyalty.util.ObjectUtil;

/**
 * @ClassName: ChangePointAct
 * @Description: ����������<���ֵ���>
 */
public class FluentChangePointAct extends AbstractAction {

	private FluentPointsDetailsRecordAct recorder;

	public FluentChangePointAct() {
		recorder = (FluentPointsDetailsRecordAct) ObjectUtil
				.getAction(FluentPointsDetailsRecordAct.class);
	}

	/**
	 * @Title: adjustPoints
	 * @Description: ��������
	 * @param pointTypeId
	 * @param memberId
	 * @param adjustedPoint
	 * @param isAdjustingPoint
	 * @throws Exception
	 */
	public void adjustPoints(PointTypeInfo type, int point, LoyaltyContext ctx) throws LoyaltyException {

		String memberPeriod = CalendarUtil.getMemberPeriod(ctx.getMember());
		
		MPoints mps = as.getMPointsByPointTypeIdAndMemberId(type.getId(), ctx.getMember().getId());
		
		// ����������򴴽�һ����¼
		boolean isNew = false;
		if (null == mps) {
			isNew = true;
			mps = new MPoints();
			mps.setID(PrimaryKeyGenerator.getInstance().generate());
			mps.setPOINT_TYPE_ID(type.getId());
			mps.setMEMBER_ID(ctx.getMember().getId());
			mps.setTOTAL_POINTS(0);
			mps.setVALID_POINTS(0);
			mps.setFOZEN_POINTS(0);
			mps.setLIFETIME_POINTS(0);
			mps.setLAST_BALANCE(0);
			mps.setLIFETIME_VALID_POINTS(0);
			mps.setGIFT_POINTS(0);
			mps.setMEMBER_PERIOD(memberPeriod);
		}

		int totalPoints = NumberUtils.nullToZero(mps.getTOTAL_POINTS());
		int liftTimePoints = NumberUtils.nullToZero(mps.getLIFETIME_POINTS());
		int validPoints = NumberUtils.nullToZero(mps.getVALID_POINTS());
		// ��������
		mps.setTOTAL_POINTS(totalPoints + point);
		mps.setLIFETIME_POINTS(liftTimePoints + point);
		mps.setVALID_POINTS(validPoints + point);
		mps.setLIFETIME_VALID_POINTS(validPoints + point 
			+ NumberUtils.nullToZero(mps.getLAST_BALANCE()));
		mps.setUPDATE_TIME(CalendarUtil.getCurrentDate());

		// ���±���¼
		if (isNew) {
			as.appendMPointsForMember(mps);
		} else {
			as.updateMPoints(mps);
		}
	}

	/**
	 * @Title: changPointBaseOnNothing
	 * @Description: ����������ϸ
	 */
	public void changPointBaseOnNothing(String pointTypeId, String memberId,
			Integer increasedPoint, String promotionId, String orderId)
			throws Exception {
		// ����һ�����׽���������ϸ
		MOrderDetail mod = new MOrderDetail();
		mod.setID(PrimaryKeyGenerator.getInstance().generate());
		mod.setORDER_ID(orderId);
		mod.setPROMOTION_ID(promotionId);
		mod.setPOINTS(increasedPoint);
		mod.setSTATUS(LoyaltyConstants.ORDER_DETAIL_VALID);
		mod.setPOINTS_TYPE_ID(pointTypeId);
		as.appendToMOrderDetail(mod);
	}

	// 20140519 SQL�Ż� liuhui
	/**
	 * ��������
	 * 
	 */
	public void changPointBaseOnMember(PointTypeInfo type, int point, LoyaltyContext ctx)
		throws LoyaltyException {
		
		if (ctx.getMember() == null) {
			throw new LoyaltyActionException("���ֵ��� : memberId is null.");
		}
		if (!type.isActivity()) {
			throw new LoyaltyActionException("���ֵ���:pointType<" + type.getId() + "> is null.");
		}

		if (point > 0) {
			this.add(type, point, ctx);
		} else {
			this.reduce(type, point, ctx);
		}
	}
	
	// 20140519 SQL�Ż� liuhui
	/**
	 * @Title: add
	 * @Description: �ͷ�
	 * @param pointTypeId
	 * @param memberId
	 * @param adjustedPoint
	 * @param promotionId
	 * @param orderId
	 * @param pointType
	 * @throws Exception
	 */
	public void add(PointTypeInfo type, int point, LoyaltyContext ctx) throws LoyaltyException {
		
		// �Ƿ���Ҫ������ǰ��Ա����
		Boolean isAdjustingPoint = (point > 0) && (type.getFreezeDay() == 0);
		// ��ȡvalid_flag
		Integer validFlag = !isAdjustingPoint ? LoyaltyConstants.LOYALTY_UNACTIVE
				: LoyaltyConstants.LOYALTY_ACTIVE;// true?1:0

		// ������Ա����
		if (isAdjustingPoint) {
			this.adjustPoints(type, point, ctx);
		}
		// ����ϸ
		recorder.recordPointTypeAfterIncreasePoints(type, point, validFlag, ctx);
	}
	
	// 20140519 SQL�Ż� liuhui
	/**
	 * @Title: reduce
	 * @Description: ����
	 * @param pointTypeId
	 * @param memberId
	 * @param adjustedPoint
	 * @param promotionId
	 * @param orderId
	 * @param pointType
	 * @throws Exception
	 */
	public void reduce(PointTypeInfo type, int point, LoyaltyContext ctx) throws LoyaltyException {
		
		MPoints points = as.getMPointsByPointTypeIdAndMemberId(type.getId(), ctx.getMember().getId());
		if (null == points) {
			throw new LoyaltyPointException("��������:��ǰ��Ա�Ļ��ֲ���.",
				LoyaltyConstants.ERRCD_POINT_NOT_ENOUGH);
		}
		int newPoint = NumberUtils.nullToZero(points.getVALID_POINTS()) + point;
		if (newPoint < 0) {
			throw new LoyaltyPointException("��������:��ǰ��Ա�Ļ��ֲ���.",
				LoyaltyConstants.ERRCD_POINT_NOT_ENOUGH);
		}
		
		// ������־ Ϊ����
		points.setVALID_POINTS(newPoint);
		points.setLIFETIME_VALID_POINTS(newPoint
				+ NumberUtils.nullToZero(points.getLAST_BALANCE()));// �����ܿ��÷�
//		if (ctx.getParams().containsKey("p4")) {
			int giftPoint = NumberUtils.nullToZero(points.getGIFT_POINTS());
			giftPoint += Math.abs(point);
			points.setGIFT_POINTS(giftPoint);
//		}
		points.setUPDATE_TIME(CalendarUtil.getCurrentDate());
		// ���»��ֱ�
		as.updateMPoints(points);
		// ����ϸ
		recorder.recordPointTypeAfterReducePoints(type, point, ctx);
	}
}
