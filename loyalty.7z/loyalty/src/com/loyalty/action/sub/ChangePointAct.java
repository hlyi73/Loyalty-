package com.loyalty.action.sub;

import java.util.Date;

import org.apache.log4j.Logger;
import com.loyalty.action.AbstractAction;
import com.loyalty.dto.MLoyOrder;
import com.loyalty.dto.MOrderDetail;
import com.loyalty.dto.MPointType;
import com.loyalty.dto.MPoints;
import com.loyalty.generator.PrimaryKeyGenerator;
import com.loyalty.util.CalendarUtil;
import com.loyalty.util.LoyaltyConstants;
import com.loyalty.util.NumberUtils;
import com.loyalty.util.ObjectUtil;
import com.loyalty.util.StringUtil;

/**
 * @ClassName: ChangePointAct
 * @Description: ����������<���ֵ���>
 */
public class ChangePointAct extends AbstractAction {

	public static Logger logger = Logger.getLogger(ChangePointAct.class);
	private PointsDetailsRecordAct recorder;

	public ChangePointAct() {
		recorder = (PointsDetailsRecordAct) ObjectUtil
				.getAction(PointsDetailsRecordAct.class);
	}

	/**
	 * ��������
	 * �������� url�е�p1��p2
	 * 
	 */
	public void changPointBaseOnMember(String pointTypeId, String memberId,
			Date sysDate, Integer adjustedPoint, String promotionId,
			String orderId, String flag, String giftName, String p1, String p2) throws Exception {
		if (StringUtil.nullToWhiteStr(memberId).length() == 0) {
			throw new Exception("���ֵ���:" + "memberId is null.");
		}
		MPointType pointType = new MPointType();
		pointType.setID(pointTypeId);
		pointType = (MPointType) as.getMacDao().selectByPrimaryKey(pointType);
		if (null == pointType) {
			throw new Exception("���ֵ���:" + "pointType<" + pointTypeId
					+ "> is null.");
		}

		if (adjustedPoint > 0) {
			this.add(pointTypeId, memberId, adjustedPoint, promotionId,
					orderId, pointType, sysDate, p1, p2);
		} else if (adjustedPoint < 0) {
			//add start 2014/05/14 hansheng
//			this.reduce(pointTypeId, memberId, adjustedPoint, promotionId,
//					orderId, pointType, sysDate);
			this.reduce(pointTypeId, memberId, adjustedPoint, promotionId,
					orderId, pointType, sysDate, flag, giftName, p1, p2);
			//add end 2014/05/14 hansheng	
		}
	}

	/**
	 * ��������
	 * 
	 */
	public void changPointBaseOnMember(String pointTypeId, String memberId,
			Date sysDate, Integer adjustedPoint, String promotionId,
			String orderId) throws Exception {
		if (StringUtil.nullToWhiteStr(memberId).length() == 0) {
			throw new Exception("���ֵ���:" + "memberId is null.");
		}
		MPointType pointType = new MPointType();
		pointType.setID(pointTypeId);
		pointType = (MPointType) as.getMacDao().selectByPrimaryKey(pointType);
		if (null == pointType) {
			throw new Exception("���ֵ���:" + "pointType<" + pointTypeId
					+ "> is null.");
		}

		if (adjustedPoint > 0) {
			this.add(pointTypeId, memberId, adjustedPoint, promotionId,
					orderId, pointType, sysDate);
		} else if (adjustedPoint < 0) {
			this.reduce(pointTypeId, memberId, adjustedPoint, promotionId,
					orderId, pointType, sysDate);	
		}
	}
	/**
	 * @Title: add
	 * @Description: �ͷ�
	 * @param pointTypeId
	 * @param memberId
	 * @param adjustedPoint
	 * @param promotionId
	 * @param orderId
	 * @param pointType
	 * @throws Exception
	 */
	public void add(String pointTypeId, String memberId, Integer adjustedPoint,
			String promotionId, String orderId, MPointType pointType,
			Date sysDate) throws Exception {
		Integer freezeDay = pointType.getFREEZE_DAY() == null ? 0 : pointType
				.getFREEZE_DAY();
		// �Ƿ���Ҫ������ǰ��Ա����
		Boolean isAdjustingPoint = (adjustedPoint > 0) && (freezeDay == 0);
		// ��ȡvalid_flag
		Integer validFlag = !isAdjustingPoint ? LoyaltyConstants.LOYALTY_UNACTIVE
				: LoyaltyConstants.LOYALTY_ACTIVE;// true?1:0

		// ������Ա����
		if (isAdjustingPoint) {
			this.adjustPoints(pointTypeId, memberId, adjustedPoint);
		}
		// ����ϸ
		recorder.recordPointTypeAfterIncreasePoints(pointTypeId, memberId,
				adjustedPoint, promotionId, orderId, validFlag, sysDate);
	}

	//add start 2014/05/16 hansheng
	/**
	 * �ͷ�ҵ�����
	 */
	public void add(String pointTypeId, String memberId, Integer adjustedPoint,
			String promotionId, String orderId, MPointType pointType,
			Date sysDate, String p1, String p2) throws Exception {
		Integer freezeDay = pointType.getFREEZE_DAY() == null ? 0 : pointType
				.getFREEZE_DAY();
		// �Ƿ���Ҫ������ǰ��Ա����
		Boolean isAdjustingPoint = (adjustedPoint > 0) && (freezeDay == 0);
		// ��ȡvalid_flag
		Integer validFlag = !isAdjustingPoint ? LoyaltyConstants.LOYALTY_UNACTIVE
				: LoyaltyConstants.LOYALTY_ACTIVE;// true?1:0

		// ������Ա����
		if (isAdjustingPoint) {
			this.adjustPoints(pointTypeId, memberId, adjustedPoint, p2);
		}
		// ����ϸ
		recorder.recordPointTypeAfterIncreasePoints(pointTypeId, memberId,
				adjustedPoint, promotionId, orderId, validFlag, sysDate, p1, p2);
	}
	//add end 2014/05/16 hansheng
	//add start 2014/05/14 hansheng
	/**
	 * �۷�ҵ�����
	 */
	public void reduce(String pointTypeId, String memberId,
			Integer adjustedPoint, String promotionId, String orderId,
			MPointType pointType, Date sysDate, String flag, String giftName,
			String p1, String p2) throws Exception {
		if (StringUtil.nullToWhiteStr(orderId).length() == 0) {
			throw new Exception("��������:" + "orderId is null.");
		}
		MLoyOrder loyOrder = new MLoyOrder();
		loyOrder.setID(orderId);
		loyOrder = (MLoyOrder) as.getMacDao().selectByPrimaryKey(loyOrder);
		if (null == loyOrder) {
			throw new Exception("��������:" + "�ҳ϶Ƚ��� is not exist.");
		}
		MPoints points = as.getMPointsByPointTypeIdAndMemberId(pointTypeId,
				memberId);
		if (null == points) {
			throw new Exception("��������:" + "The points of member is not exist.");
		}
		// ������־
		String redeemPeriod = loyOrder.getREDEEM_PERIOD();

		if (StringUtil.nullToWhiteStr(redeemPeriod).length() == 0) {
			// ���Ϊ����Ϊ����
			redeemPeriod = LoyaltyConstants.REDEEM_PERIOD_M_CURRENT;
		}

		// �жϽ����Ƿ������Ƕһ�����
		String transcationType = StringUtil.nullToWhiteStr(loyOrder.getTYPE());
		Boolean isRedeem = transcationType
				.equals(LoyaltyConstants.TRANS_TYPE_REDEEM);
		// ����Ƕһ����͵Ļ��ʹӶ�����п۳�
		if (!isRedeem) {
			if (redeemPeriod.equalsIgnoreCase(LoyaltyConstants.REDEEM_PERIOD_M_LAST)) {// ����

				points.setLAST_BALANCE(NumberUtils.nullToZero(points
						.getLAST_BALANCE())
						+ adjustedPoint);
				points.setLIFETIME_VALID_POINTS(NumberUtils.nullToZero(points
						.getVALID_POINTS())
						+ NumberUtils.nullToZero(points.getLAST_BALANCE()));// �����ܿ��÷�

			} else if (redeemPeriod
					.equalsIgnoreCase(LoyaltyConstants.REDEEM_PERIOD_M_CURRENT)) {// ����

				points
						.setVALID_POINTS(points.getVALID_POINTS()
								+ adjustedPoint);
				points.setLIFETIME_VALID_POINTS(NumberUtils.nullToZero(points
						.getVALID_POINTS())
						+ NumberUtils.nullToZero(points.getLAST_BALANCE()));// �����ܿ��÷�

			}
			// ��������������˻��Ļ�,Ҫ�۳��ܻ���<LIFETIME_POINTS>,�����ۼƻ���<TOTAL_POINTS>
			if (transcationType
					.equals(LoyaltyConstants.TRANS_TYPE_REFUND)) {
				points.setLIFETIME_POINTS(NumberUtils.nullToZero(points
						.getLIFETIME_POINTS())
						+ adjustedPoint);
				points.setTOTAL_POINTS(NumberUtils.nullToZero(points
						.getTOTAL_POINTS())
						+ adjustedPoint);
			}
		} else {
			points.setFOZEN_POINTS(NumberUtils.nullToZero(points
					.getFOZEN_POINTS())
					+ adjustedPoint);
		}

		points.setUPDATE_TIME(CalendarUtil.getCurrentDate());
		// ���»��ֱ�
		//add start 2014/05/16 hansheng
		if ("1".equals(flag)) {
			int point =- (int)adjustedPoint;
			points.setGIFT_POINTS(point);
		} else {
			points.setGIFT_POINTS(0);
		}
		//add end 2014/05/16 hansheng
		as.updateMPoints(points);
		// ����ϸ
		//add start 2014/05/16 hansheng
//		recorder.recordPointTypeAfterReducePoints(pointTypeId, memberId,
//				adjustedPoint, promotionId, orderId, sysDate);
		recorder.recordPointTypeAfterReducePoints(pointTypeId, memberId,
				adjustedPoint, promotionId, orderId, sysDate, giftName, p1, p2);
		//add end 2014/05/16 hansheng
	}
	//add start 2014/05/14 hansheng

	public void reduce(String pointTypeId, String memberId,
			Integer adjustedPoint, String promotionId, String orderId,
			MPointType pointType, Date sysDate) throws Exception {
		if (StringUtil.nullToWhiteStr(orderId).length() == 0) {
			throw new Exception("��������:" + "orderId is null.");
		}
		MLoyOrder loyOrder = new MLoyOrder();
		loyOrder.setID(orderId);
		loyOrder = (MLoyOrder) as.getMacDao().selectByPrimaryKey(loyOrder);
		if (null == loyOrder) {
			throw new Exception("��������:" + "�ҳ϶Ƚ��� is not exist.");
		}
		MPoints points = as.getMPointsByPointTypeIdAndMemberId(pointTypeId,
				memberId);
		if (null == points) {
			throw new Exception("��������:" + "The points of member is not exist.");
		}
		// ������־
		String redeemPeriod = loyOrder.getREDEEM_PERIOD();

		if (StringUtil.nullToWhiteStr(redeemPeriod).length() == 0) {
			// ���Ϊ����Ϊ����
			redeemPeriod = LoyaltyConstants.REDEEM_PERIOD_M_CURRENT;
		}

		// �жϽ����Ƿ������Ƕһ�����
		String transcationType = StringUtil.nullToWhiteStr(loyOrder.getTYPE());
		Boolean isRedeem = transcationType
				.equals(LoyaltyConstants.TRANS_TYPE_REDEEM);
		// ����Ƕһ����͵Ļ��ʹӶ�����п۳�
		if (!isRedeem) {
			if (redeemPeriod.equalsIgnoreCase(LoyaltyConstants.REDEEM_PERIOD_M_LAST)) {// ����

				points.setLAST_BALANCE(NumberUtils.nullToZero(points
						.getLAST_BALANCE())
						+ adjustedPoint);
				points.setLIFETIME_VALID_POINTS(NumberUtils.nullToZero(points
						.getVALID_POINTS())
						+ NumberUtils.nullToZero(points.getLAST_BALANCE()));// �����ܿ��÷�

			} else if (redeemPeriod
					.equalsIgnoreCase(LoyaltyConstants.REDEEM_PERIOD_M_CURRENT)) {// ����

				points
						.setVALID_POINTS(points.getVALID_POINTS()
								+ adjustedPoint);
				points.setLIFETIME_VALID_POINTS(NumberUtils.nullToZero(points
						.getVALID_POINTS())
						+ NumberUtils.nullToZero(points.getLAST_BALANCE()));// �����ܿ��÷�

			}
			// ��������������˻��Ļ�,Ҫ�۳��ܻ���<LIFETIME_POINTS>,�����ۼƻ���<TOTAL_POINTS>
			if (transcationType
					.equals(LoyaltyConstants.TRANS_TYPE_REFUND)) {
				points.setLIFETIME_POINTS(NumberUtils.nullToZero(points
						.getLIFETIME_POINTS())
						+ adjustedPoint);
				points.setTOTAL_POINTS(NumberUtils.nullToZero(points
						.getTOTAL_POINTS())
						+ adjustedPoint);
			}
		} else {
			points.setFOZEN_POINTS(NumberUtils.nullToZero(points
					.getFOZEN_POINTS())
					+ adjustedPoint);
		}

		points.setUPDATE_TIME(CalendarUtil.getCurrentDate());
		//add start 2014/05/14 hansheng
		points.setGIFT_POINTS(0);
		//add end 2014/05/14 hansheng
		// ���»��ֱ�
		as.updateMPoints(points);
		// ����ϸ
		recorder.recordPointTypeAfterReducePoints(pointTypeId, memberId,
				adjustedPoint, promotionId, orderId, sysDate);
	}
	/**
	 * @Title: adjustPoints
	 * @Description: ��������
	 * @param pointTypeId
	 * @param memberId
	 * @param adjustedPoint
	 * @param isAdjustingPoint
	 * @throws Exception
	 */
	public void adjustPoints(String pointTypeId, String memberId,
			Integer adjustedPoint) throws Exception {

		String memberPeriod = CalendarUtil.getMemberPeriod(memberId);
		MPoints mps = as.getMPointsByPointTypeIdAndMemberId(pointTypeId,
				memberId);
		// ����������򴴽�һ����¼
		Boolean isMPointsNotExist = false;
		if (null == mps) {
			isMPointsNotExist = true;
			mps = new MPoints();
			mps.setID(PrimaryKeyGenerator.getInstance().generate());
			mps.setPOINT_TYPE_ID(pointTypeId);
			mps.setMEMBER_ID(memberId);
			mps.setTOTAL_POINTS(0);
			mps.setVALID_POINTS(0);
			mps.setFOZEN_POINTS(0);
			mps.setLIFETIME_POINTS(0);
			mps.setLAST_BALANCE(0);
			mps.setLIFETIME_VALID_POINTS(0);
			mps.setMEMBER_PERIOD(memberPeriod);

		}

		// ��������
		mps.setTOTAL_POINTS(NumberUtils.nullToZero(mps.getTOTAL_POINTS())
				+ adjustedPoint);
		mps.setLIFETIME_POINTS(NumberUtils.nullToZero(mps.getLIFETIME_POINTS())
				+ adjustedPoint);
		mps.setVALID_POINTS(NumberUtils.nullToZero(mps.getVALID_POINTS())
				+ adjustedPoint);
		mps.setLIFETIME_VALID_POINTS(NumberUtils.nullToZero(mps
				.getVALID_POINTS())
				+ NumberUtils.nullToZero(mps.getLAST_BALANCE()));
		mps.setUPDATE_TIME(CalendarUtil.getCurrentDate());

		// ���±���¼
		if (isMPointsNotExist) {
			as.appendMPointsForMember(mps);
		} else {
			as.updateMPoints(mps);
		}
	}
	//add start 2014/05/19 hansheng
	// ���˺�ҵ�����
	public void adjustPoints(String pointTypeId, String memberId,
			Integer adjustedPoint, String p2) throws Exception {

		String memberPeriod = CalendarUtil.getMemberPeriod(memberId);
		MPoints mps = as.getMPointsByPointTypeIdAndMemberId(pointTypeId,
				memberId);
		// ����������򴴽�һ����¼
		Boolean isMPointsNotExist = false;
		if (null == mps) {
			isMPointsNotExist = true;
			mps = new MPoints();
			mps.setID(PrimaryKeyGenerator.getInstance().generate());
			mps.setPOINT_TYPE_ID(pointTypeId);
			mps.setMEMBER_ID(memberId);
			mps.setTOTAL_POINTS(0);
			mps.setVALID_POINTS(0);
			mps.setFOZEN_POINTS(0);
			mps.setLIFETIME_POINTS(0);
			mps.setLAST_BALANCE(0);
			mps.setLIFETIME_VALID_POINTS(0);
			mps.setMEMBER_PERIOD(memberPeriod);

		}

		// ��������
		mps.setTOTAL_POINTS(NumberUtils.nullToZero(mps.getTOTAL_POINTS())
				+ adjustedPoint);
		mps.setLIFETIME_POINTS(NumberUtils.nullToZero(mps.getLIFETIME_POINTS())
				+ adjustedPoint);
		mps.setVALID_POINTS(NumberUtils.nullToZero(mps.getVALID_POINTS())
				+ adjustedPoint);
		mps.setLIFETIME_VALID_POINTS(NumberUtils.nullToZero(mps
				.getVALID_POINTS())
				+ NumberUtils.nullToZero(mps.getLAST_BALANCE()));
		mps.setUPDATE_TIME(CalendarUtil.getCurrentDate());

		// ���±���¼
		if (isMPointsNotExist) {
			as.appendMPointsForMember(mps);
		} else {
			as.updateMPoints(mps);
		}
	}
	//add start 2014/05/19 hansheng
	/**
	 * @Title: changPointBaseOnNothing
	 * @Description: ����������ϸ
	 */
	public void changPointBaseOnNothing(String pointTypeId, String memberId,
			Integer increasedPoint, String promotionId, String orderId)
			throws Exception {
		// ����һ�����׽���������ϸ
		MOrderDetail mod = new MOrderDetail();
		mod.setID(PrimaryKeyGenerator.getInstance().generate());
		mod.setORDER_ID(orderId);
		mod.setPROMOTION_ID(promotionId);
		mod.setPOINTS(increasedPoint);
		mod.setSTATUS(LoyaltyConstants.ORDER_DETAIL_VALID);
		mod.setPOINTS_TYPE_ID(pointTypeId);
		as.appendToMOrderDetail(mod);
	}

}
