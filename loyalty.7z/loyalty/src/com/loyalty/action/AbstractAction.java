package com.loyalty.action;

import com.loyalty.service.ActionService;

public abstract class AbstractAction implements Action {

	protected ActionService as = null;

	public void setAs(ActionService as) {
		this.as = as;
	}

}
