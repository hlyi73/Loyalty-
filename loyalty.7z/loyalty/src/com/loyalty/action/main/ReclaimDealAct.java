package com.loyalty.action.main;

import java.util.Date;

import org.apache.log4j.Logger;

import com.loyalty.action.AbstractAction;
import com.loyalty.action.sub.ChangePointAct;
import com.loyalty.action.sub.FluentChangePointAct;
import com.loyalty.bean.ActionInfo;
import com.loyalty.bean.PromotionInfo;
import com.loyalty.core.AttributeImpl;
import com.loyalty.core.FluentAttributeImpl;
import com.loyalty.core.LoyaltyContext;
import com.loyalty.dto.MAction;
import com.loyalty.dto.MLoyOrder;
import com.loyalty.dto.MMember;
import com.loyalty.dto.MPoints;
import com.loyalty.dto.MPromotion;
import com.loyalty.dto.MRule;
import com.loyalty.exception.LoyaltyException;
import com.loyalty.exception.action.LoyaltyActionException;
import com.loyalty.exception.action.LoyaltyPointException;
import com.loyalty.util.CalendarUtil;
import com.loyalty.util.LoyaltyConstants;
import com.loyalty.util.ObjectUtil;
import com.loyalty.util.OperateUtil;
import com.loyalty.util.StringUtil;

/**
 * ����������
 * 
 * @author Administrator
 * 
 */
public class ReclaimDealAct extends AbstractAction {
	static Logger logger = Logger.getLogger(ReclaimDealAct.class);
	private ChangePointAct pch = null;
	private FluentChangePointAct fpch = null;

	public ReclaimDealAct() {
		pch = (ChangePointAct) (ObjectUtil.getAction(ChangePointAct.class));
		fpch = (FluentChangePointAct) (ObjectUtil.getAction(FluentChangePointAct.class));
	}

	/**
	 * ׷�ػ���
	 * 
	 * @param orderId
	 */
	public Boolean reclaim(MAction action, LoyaltyContext ctx) throws Exception {
		String memberId = ctx.getMemberId();
		String orderId = ctx.getOrderId();
		Date sysDate = CalendarUtil.resetHMSToZero(ctx.getCtxDate());
		Boolean doSuccess = false;
		if (null == sysDate) {
			throw new LoyaltyActionException("����������:" + "sysDate is not exist.");
		}
		if (null == action) {
			throw new LoyaltyActionException("����������:" + "action is null.");
		}
		String sourceAttrId = action.getFROM_ATTR_ID();// ��ȡ��Դ����
		String operation = action.getOPERATE();// ��������
		String pointTypeId = action.getPOINT_TYPE_ID();// ��û�������
		if (StringUtil.nullToWhiteStr(pointTypeId).length() == 0) {
			throw new LoyaltyActionException("����������:" + "pointTypeId is null.");
		}
		String value = action.getCRITERIA_VALUE(); // ����ֵ
		//add start 2014/04/18 liuxingya
//		if (value == null || "".equals(value)) {
//			String valueAttrId = action.getVALUE_ATTR_ID();
//			PromotionService db = PromotionService.getInstance();
//			MAttributes attr = db.getMAttributes(valueAttrId);
//			if (LoyaltyConstants.PROMOTION_SOURCE_REAL_TIME.equals(attr.getATTR_TYPE())) {
//				value = (String)ctx.getParams().get(attr.getFIELD_NAME());
//			}
//		}
		//add end 2014/04/18 liuxingya
		MMember mmember = as.getMMemberByMemberId(memberId);
		if (null == mmember) {
			throw new LoyaltyActionException("����������:" + "��Ա is not exist.");
		}
		MPoints mpoints = as.getMPointsByPointTypeIdAndMemberId(pointTypeId,
				mmember.getID());
		if (null == mpoints) {
			throw new LoyaltyActionException("����������:" + "��Ա����<" + pointTypeId
					+ ":" + mmember.getID() + "> is not exist.");
		}
		MLoyOrder mlo = null;
		if (StringUtil.nullToWhiteStr(orderId).length() != 0) {
			mlo = as.getMLoyOrderByOrderId(orderId);// ��ȡ����
			if (null == mlo) {
				throw new LoyaltyActionException("����������:" + "����<" + orderId
						+ "> is not exist.");
			}
		}
		MRule mr = as.getMRuleByRuleId(action.getRULE_ID());// ��ȡ����
		if (null == mr) {
			throw new LoyaltyActionException("����������:" + "����<"
					+ action.getRULE_ID() + "> is not exist.");
		}
		MPromotion mp = as.getMPromotionByPromotionId(mr.getPROMOTION_ID());// ��ȡpromotion
		if (null == mp) {
			throw new LoyaltyActionException("����������:" + "Promotion<"
					+ mr.getPROMOTION_ID() + "> is not exist.");
		}
		Integer reducedPoint = null;
		Integer validPoints = mpoints.getVALID_POINTS();

		if (StringUtil.nullToWhiteStr(sourceAttrId).length() != 0) {
			Object attr = new AttributeImpl(sourceAttrId, ctx).getAttributes();
			String sourceAttrValue = attr.toString();
			if (StringUtil.nullToWhiteStr(operation).length() != 0) {
				reducedPoint = OperateUtil.compute(operation, value, Double
						.valueOf(sourceAttrValue));
			} else {
				reducedPoint = (int) Math
						.floor(Double.valueOf(sourceAttrValue));
			}
		} else {
			if (StringUtil.nullToWhiteStr(value).length() != 0) {
				reducedPoint = Integer.valueOf(value);
			} else {
				doSuccess = true;
				return doSuccess;
			}
		}
		//add start 2014/05/14 hansheng
		// ���ӻ��ֻ���Ʒ�Ľӿ�ҵ��ͨ��url���ã�
		if ("�һ���Ʒ".equals(ctx.getParams().get("p2"))) {
			pch.changPointBaseOnMember(pointTypeId, memberId, sysDate,
					-reducedPoint, mp.getID(), 
					(mlo == null ? null : mlo.getID()), "1", String.valueOf(ctx.getParams().get("p4")),
					String.valueOf(ctx.getParams().get("p1")), String.valueOf(ctx.getParams().get("p2")));
		} else {
			pch.changPointBaseOnMember(pointTypeId, memberId, sysDate,
					-reducedPoint, mp.getID(), 
					(mlo == null ? null : mlo.getID()), "0", "",
					String.valueOf(ctx.getParams().get("p1")), String.valueOf(ctx.getParams().get("p2")));
		}

//		pch.changPointBaseOnMember(pointTypeId, memberId, sysDate,
//				-reducedPoint, mp.getID(), (mlo == null ? null : mlo.getID()));
		//add end 2014/05/14 hansheng
		doSuccess = true;
		return doSuccess;
	}
	
	/**
	 * ׷�ػ���
	 * 
	 * @param orderId
	 */
	public Boolean consumeRealTime(ActionInfo action, LoyaltyContext ctx) throws LoyaltyException {
		
		logger.info("�����  ʵʱ���ֶһ�������ʼִ��.  �����");
		if (ctx.getCtxDate() == null) {
			throw new LoyaltyActionException("ʵʱ���ֶһ�:sysDate is not exist.");
		}
		if (null == action) {
			throw new LoyaltyActionException("ʵʱ���ֶһ�:action is null.");
		}
		// ��û�������
		if (!action.getPointType().isActivity()) {
			throw new LoyaltyActionException("ʵʱ���ֶһ�:pointTypeId is null or invalid.");
		}
		// ��ȡ����
		if (!action.getRule().isActivity()) {
			throw new LoyaltyActionException("ʵʱ���ֶһ�:����<" + action.getRule().getId() + "> is not exist or invalid.");
		}
		// ��ȡ����
		PromotionInfo pi = ctx.getPromotion();
		if (pi == null) {
			throw new LoyaltyActionException("ʵʱ���ֶһ�:����<" + action.getRule().getPromotionId()
					+ "> is not exist.");
		}
		if (ctx.getMember() == null) {
			throw new LoyaltyActionException("ʵʱ���ֶһ�:member is not exist.");
		}
		
		String operation = action.getOperate();// ��������
		// ����ֵ
		String value = action.getValue();// ����ֵ

		int reducedPoint = 0;
		double baseVal = 0;
		if (action.getAttr().isActivity()) {
			
			try {
				baseVal = Double.valueOf(new FluentAttributeImpl(action.getAttr(),
					ctx).getAttributes().toString());
				
				if (baseVal < 0) {
					throw new LoyaltyPointException("ʵʱ���ֶһ�:ָ���һ�����ֵΪ����.",
						LoyaltyConstants.ERRCD_POINT_PARAM_NEGATIVE);
				}
				
				if (com.ruixue.rfw.util.StringUtil.isNotEmpty(operation)) {
					
					reducedPoint = OperateUtil.compute(operation, value, baseVal);
				} else {
					reducedPoint = (int) Math.floor(baseVal);
				}
			} catch (NumberFormatException e) {
				logger.error("��û������ָ�ʽ����ȷ.["+e.getMessage()+"]");
				throw new LoyaltyPointException("�����߻��ֲ���Ϊ��Ч����.",
					LoyaltyConstants.ERRCD_POINT_PARAM_INVALID);
			} catch (NullPointerException e) {
				logger.error("���ֻ��߽��ֵΪ��.["+e.getMessage()+"]");
				throw new LoyaltyPointException("���ֻ��߽��ֵΪ��.",
					LoyaltyConstants.ERRCD_POINT_PARAM_INVALID);
			}
		} else {
			if (com.ruixue.rfw.util.StringUtil.isNotEmpty(value)) {
				try {
					reducedPoint = Integer.valueOf(value);
				} catch (NumberFormatException e) {
					logger.error("��û������ָ�ʽ����ȷ.["+e.getMessage()+"]");
					throw new LoyaltyPointException("�����߻��ֲ���Ϊ��Ч����.",
						LoyaltyConstants.ERRCD_POINT_PARAM_INVALID);
				} catch (NullPointerException e) {
					logger.error("���ֻ��߽��ֵΪ��.["+e.getMessage()+"]");
					throw new LoyaltyPointException("���ֻ��߽��ֵΪ��.",
						LoyaltyConstants.ERRCD_POINT_PARAM_INVALID);
				}
			} else {
				throw new LoyaltyPointException("ʵʱ���ֶһ�:��ǰ����һ�����Ϊ0.");
			}
		}
		fpch.changPointBaseOnMember(action.getPointType(), -reducedPoint, ctx);
		
		logger.info("�����  ʵʱ���ֶһ���������.  �����");
		return true;
	}
}
