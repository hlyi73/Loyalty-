package com.loyalty.action.main;

import java.util.Date;
import java.util.List;

import org.apache.log4j.Logger;

import com.loyalty.action.AbstractAction;
import com.loyalty.action.sub.ChangePointAct;
import com.loyalty.action.sub.ExchangeRateAct;
import com.loyalty.action.sub.FluentChangePointAct;
import com.loyalty.action.sub.ValidityOfTheCalculationAct;
import com.loyalty.bean.ActionInfo;
import com.loyalty.bean.PointTypeInfo;
import com.loyalty.bean.PromotionInfo;
import com.loyalty.core.AttributeImpl;
import com.loyalty.core.FluentAttributeImpl;
import com.loyalty.core.LoyaltyContext;
import com.loyalty.dao.FluentPromotionDAO;
import com.loyalty.dto.MAction;
import com.loyalty.dto.MCustomer;
import com.loyalty.dto.MLoyOrder;
import com.loyalty.dto.MMember;
import com.loyalty.dto.MMemberActiveHis;
import com.loyalty.dto.MMemberCard;
import com.loyalty.dto.MMemberOrg;
import com.loyalty.dto.MMemberTier;
import com.loyalty.dto.MOrderDetail;
import com.loyalty.dto.MPoints;
import com.loyalty.dto.MPromotion;
import com.loyalty.dto.MRule;
import com.loyalty.dto.MTier;
import com.loyalty.dto.MTierDetail;
import com.loyalty.enums.LoyaltyActionEnums;
import com.loyalty.exception.LoyaltyException;
import com.loyalty.exception.action.LoyaltyActionException;
import com.loyalty.exception.action.LoyaltyPointException;
import com.loyalty.generator.CardNoGenerator;
import com.loyalty.generator.NumberGenerator;
import com.loyalty.generator.PrimaryKeyGenerator;
import com.loyalty.message.BaseLoyaltyMessage;
import com.loyalty.message.Message;
import com.loyalty.message.ValidityMessage;
import com.loyalty.util.CalendarUtil;
import com.loyalty.util.CommonUtils;
import com.loyalty.util.DAOUtil;
import com.loyalty.util.LoyaltyConstants;
import com.loyalty.util.NumberUtils;
import com.loyalty.util.ObjectUtil;
import com.loyalty.util.OperateUtil;
import com.loyalty.util.StringUtil;

/**
 * @ClassName: MemberAct
 * @Description: ������<����,��Ա�ж�,����,�ͷ�,����>
 * @author
 */
public class MemberAct extends AbstractAction {
	static Logger logger = Logger.getLogger(MemberAct.class);
	private ChangePointAct pch = null;
	private FluentChangePointAct fpch = null;
	private ExchangeRateAct era = null;
	private ValidityOfTheCalculationAct votca = null;

	public MemberAct() {
		pch = (ChangePointAct) (ObjectUtil.getAction(ChangePointAct.class));
		fpch = (FluentChangePointAct) (ObjectUtil.getAction(FluentChangePointAct.class));
		era = (ExchangeRateAct) (ObjectUtil.getAction(ExchangeRateAct.class));
		votca = (ValidityOfTheCalculationAct) (ObjectUtil
				.getAction(ValidityOfTheCalculationAct.class));
	}

	/**
	 * @Title: adjustTier
	 * @Description: �����ȼ�<����,����>
	 * @param action
	 * @param orderId
	 * @param memberId
	 * @param customerId
	 * @param pragramId
	 * @param actionType
	 * @return flowIsSuccess
	 * @throws Exception
	 */
	public Boolean adjustTier(MAction action, LoyaltyContext ctx)
			throws Exception {
		Boolean flowIsSuccess = false;
		String memberId = ctx.getMemberId();

		String customerId = ctx.getCustomerId();
		String pragramId = ctx.getProgramId();
		String actionType = action.getTYPE().trim();
		Date sysDate = CalendarUtil.resetHMSToZero(ctx.getCtxDate());

		if (null == sysDate) {
			throw new Exception("�ȼ�����:" + "sysDate is not exist.");
		}
		if (StringUtil.nullToWhiteStr(memberId).length() == 0) {
			memberId = ctx.getMember().getId();
		}
		if (com.ruixue.rfw.util.StringUtil.isEmpty(memberId)) {
			throw new Exception("�ȼ�����:" + "memberId is null.");
		}
		// �����Ա���ڷǻ״̬�򷵻�
		if (CommonUtils.isMemberNotActive(StringUtil.nullToWhiteStr(memberId))) {
			flowIsSuccess = true;
			return flowIsSuccess;
		}
		String targetLevel = action.getTARGET_TIER_ID();// ��ȡĿ��ȼ�
		if (StringUtil.nullToWhiteStr(targetLevel).length() == 0) {
			throw new Exception("�ȼ�����:" + "targetLevel is null.");
		}
		// ����Ŀ��ȼ�
		MTier targetMt = as.getMTierById(targetLevel);
		if (null == targetMt) {
			throw new Exception("�ȼ�����:" + "Ŀ��ȼ�<" + targetLevel
					+ "> not found.");
		}
		String targetSeq = targetMt.getSEQUENCE();
		MMemberTier currentMmt = as
				.getActiveMMemberTierByMMemberIdAndMTierClassId(memberId,
						targetMt.getTIER_CLASS_ID(),
						LoyaltyConstants.LOYALTY_ACTIVE);
		if (null == currentMmt) {
			throw new Exception("�ȼ�����:" + "��ǰ�ȼ�<" + memberId + ":"
					+ targetMt.getTIER_CLASS_ID() + "> not found.");
		}
		String currentLevel = currentMmt.getTIER();
		MTier currentMt = as.getMTierById(currentLevel);
		// ��ȡ��ǰ�ȼ������
		String currentSeq = currentMt.getSEQUENCE();
		// ����ǰ�ȼ���Ϊ��Ч
		currentMmt.setACTIVE_FLAG(LoyaltyConstants.LOYALTY_UNACTIVE);
		// �ж������ͽ����ĺϷ���
		if (actionType
				.equalsIgnoreCase(LoyaltyConstants.ACTION_ACTIONTYPE_M_UPGRADE)) {
			if (Integer.parseInt(currentSeq) >= Integer.parseInt(targetSeq)) {
				logger.debug("��������:Ŀ��ȼ����ڵ��ڵ�ǰ�ȼ�,����������.");
				flowIsSuccess = true;
				return flowIsSuccess;
			}
		} else if (actionType
				.equalsIgnoreCase(LoyaltyConstants.ACTION_ACTIONTYPE_M_DEGRADE)) {
			if (Integer.parseInt(currentSeq) <= Integer.parseInt(targetSeq)) {
				logger.debug("��������:Ŀ��ȼ�С�ڵ��ڵ�ǰ�ȼ�,����������.");
				flowIsSuccess = true;
				return flowIsSuccess;
			}
		}

		// ������Ч��
		Message message = new ValidityOfTheCalculationAct().doCalculation(
				targetMt, ctx, null);// ��Ч�ڼ���
		if (!((BaseLoyaltyMessage) message).getSuccess()) {
			throw new Exception("�ȼ�����:��Ч�ڼ���ʧ��<" + ObjectUtil.toString(targetMt)
					+ ">");
		}

		// ������Ա�ȼ�
		MMemberTier newMmt = new MMemberTier();
		newMmt.setID(PrimaryKeyGenerator.getInstance().generate());
		newMmt.setTIER_CLASS(currentMmt.getTIER_CLASS());
		newMmt.setMEMBER_ID(currentMmt.getMEMBER_ID());
		newMmt.setSTART_DATE(sysDate);
		newMmt.setEND_DATE((Date) ((ValidityMessage) message).getResult());
		newMmt.setACTIVE_FLAG(LoyaltyConstants.LOYALTY_ACTIVE);
		newMmt.setTIER(targetMt.getID());

		// �������ݿ�,��������
		if (!as.adjustMMemberTier(currentMmt, newMmt)) {
			throw new Exception("�ȼ�����:�������ݿ�ʧ��<" + ObjectUtil.toString(newMmt)
					+ ">");
		} else {
			// �Ƿ���»�Ա��
			if (action.getUPDATE_MEMBER_PERIOD() == 1) {
				MMember mm = new MMember();
				mm.setID(newMmt.getMEMBER_ID());
				mm = (MMember) as.getMacDao().selectByPrimaryKey(mm);
				mm.setSTART_DATE(newMmt.getSTART_DATE());
				mm.setEND_DATE(newMmt.getEND_DATE());
				as.getMacDao().updateByPrimaryKey(mm);
			}
			// ����ȼ���ϸ
			MTierDetail newTierDetail = new MTierDetail();
			newTierDetail.setID(PrimaryKeyGenerator.getInstance().generate());
			newTierDetail.setMEMBER_ID(memberId);
			newTierDetail.setCUSTOMER_ID(customerId);
			newTierDetail.setPROGRAM_ID(pragramId);
			newTierDetail.setTIER_CLASS(newMmt.getTIER_CLASS());
			newTierDetail.setAFTER_TIER(newMmt.getID());
			newTierDetail.setBEFORE_TIER(currentMmt.getID());
			newTierDetail.setUPDATE_DATE(sysDate);
			as.appendMTierDetail(newTierDetail);
			flowIsSuccess = true;
		}
		return flowIsSuccess;
	}

	/**
	 * @Title: isMember
	 * @Description: ��Ա�ж�
	 * @param action
	 * @param orderId
	 * @param memberId
	 * @param customerId
	 * @param pragramId
	 * @return isMember
	 * @throws Exception
	 */
	public boolean isMember(MAction action, LoyaltyContext ctx)
			throws Exception {
		Boolean isMember = false;

		String orderId = ctx.getOrderId();
		String customerId = ctx.getCustomerId();
		String pragramId = ctx.getProgramId();
		Date sysDate = CalendarUtil.resetHMSToZero(ctx.getCtxDate());

		if (null == sysDate) {
			throw new Exception("��Ա�ж�:" + "sysDate is not exist.");
		}

		if (StringUtil.nullToWhiteStr(orderId).length() == 0) {
			throw new Exception("��Ա�ж�:" + "orderId is null.");
		}

		MLoyOrder aimOrder = as.getMLoyOrderByOrderId(orderId);
		if (null == aimOrder) {
			throw new Exception("��Ա�ж�:" + "Ŀ�궩�� is not exist.");
		}

		if (StringUtil.nullToWhiteStr(customerId).length() == 0) {
			throw new Exception("��Ա�ж�:" + "customerId is null.");
		}
		if (StringUtil.nullToWhiteStr(pragramId).length() == 0) {
			throw new Exception("��Ա�ж�:" + "pragramId is null.");
		}

		// ��ȡ�ͻ���Ϣ
		MCustomer mCustomer = as.getMCustomerByCustomerId(customerId);
		if (null == mCustomer) {
			throw new Exception("��Ա�ж�:" + "�ͻ���Ϣ is not exist.");
		}

		// ��ȡ��Ա��Ϣ
		MMember mMember = as.getActiveMMemberByCustIdAndProgramId(StringUtil
				.nullToWhiteStr(mCustomer.getID()), StringUtil
				.nullToWhiteStr(aimOrder.getPROGRAM_ID()));
		MMemberTier mmt = null;
		MMemberCard mmc = null;
		if (null == mMember) {
			// ��ȡĿ��ȼ���Ϣ
			MTier mTier = new MTier();
			mTier.setID(action.getTARGET_TIER_ID());
			mTier = (MTier) as.getMacDao().selectByPrimaryKey(mTier);

			// ����ȼ���Ч��
			BaseLoyaltyMessage message = votca.doCalculation(mTier, ctx, null);
			if (message.getSuccess() == false) {
				throw new Exception("��Ա�ж�:" + "��Ч�ڼ���ʧ��<"
						+ ObjectUtil.toString(mTier) + ">.");
			}
			ValidityMessage vMessage = (ValidityMessage) message;

			// ������Ա
			mMember = new MMember();
			mMember.setID(PrimaryKeyGenerator.getInstance().generate());
			mMember.setMEMBER_NUM(NumberGenerator.getInstance().generate());
			mMember.setNAME(mCustomer.getFULL_NAME());
			mMember
					.setMEMBER_TYPE(LoyaltyConstants.MEMBER_MEMBERTYPE_M_INDIVIDUAL);
			mMember.setCUSTOMER_ID(mCustomer.getID());
			mMember.setPROGRAM_ID(pragramId);
			mMember.setJOIN_DATE(sysDate);
			mMember.setCREATE_DATE(sysDate);
			mMember.setSTART_DATE(sysDate);
			mMember.setEND_DATE((Date) vMessage.getResult());
			mMember.setACTIVE_FLAG(LoyaltyConstants.LOYALTY_ACTIVE);
			mMember.setORG_ID(aimOrder.getORG_ID());
			mMember.setCREATE_BY("sadmin");
			mMember.setUPDATE_BY("sadmin");
			mMember.setUPDATE_DATE(sysDate);

			// ������֯����
			MMemberOrg mmo = new MMemberOrg();
			mmo.setID(PrimaryKeyGenerator.getInstance().generate());
			mmo.setMEMBER_ID(mMember.getID());
			mmo.setORG_ID(aimOrder.getORG_ID());
			as.getMacDao().insert(mmo);

			// ������Ա�ȼ�
			mmt = new MMemberTier();
			mmt.setID(PrimaryKeyGenerator.getInstance().generate());
			mmt.setACTIVE_FLAG(LoyaltyConstants.LOYALTY_ACTIVE);
			mmt.setMEMBER_ID(mMember.getID());
			mmt.setSTART_DATE(mMember.getSTART_DATE());
			mmt.setEND_DATE((Date) vMessage.getResult());
			mmt.setTIER(mTier.getID());
			mmt.setTIER_CLASS(mTier.getTIER_CLASS_ID());

			// ������Ա��
			String cardNo = CardNoGenerator.getInstance().generate();
			mmc = new MMemberCard();
			mmc.setID(PrimaryKeyGenerator.getInstance().generate());
			mmc.setCARD_NUMBER(cardNo);
			mmc.setMEMBER_ID(mMember.getID());
			mmc.setSTART_DATE(mMember.getSTART_DATE());
			mmc.setEND_DATE(mMember.getEND_DATE());
			mmc.setSTATUS("MEMBER_CARD_STATUS_HD");

			// ������Ա�״̬�����ʷ
			MMemberActiveHis mmah = new MMemberActiveHis();
			mmah.setID(PrimaryKeyGenerator.getInstance().generate());
			mmah.setCHANGE_DATE(sysDate);
			mmah.setCHANGE_TYPE(LoyaltyActionEnums.LOYALTY_MEMBER_CLUB_JOIN);
			mmah.setCUSTOMER_ID(mMember.getCUSTOMER_ID());
			mmah.setMEMBER_ID(mMember.getID());

			as.appendNewMMemberAndOtherInfos(mMember, mmt, mmc, mmah);
			isMember = true;
		}

		if (mMember.getACTIVE_FLAG() != LoyaltyConstants.LOYALTY_ACTIVE) {
			mMember.setACTIVE_FLAG(LoyaltyConstants.LOYALTY_ACTIVE);
			as.getMacDao().updateByPrimaryKey(mMember);
		}
		// ���µĻ�Աidд�뽻�ױ�
		// aimOrder.setMEMBER_CARD(mmc.getCARD_NUMBER());
		aimOrder.setMEMBER_ID(mMember.getID());
		as.updateMLoyOrder(aimOrder);
		isMember = true;
		return isMember;
	}

	/**
	 * @Title: addBasicPoints
	 * @Description: �ͻ�����
	 * @param action
	 * @param orderId
	 * @param memberId
	 * @return isMember
	 * @throws Exception
	 */
	public boolean addBasicPoints(MAction action, LoyaltyContext ctx)
			throws Exception {
		Boolean doSuccess = false;
		String memberId = ctx.getMemberId();
		if (CommonUtils.isMemberNotActive(StringUtil.nullToWhiteStr(memberId))) {
			doSuccess = true;
			return doSuccess;
		}

		String orderId = ctx.getOrderId();
		Date sysDate = CalendarUtil.resetHMSToZero(ctx.getCtxDate());

		if (null == sysDate) {
			throw new Exception("�ӻ�����:" + "sysDate is not exist.");
		}
		if (null == action) {
			throw new Exception("�ӻ�����:" + "action is null.");
		}
		String sourceAttrId = action.getFROM_ATTR_ID();// ��ȡ��Դ����
		String operation = action.getOPERATE();// ��������
		String pointTypeId = action.getPOINT_TYPE_ID();// ��û�������

		if (StringUtil.nullToWhiteStr(pointTypeId).length() == 0) {
			throw new Exception("�ӻ�����:" + "pointTypeId is null.");
		}
		// ����ֵ
		String value = action.getCRITERIA_VALUE();
		//add start 2014/04/18 liuxingya
//		if (value == null || "".equals(value)) {
//			String valueAttrId = action.getVALUE_ATTR_ID();
//			PromotionService db = PromotionService.getInstance();
//			MAttributes attr = db.getMAttributes(valueAttrId);
//			if (LoyaltyConstants.PROMOTION_SOURCE_REAL_TIME.equals(attr.getATTR_TYPE())) {
//				value = (String)ctx.getParams().get(attr.getFIELD_NAME());
//			}
//		}
		//add end 2014/04/18 liuxingya
		MLoyOrder mlo = null;
		if (StringUtil.nullToWhiteStr(orderId).length() != 0) {
			// ��ȡ����
			mlo = as.getMLoyOrderByOrderId(orderId);
			if (null == mlo) {
				throw new Exception("�ӻ�����:" + "����<" + orderId
						+ "> is not exist.");
			}
		}
		// ��ȡ����
		MRule mr = as.getMRuleByRuleId(StringUtil.nullToWhiteStr(action
				.getRULE_ID()));
		if (null == mr) {
			throw new Exception("�ӻ�����:" + "����<" + action.getRULE_ID()
					+ "> is not exist.");
		}
		// ��ȡpromotion
		MPromotion mp = as.getMPromotionByPromotionId(mr.getPROMOTION_ID());
		if (null == mp) {
			throw new Exception("�ӻ�����:" + "MPromotion<" + mr.getPROMOTION_ID()
					+ "> is not exist.");
		}
		Object attr = null;
		String sourceAttrValue = null;
		Double realBasicPoint = null;
		Integer increasedPoint = null;// ��������
		if (StringUtil.nullToWhiteStr(sourceAttrId).length() != 0) {
			// Դ����ֵ��ȡ
			attr = new AttributeImpl(sourceAttrId, ctx).getAttributes();
			sourceAttrValue = attr.toString();
			realBasicPoint = null;

			// ������������ھͲ�ת��,ֱ����Դ����ֵ����
			if (null != mlo) {
				realBasicPoint = era.convert(Double.valueOf(sourceAttrValue),
						mlo.getCURRENCY(), mlo.getORG_ID());
			} else {
				realBasicPoint = Double.valueOf(sourceAttrValue);
			}

			// ��ȡ��������
			if (StringUtil.nullToWhiteStr(operation).length() != 0) {
				// ͨ����������
				increasedPoint = OperateUtil.compute(operation, value,
						realBasicPoint);
			} else {
				// ������ת��Ϊ����
				increasedPoint = (int) Math.floor(realBasicPoint);
			}

		} else {
			increasedPoint = Integer.valueOf(value);
		}
		// ��ȡ���ֵ
		Integer maximumPointsLimit = mp.getMAX_LIMIT();
		if (NumberUtils.nullToZero(maximumPointsLimit) > 0) {
			if (increasedPoint > maximumPointsLimit) {
				increasedPoint = maximumPointsLimit;
			}
		}
		String promotionType = StringUtil.nullToWhiteStr(mp.getTYPE());
		String source = StringUtil.nullToWhiteStr(mp.getSOURCE());

		// �ж�promotion Type
		// ���ֽ���<T_BONUS>
		if (LoyaltyConstants.PROMOTION_TYPE_BONUS
				.equalsIgnoreCase(promotionType)) {
			// ���ڻ�Ա<M_MEMBER>
			if (LoyaltyConstants.PROMOTION_SOURCE_MEMBER
					.equalsIgnoreCase(source)
					//add start 2014/04/24 liuxingya
					|| LoyaltyConstants.PROMOTION_SOURCE_REAL_TIME.equalsIgnoreCase(source)
					//add end 2014/04/24 liuxingya
					) {
				// �ӷ�����
				//add start 2014/05/16 hansheng
//				pch.changPointBaseOnMember(pointTypeId, memberId, sysDate,
//						increasedPoint, mp.getID(), (mlo == null ? null : mlo
//								.getID()));
				pch.changPointBaseOnMember(pointTypeId, memberId, sysDate,
						increasedPoint, mp.getID(), (mlo == null ? null : mlo
								.getID()), "0","",
								String.valueOf(ctx.getParams().get("p1")),
								String.valueOf(ctx.getParams().get("p2")));
				//add end 2014/05/16 hansheng
				doSuccess = true;
			} else {
				// ���ӽ���������ϸ
				pch.changPointBaseOnNothing(pointTypeId, memberId,
						increasedPoint, mp.getID(), (mlo == null ? null : mlo
								.getID()));
				doSuccess = true;
			}
			return doSuccess;
		} else {
			// �ӷ�����
			pch.changPointBaseOnMember(pointTypeId, memberId, sysDate,
					increasedPoint, mp.getID(), (mlo == null ? null : mlo
							.getID()));
			doSuccess = true;
		}
		return doSuccess;
	}

	/**
	 * @Title: addBasicPoints
	 * @Description: �ͻ�����
	 * @param action
	 * @param orderId
	 * @param memberId
	 * @return isMember
	 * @throws Exception
	 */
	public boolean addRealTimePoints(ActionInfo action, LoyaltyContext ctx)
			throws LoyaltyException {
		logger.info("�����  ʵʱ�����ۼƶ�����ʼִ��  �����");
		if (ctx.getCtxDate() == null) {
			throw new LoyaltyActionException("��ʵʱ����:sysDate is not exist.");
		}
		if (null == action) {
			throw new LoyaltyActionException("��ʵʱ����:action is null.");
		}
		// ��û�������
		if (!action.getPointType().isActivity()) {
			throw new LoyaltyActionException("��ʵʱ����:pointTypeId is null or invalid.");
		}
		// ��ȡ����
		if (!action.getRule().isActivity()) {
			throw new LoyaltyActionException("��ʵʱ����:����<" + action.getRule().getId() + "> is not exist or invalid.");
		}
		// ��ȡ����
		PromotionInfo pi = ctx.getPromotion();
		if (pi == null) {
			throw new LoyaltyActionException("��ʵʱ����:����<" + action.getRule().getPromotionId()
					+ "> is not exist.");
		}
		
		String operation = action.getOperate();// ��������
		// ����ֵ
		String value = action.getValue();

		// ��û�����Դ
		int point = 0;
		double baseVal = 0;
		if (action.getAttr().isActivity()) {
			
			try {
				baseVal = Double.valueOf(new FluentAttributeImpl(action.getAttr(),
					ctx).getAttributes().toString());
				
				if (baseVal < 0) {
					throw new LoyaltyPointException("��ʵʱ����:ָ�������ۼ�ֵΪ����.",
						LoyaltyConstants.ERRCD_POINT_PARAM_NEGATIVE);
				}
				
				if (com.ruixue.rfw.util.StringUtil.isNotEmpty(operation)) {
					point = OperateUtil.compute(operation, value, baseVal);
				} else {
					point = (int) Math.floor(baseVal);
				}
			} catch (NumberFormatException e) {
				logger.error("��û������ָ�ʽ����ȷ.["+e.getMessage()+"]");
				throw new LoyaltyPointException("�����߻��ֲ���Ϊ��Ч����.",
					LoyaltyConstants.ERRCD_POINT_PARAM_INVALID);
			} catch (NullPointerException e) {
				logger.error("���ֻ��߽��ֵΪ��.["+e.getMessage()+"]");
				throw new LoyaltyPointException("���ֻ��߽��ֵΪ��.",
					LoyaltyConstants.ERRCD_POINT_PARAM_INVALID);
			}
		} else {
			point = Integer.valueOf(value);
		}
		
		// ��ȡ���ֵ
		if (pi.getMaxLimit() > 0) {
			point = Math.max(pi.getMaxLimit(), point);
		}
		
		// �ӷ�����
		fpch.changPointBaseOnMember(action.getPointType(), point, ctx);
		
		logger.info("�����  ʵʱ�����ۼƶ�������  �����");
		return true;
	}

	
	/**
	 * @Title: addBonusPoints
	 * @Description: �ͽ�������
	 * @param action
	 * @param orderId
	 * @param memberId
	 * @return doSuccess
	 * @throws Exception
	 */
	public void addBonusPoints(String orderId, String memberId, Date sysDate)
			throws Exception {

		if (CommonUtils.isMemberNotActive(StringUtil.nullToWhiteStr(memberId))) {
			return;
		}

		if (StringUtil.nullToWhiteStr(orderId).length() == 0) {
			throw new LoyaltyActionException("���ӽ�������:" + "orderId is null.");
		}
		if (StringUtil.nullToWhiteStr(memberId).length() == 0) {
			throw new LoyaltyActionException("���ӽ�������:" + "memberId is null.");
		}
		List<MOrderDetail> orderDetails = as
				.findOrderDetailListByOrderId(orderId);
		String odStatus = LoyaltyConstants.ORDER_DETAIL_INVALID;
		for (MOrderDetail orderDetail : orderDetails) {
			odStatus = orderDetail.getSTATUS();
			if (LoyaltyConstants.ORDER_DETAIL_VALID.equals(odStatus)) {
				pch.changPointBaseOnMember(orderDetail.getPOINTS_TYPE_ID(),
						memberId, sysDate, orderDetail.getPOINTS(), orderDetail
								.getPROMOTION_ID(), orderDetail.getORDER_ID());
				logger.info("���ӽ�������:���ӳɹ�" + "<" + orderDetail.getID() + ">");
			}
		}
	}

	/**
	 * ����
	 * 
	 * @param action
	 * @param orderId
	 * @param memberId
	 * @return doSuccess
	 * @throws Exception
	 */
	public boolean reduceScore(MAction action, LoyaltyContext ctx)
			throws Exception {
		String memberId = ctx.getMemberId();
		String orderId = ctx.getOrderId();
		Date sysDate = CalendarUtil.resetHMSToZero(ctx.getCtxDate());
		Boolean doSuccess = false;

		if (null == sysDate) {
			throw new LoyaltyActionException("��������:" + "sysDate is not exist.");
		}

		if (null == action) {
			throw new LoyaltyActionException("��������:" + "action is null.");
		}
		String sourceAttrId = action.getFROM_ATTR_ID();// ��ȡ��Դ����
		String operation = action.getOPERATE();// ��������
		String pointTypeId = action.getPOINT_TYPE_ID();// ��û�������
		if (StringUtil.nullToWhiteStr(pointTypeId).length() == 0) {
			throw new LoyaltyActionException("��������:" + "pointTypeId is null.");
		}
		String value = action.getCRITERIA_VALUE(); // ����ֵ

		MMember mmember = as.getMMemberByMemberId(memberId);
		if (null == mmember) {
			throw new LoyaltyActionException("��������:" + "��Ա is not exist.");
		}
		MPoints mpoints = as.getMPointsByPointTypeIdAndMemberId(pointTypeId,
				mmember.getID());
		if (null == mpoints) {
			throw new LoyaltyActionException("��������:" + "��Ա����<" + pointTypeId
					+ ":" + mmember.getID() + "> is not exist.");
		}
		MLoyOrder mlo = null;
		if (StringUtil.nullToWhiteStr(orderId).length() != 0) {
			mlo = as.getMLoyOrderByOrderId(orderId);// ��ȡ����
			// �е�����:????
			if (null == mlo) {
				throw new LoyaltyActionException("��������:" + "����<" + orderId
						+ "> is not exist.");
			}
		}
		MRule mr = as.getMRuleByRuleId(action.getRULE_ID());// ��ȡ����
		if (null == mr) {
			throw new LoyaltyActionException("��������:" + "����<"
					+ action.getRULE_ID() + "> is not exist.");
		}
		MPromotion mp = as.getMPromotionByPromotionId(mr.getPROMOTION_ID());// ��ȡpromotion
		if (null == mp) {
			throw new LoyaltyActionException("��������:" + "Promotion<"
					+ mr.getPROMOTION_ID() + "> is not exist.");
		}
		Integer reducedPoint = null;
		Integer validPoints = mpoints.getVALID_POINTS();

		if (StringUtil.nullToWhiteStr(sourceAttrId).length() != 0) {
			Object attr = new AttributeImpl(sourceAttrId, ctx).getAttributes();
			String sourceAttrValue = attr.toString();
			if (StringUtil.nullToWhiteStr(operation).length() != 0) {
				reducedPoint = OperateUtil.compute(operation, value, Double
						.valueOf(sourceAttrValue));
			} else {
				reducedPoint = (int) Math
						.floor(Double.valueOf(sourceAttrValue));
			}
		} else {
			if (StringUtil.nullToWhiteStr(value).length() != 0) {
				reducedPoint = Integer.valueOf(value);
			} else {
				doSuccess = true;
				return doSuccess;
			}
		}
		pch.changPointBaseOnMember(pointTypeId, memberId, sysDate,
				-reducedPoint, mp.getID(), (mlo == null ? null : mlo.getID()));
		doSuccess = true;
		return doSuccess;
	}
	
	
	/**
	 * @Title: isMember
	 * @Description: ��Ա�ж�
	 * @param action
	 * @param orderId
	 * @param memberId
	 * @param customerId
	 * @param pragramId
	 * @return isMember
	 * @throws Exception
	 */
	public boolean isMember(ActionInfo action, LoyaltyContext ctx)
			throws LoyaltyException {
		if (!ctx.getOrderInfo().getCustomer().isActivity()) {
			throw new LoyaltyActionException(String.format("�ͻ���Ϣ������.[action=��Ա�ж�, custId=%s]",
				ctx.getOrderInfo().getCustomer().getId()));
		}
		
		if (!ctx.getMember().isActivity()) {
			logger.info(">>>> ��Ա��Ϣ������,�½���Ա������ʼ.");
			
			// ����ȼ���Ч��
			BaseLoyaltyMessage message = votca.doCalculation(action.getTargetTier(), ctx, null);
			if (message.getSuccess() == false) {
				throw new LoyaltyActionException("��Ч�ڼ���ʧ��<"
						+ ObjectUtil.toString(action.getTargetTier()) + ">.[action=��Ա�ж�]");
			}
			ValidityMessage vMessage = (ValidityMessage) message;

			// ������Ա
			MMember mMember = new MMember();
			mMember.setID(PrimaryKeyGenerator.getInstance().generate());
			String memberNum = ctx.getOrderInfo().getCustomer().getMobileTel();
			if (memberNum == null || "".equals(memberNum)) {
				memberNum = NumberGenerator.getInstance().generate();
			}
			mMember.setMEMBER_NUM(memberNum);
			mMember.setNAME(ctx.getOrderInfo().getCustomer().getFullName());
			mMember.setMEMBER_TYPE(
				LoyaltyConstants.MEMBER_MEMBERTYPE_M_INDIVIDUAL);
			mMember.setCUSTOMER_ID(ctx.getOrderInfo().getCustomer().getId());
			mMember.setPROGRAM_ID(ctx.getProgram().getId());
			mMember.setJOIN_DATE(ctx.getCtxDate());
			mMember.setCREATE_DATE(ctx.getCtxDate());
			mMember.setSTART_DATE(ctx.getCtxDate());
			mMember.setEND_DATE((Date) vMessage.getResult());
			mMember.setACTIVE_FLAG(LoyaltyConstants.LOYALTY_ACTIVE);
			mMember.setORG_ID(ctx.getOrg().getId());
			mMember.setCREATE_BY("OrderToPoint");
			mMember.setUPDATE_BY("OrderToPoint");
			mMember.setUPDATE_DATE(ctx.getCtxDate());

			// ������֯����
			MMemberOrg mmo = new MMemberOrg();
			mmo.setID(PrimaryKeyGenerator.getInstance().generate());
			mmo.setMEMBER_ID(mMember.getID());
			mmo.setORG_ID(ctx.getOrg().getId());
			

			// ������Ա�ȼ�
			MMemberTier mmt = new MMemberTier();
			mmt.setID(PrimaryKeyGenerator.getInstance().generate());
			mmt.setACTIVE_FLAG(LoyaltyConstants.LOYALTY_ACTIVE);
			mmt.setMEMBER_ID(mMember.getID());
			mmt.setSTART_DATE(mMember.getSTART_DATE());
			mmt.setEND_DATE((Date) vMessage.getResult());
			mmt.setTIER(action.getTargetTier().getId());
			mmt.setTIER_CLASS(action.getTargetTier().getClassId());
			
			// ������Ա��
//			String cardNo = CardNoGenerator.getInstance().generate();
//			mmc = new MMemberCard();
//			mmc.setID(PrimaryKeyGenerator.getInstance().generate());
//			mmc.setCARD_NUMBER(cardNo);
//			mmc.setMEMBER_ID(mMember.getID());
//			mmc.setSTART_DATE(mMember.getSTART_DATE());
//			mmc.setEND_DATE(mMember.getEND_DATE());
//			mmc.setSTATUS("MEMBER_CARD_STATUS_HD");

			// ������Ա�״̬�����ʷ
//			MMemberActiveHis mmah = new MMemberActiveHis();
//			mmah.setID(PrimaryKeyGenerator.getInstance().generate());
//			mmah.setCHANGE_DATE(sysDate);
//			mmah.setCHANGE_TYPE(LoyaltyActionEnums.LOYALTY_MEMBER_CLUB_JOIN);
//			mmah.setCUSTOMER_ID(mMember.getCUSTOMER_ID());
//			mmah.setMEMBER_ID(mMember.getID());
//			as.appendNewMMemberAndOtherInfos(mMember, mmt, mmc, mmah);
			
			as.getMacDao().insert(mMember);
			as.getMacDao().insert(mmt);
			as.getMacDao().insert(mmo);
			
			ctx.getMember().setId(mMember.getID());
			ctx.getMember().setStartDt(ctx.getCtxDate());
			ctx.getMember().setActivity(true);
			
			MPoints mp;
			for (PointTypeInfo pt : ctx.getProgram().getPointTypes()) {
				if (!pt.isActivity()) continue;
				
				mp = new MPoints();
				mp.setID(PrimaryKeyGenerator.getInstance().generate());
				mp.setMEMBER_ID(mMember.getID());
				mp.setPOINT_TYPE_ID(pt.getId());
				mp.setFOZEN_POINTS(0);
				mp.setGIFT_POINTS(0);
				mp.setLAST_BALANCE(0);
				mp.setLIFETIME_POINTS(0);
				mp.setTOTAL_POINTS(0);
				mp.setVALID_POINTS(0);
				mp.setLIFETIME_VALID_POINTS(0);
				mp.setUPDATE_TIME(ctx.getCtxDate());
				mp.setMEMBER_PERIOD(CalendarUtil.getMemberPeriod(ctx.getMember()));
				as.getMacDao().insert(mp);
			}
		}
		FluentPromotionDAO dao = DAOUtil.getDao(FluentPromotionDAO.class);
		ctx.setMember(dao.selectMemberInfoByPrimaryKey(ctx.getMember().getId()));
		return true;
	}

	public ChangePointAct getPch() {
		return pch;
	}

	public void setPch(ChangePointAct pch) {
		this.pch = pch;
	}
}
