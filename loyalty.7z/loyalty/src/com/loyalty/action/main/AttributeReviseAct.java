package com.loyalty.action.main;

import java.lang.reflect.Field;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.log4j.Logger;

import com.loyalty.action.AbstractAction;
import com.loyalty.action.helper.DataOperateHelper;
import com.loyalty.core.Attribute;
import com.loyalty.core.AttributeImpl;
import com.loyalty.core.LoyaltyContext;
import com.loyalty.dao.FluentPromotionDAO;
import com.loyalty.data.DataType;
import com.loyalty.data.IntegerType;
import com.loyalty.dto.MAction;
import com.loyalty.dto.MAttributes;
import com.loyalty.dto.MMemberAttrData;
import com.loyalty.dto.MPromotionAttrData;
import com.loyalty.generator.PrimaryKeyGenerator;
import com.loyalty.util.CommonUtils;
import com.loyalty.util.DAOUtil;
import com.loyalty.util.DataTypeUtil;
import com.loyalty.util.LoyaltyConstants;
import com.loyalty.util.StringUtil;

/**
 * ����ֵ
 * 
 * @author Administrator
 */
public class AttributeReviseAct extends AbstractAction {
	static Logger logger = Logger.getLogger(AttributeReviseAct.class);

	public AttributeReviseAct() {
	}

	/**
	 * �޸�����
	 * 
	 * @param action
	 * @param ctx
	 * @throws Exception
	 */
	public Boolean revise(MAction action, LoyaltyContext ctx) throws Exception {
		Boolean doSuccess = false;
		String memberId = ctx.getMemberId();
		if (StringUtil.nullToWhiteStr(memberId).length() == 0 ) {
			if (ctx.getMember().isActivity()) {
				memberId = ctx.getMember().getId();
			}
		}
		
		if (com.ruixue.rfw.util.StringUtil.isEmpty(memberId)) {
			throw new Exception("����ֵ�޸�:" + "memberId is null.");
		}
		
		// ��Ա���ڷǻ״̬�Ļ���ֱ�ӷ���
		if (CommonUtils.isMemberNotActive(StringUtil.nullToWhiteStr(memberId))) {
			doSuccess = true;
			return doSuccess;
		}

		String targetAttrId = action.getTARGET_ATTR_ID();// Ŀ������
		if (StringUtil.nullToWhiteStr(targetAttrId).length() == 0) {
			throw new Exception("����ֵ�޸�:" + "targetAttrId is null.");
		}
		MAttributes targetMa = as.getMAttributesById(targetAttrId);
		if (null == targetMa) {
			throw new Exception("����ֵ�޸�:" + "targetAttr is not exist.<"
					+ targetAttrId + ">");
		}
		String attrType = StringUtil.nullToWhiteStr(targetMa.getATTR_TYPE());

		Map<String, Object> fields = new HashMap<String, Object>(1);
		Map<String, String> wheres = new HashMap<String, String>(3);
		if (LoyaltyConstants.ATTRTYPE_MEMBER.equals(attrType)) {
			dealWithMemberType(fields, wheres, targetMa, ctx, action);
		} else if (LoyaltyConstants.ATTRTYPE_PROGRAM.equals(attrType)) {
			dealWithProgramType(fields, wheres, targetMa, ctx, action);
		} else if (LoyaltyConstants.ATTRTYPE_PROMOTION.equals(attrType)) {
			dealWithPromotionType(fields, wheres, targetMa, ctx, action);
		//add start 2014/05/20 hansheng
		} else if (LoyaltyConstants.ATTRTYPE_MEMBERPOINTS.equals(attrType)) {
			dealWithMemberPointsType(fields, wheres, targetMa, ctx, action);
		//add end 2014/05/20 hansheng
		} else if (LoyaltyConstants.ATTRTYPE_TRANSACTION.equals(attrType)) {
			dealWithOrderType(fields, wheres, targetMa, ctx, action);
			//add end 2014/05/20 hansheng
		} else {
			return doSuccess;
		}
		as.updateDynTableData(generateSql(targetMa, fields, wheres));
		if (LoyaltyConstants.ATTRTYPE_MEMBER.equals(attrType)) {
			FluentPromotionDAO fpDao = (FluentPromotionDAO) DAOUtil.getDao(FluentPromotionDAO.class);
			ctx.setMember(fpDao.selectMemberInfoByPrimaryKey(ctx.getMember().getId()));
		}
		doSuccess = true;
		return doSuccess;
	}

	private void dealWithMemberType(final Map<String, Object> fields,
			final Map<String, String> wheres, MAttributes attr,
			LoyaltyContext ctx, MAction action) throws Exception {
		String memberId = ctx.getMemberId();
		if ("M_MEMBER".equals(attr.getTABLE_NAME())) {
			wheres.put("ID", memberId);
		} else {
			wheres.put("MEMBER_ID", memberId);
		}
		fields.put(attr.getFIELD_NAME(), getReviseValue(action, attr, ctx));
	}

	//add start 2014/05/21 hansheng
	private void dealWithMemberPointsType(final Map<String, Object> fields,
			final Map<String, String> wheres, MAttributes attr,
			LoyaltyContext ctx, MAction action) throws Exception {
		String memberId = ctx.getMemberId();
		wheres.put("MEMBER_ID", memberId);
		Object value = getReviseValue(action, attr, ctx);
		IntegerType zero = new IntegerType(0);
		fields.put("VALID_POINTS", value);
		fields.put("LIFETIME_POINTS", value);
		fields.put("TOTAL_POINTS", value);
		fields.put("LIFETIME_VALID_POINTS", value);
		fields.put("FOZEN_POINTS", zero);
		fields.put("LAST_BALANCE", zero);
		fields.put("GIFT_POINTS", zero);
	}
	//add end 2014/05/21 hansheng
	private void dealWithOrderType(final Map<String, Object> fields,
			final Map<String, String> wheres, MAttributes attr,
			LoyaltyContext ctx, MAction action) throws Exception {
		Object value = getReviseValue(action, attr, ctx);
		fields.put(attr.getFIELD_NAME(), value);
		wheres.put("ID", ctx.getOrderInfo().getId());
	}
	
	private void dealWithProgramType(final Map<String, Object> fields,
			final Map<String, String> wheres, MAttributes attr,
			LoyaltyContext ctx, MAction action) throws Exception {
		String memberId = ctx.getMemberId();
		String programId = ctx.getProgramId();
		if (StringUtil.nullToWhiteStr(programId).length() == 0) {
			throw new Exception("����ֵ�޸�:" + "programId is null.");
		}
		List<MMemberAttrData> mAttrData = as.findMAttrDatasByPIdAndMId(
				memberId, programId);
		if (mAttrData != null && mAttrData.size() > 1) {
			throw new Exception("����ֵ�޸�:"
					+ "The length of memberAttrData is not fit.<length:"
					+ mAttrData.size() + ">");
		}
		MMemberAttrData attrData = null;
		if (mAttrData == null || mAttrData.size() == 0) {
			attrData = new MMemberAttrData();
			attrData.setID(PrimaryKeyGenerator.getInstance().generate());
			attrData.setMEMBER_ID(memberId);
			attrData.setPROGRAM_ID(programId);

			// ��ֵ���ȥ
			Class attrClass = attrData.getClass();
			Field field = attrClass.getDeclaredField(StringUtil
					.nullToWhiteStr(attr.getFIELD_NAME()));
			field.setAccessible(true);
			field
					.set(attrData, StringUtil.nullToWhiteStr(attr
							.getINIT_VALUE()));

			as.getMacDao().insert(attrData);
		} else {
			attrData = mAttrData.get(0);
		}
		wheres.put("MEMBER_ID", memberId);
		wheres.put("PROGRAM_ID", programId);
		fields.put(attr.getFIELD_NAME(), getReviseValue(action, attr, ctx));
	}

	private void dealWithPromotionType(final Map<String, Object> fields,
			final Map<String, String> wheres, MAttributes attr,
			LoyaltyContext ctx, MAction action) throws Exception {
		String memberId = ctx.getMemberId();
		String programId = ctx.getProgramId();
		if (StringUtil.nullToWhiteStr(programId).length() == 0) {
			throw new Exception("����ֵ�޸�:" + "programId is null.");
		}
		String promotionId = ctx.getPromotionId();
		if (StringUtil.nullToWhiteStr(promotionId).length() == 0) {
			throw new Exception("����ֵ�޸�:" + "promotionId is null.");
		}

		List<MPromotionAttrData> pAttrData = as
				.findPAttrDatasByPIdAndMIdAndProId(memberId, programId,
						promotionId);
		if (pAttrData != null && pAttrData.size() > 1) {
			throw new Exception("����ֵ�޸�:"
					+ "The length of promotionAttrData is not fit.<length:"
					+ pAttrData.size() + ">");
		}
		MPromotionAttrData attrData = null;
		if (pAttrData == null || pAttrData.size() == 0) {
			attrData = new MPromotionAttrData();
			attrData.setID(PrimaryKeyGenerator.getInstance().generate());
			attrData.setMEMBER_ID(memberId);
			attrData.setPROGRAM_ID(programId);
			attrData.setPROMOTION_ID(promotionId);

			// ��ֵ���ȥ
			Class attrClass = attrData.getClass();
			Field field = attrClass.getDeclaredField(StringUtil
					.nullToWhiteStr(attr.getFIELD_NAME()));
			field.setAccessible(true);
			field
					.set(attrData, StringUtil.nullToWhiteStr(attr
							.getINIT_VALUE()));

			as.getMacDao().insert(attrData);
		} else {
			attrData = pAttrData.get(0);
		}

		wheres.put("MEMBER_ID", memberId);
		wheres.put("PROGRAM_ID", programId);
		wheres.put("PROMOTION_ID", promotionId);
		fields.put(attr.getFIELD_NAME(), getReviseValue(action, attr, ctx));
	}

	private Object getReviseValue(MAction action, MAttributes targetMa,
			LoyaltyContext ctx) throws Exception {

		Object reviseValue = null;// �޸�ֵ
		String sourceAttrId = action.getSOURCE_ATTR_ID();

		if (StringUtil.nullToWhiteStr(sourceAttrId).length() > 0) {
			MAttributes sourceMa = as.getMAttributesById(sourceAttrId);
			if (null == sourceMa) {
				throw new Exception("����ֵ�޸�:" + "sourceAttr is not exist.<"
						+ sourceAttrId + ">");
			}
			Attribute attTo = new AttributeImpl(sourceMa, ctx);
			Object sourceAttrValue = attTo.getAttributes();
			String operate = action.getOPERATE();
			String criteriaValue = action.getCRITERIA_VALUE();
			DataOperateHelper doh = new DataOperateHelper(sourceAttrValue,
					sourceMa.getDATA_TYPE());
			reviseValue = doh.process(criteriaValue, operate);
		} else {
			Attribute attTo = new AttributeImpl(targetMa, ctx);
			Object targetAttrValue = attTo.getAttributes();
			String operate = action.getACTION();
			String criteriaValue = action.getCRITERIA_VALUE();
			DataOperateHelper doh = new DataOperateHelper(targetAttrValue,
					targetMa.getDATA_TYPE());
			reviseValue = doh.process(criteriaValue, operate);
		}
		return reviseValue;
	}

	private String generateSql(MAttributes targetMa,
			Map<String, Object> fields, Map<String, String> wheres) {
		StringBuffer sbu = new StringBuffer();
		sbu.append("update " + targetMa.getTABLE_NAME());
		if (fields.size() > 0) {
			sbu.append(" set ");
			Set<String> fieldsKeys = fields.keySet();
			int i = 0;
			for (String key : fieldsKeys) {
				DataType o = (DataType) fields.get(key);
				if (DataTypeUtil.isNumber(o)) {
					//add start 2014/05/21 hansheng
//					sbu.append(targetMa.getFIELD_NAME() + "=" + o.toString());
					sbu.append(key + "=" + o.toString());
					//add end 2014/05/21 hansheng
				} else if (DataTypeUtil.isCalender(o)) {
					//add start 2014/05/21 hansheng
//					sbu.append(targetMa.getFIELD_NAME() + "=" + "CAST('"
//							+ o.toString() + "' AS DateTime)");
					sbu.append(key + "=" + "CAST('"
							+ o.toString() + "' AS DateTime)");
					//add end 2014/05/21 hansheng
				} else if (DataTypeUtil.isString(o)) {
					//add start 2014/05/21 hansheng
//					sbu.append(targetMa.getFIELD_NAME() + "='" + o.toString()
//							+ "'");
					sbu.append(key + "='" + o.toString()
							+ "'");
					//add end 2014/05/21 hansheng
				}
				i++;
				if (fieldsKeys.size() > i) {
					sbu.append(",");
				}
			}
		}

		if (wheres.size() > 0) {
			sbu.append(" where ");
			Set<String> wheresKeys = wheres.keySet();
			int i = 0;
			for (String key : wheresKeys) {
				sbu.append(key + "='" + wheres.get(key) + "'");
				i++;
				if (wheres.size() > i) {
					sbu.append(" and ");
				}
			}
		}
		return sbu.toString();
	}
}
