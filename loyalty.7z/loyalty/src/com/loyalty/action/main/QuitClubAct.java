package com.loyalty.action.main;

import java.util.Date;

import org.apache.log4j.Logger;
import com.loyalty.action.AbstractAction;

import com.loyalty.core.LoyaltyContext;
import com.loyalty.dto.MMember;
import com.loyalty.dto.MMemberActiveHis;
import com.loyalty.enums.LoyaltyActionEnums;
import com.loyalty.generator.PrimaryKeyGenerator;
import com.loyalty.util.CalendarUtil;
import com.loyalty.util.CommonUtils;
import com.loyalty.util.ObjectUtil;
import com.loyalty.util.StringUtil;

/**
 * @ClassName: QuitClubAct
 * @Description: ������<�˻�>
 */
public class QuitClubAct extends AbstractAction {
	static Logger logger = Logger.getLogger(QuitClubAct.class);

	public QuitClubAct() {
	}

	/**
	 * @Title: quit
	 * @Description: �˻�
	 * @param memberId
	 * @return doSuccess
	 */
	public Boolean quit(LoyaltyContext ctx) throws Exception {
		Boolean doSuccess = false;

		String memberId = StringUtil.nullToWhiteStr(ctx.getMemberId());
		Date sysDate = CalendarUtil.resetHMSToZero(ctx.getCtxDate());

		if (null == sysDate) {
			throw new Exception("�˻�����:" + "sysDate is null.");
		}

		if (memberId.length() == 0) {
			throw new Exception("�˻�����:" + "memberId is null.");
		}

		if (CommonUtils.isMemberNotActive(StringUtil.nullToWhiteStr(memberId))) {
			doSuccess = true;
			return doSuccess;
		}

		MMember requestMember = as.getMMemberByMemberId(memberId);
		if (null == requestMember) {
			throw new Exception("�˻�����:" + "member is not exist.<" + memberId
					+ ">");
		}

		requestMember
				.setACTIVE_FLAG(LoyaltyActionEnums.LOYALTY_MEMBER_CLUB_QUIT);
		
		MMemberActiveHis mmah = new MMemberActiveHis();
		mmah.setID(PrimaryKeyGenerator.getInstance().generate());
		mmah.setCHANGE_DATE(sysDate);
		mmah.setCHANGE_TYPE(LoyaltyActionEnums.LOYALTY_MEMBER_CLUB_QUIT);
		mmah.setCUSTOMER_ID(requestMember.getCUSTOMER_ID());
		mmah.setMEMBER_ID(requestMember.getID());
		
		// ���»�Ա״̬,����״̬�����ʷ
		as.updateMemberAndAppendActiveHis(requestMember, mmah);
		doSuccess = true;
		return doSuccess;
	}
}
