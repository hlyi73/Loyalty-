package com.loyalty.action.main;

import com.loyalty.action.AbstractAction;
import com.loyalty.core.LoyaltyContext;
import com.loyalty.dto.MAction;
import com.loyalty.dto.MCustAction;

/**
 * �ͻ���
 * 
 * @author Administrator
 * 
 */
public class CustomizationAct extends AbstractAction {

	public Boolean toCustomization(MCustAction action, LoyaltyContext ctx)
			throws Exception {
		if (null == action) {
			throw new Exception("�ͻ���:" + "action is null.");
		}

		return as.callMCustCriteria(action.getMETHOD_NAME(), ctx.getMemberId(),
				ctx.getOrderId()) == 0 ? false : true;
	}
}
