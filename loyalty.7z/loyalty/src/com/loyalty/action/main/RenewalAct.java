package com.loyalty.action.main;

import java.util.Date;
import java.util.List;
import org.apache.log4j.Logger;
import com.loyalty.action.AbstractAction;
import com.loyalty.action.sub.UpdateMemberPeriodAct;
import com.loyalty.action.sub.ValidityOfTheCalculationAct;
import com.loyalty.core.LoyaltyContext;
import com.loyalty.dto.MAction;
import com.loyalty.dto.MMember;
import com.loyalty.dto.MMemberActiveHis;
import com.loyalty.dto.MMemberTier;
import com.loyalty.dto.MPoints;
import com.loyalty.dto.MPointsHis;
import com.loyalty.dto.MTier;
import com.loyalty.enums.LoyaltyActionEnums;
import com.loyalty.exception.action.LoyaltyActionException;
import com.loyalty.generator.PrimaryKeyGenerator;
import com.loyalty.message.BaseLoyaltyMessage;
import com.loyalty.message.Message;
import com.loyalty.message.ValidityMessage;
import com.loyalty.util.CalendarUtil;
import com.loyalty.util.LoyaltyConstants;
import com.loyalty.util.NumberUtils;
import com.loyalty.util.ObjectUtil;
import com.loyalty.util.StringUtil;

/**
 * ��������
 */
public class RenewalAct extends AbstractAction {
	static Logger logger = Logger.getLogger(RenewalAct.class);
	private UpdateMemberPeriodAct umph;
	private ValidityOfTheCalculationAct votca;

	public RenewalAct() {
		umph = (UpdateMemberPeriodAct) (ObjectUtil
				.getAction(UpdateMemberPeriodAct.class));
		votca = (ValidityOfTheCalculationAct) (ObjectUtil
				.getAction(ValidityOfTheCalculationAct.class));
	}

	/**
	 * ���¼�����Ч��
	 * 
	 * @param action
	 * @param ctx
	 * @return
	 * @throws Exception
	 */
	public Boolean refreshTier(MAction action, LoyaltyContext ctx)
			throws Exception {
		Boolean doSuccess = false;
		String targetId = action.getTARGET_TIER_ID();
		String type = StringUtil.nullToWhiteStr(action.getTYPE());
		Date sysDate = CalendarUtil.resetHMSToZero(ctx.getCtxDate());
		if (null == sysDate) {
			throw new LoyaltyActionException("��������:" + "sysDate is null.");
		}
		if (StringUtil.nullToWhiteStr(ctx.getMemberId()).length() == 0) {
			throw new LoyaltyActionException("��������:" + "memberId is null.");
		}
		MTier targetMt = null;
		if (StringUtil.nullToWhiteStr(targetId).length() == 0) {
			// ��ȡ��ǰ�ȼ�
			List<MMemberTier> mmtList = as
					.getMMemberTiersByMemberIdAndFlagActive(ctx.getMemberId(),
							LoyaltyConstants.LOYALTY_ACTIVE);
			MMemberTier cmt = mmtList.get(0);
			targetMt = as
					.getMTierById(StringUtil.nullToWhiteStr(cmt.getTIER()));
		} else {
			targetMt = as.getMTierById(targetId);
		}
		if (null == targetMt) {
			throw new LoyaltyActionException("��������:"
					+ "Target tier is not exist.<" + targetId + ">");
		}

		// ��ȡ��Ч��
		Message message = votca.doCalculation(targetMt, ctx, type);// ��Ч�ڼ���
		if (!((BaseLoyaltyMessage) message).getSuccess()) {
			throw new LoyaltyActionException("��������:"
					+ "failed to compute valid date.");
		}
		List<MMemberTier> mmtList = as.getMMemberTiersByMemberIdAndFlagActive(
				ctx.getMemberId(), LoyaltyConstants.LOYALTY_ACTIVE);

		if (null != mmtList) {
			for (MMemberTier mmt : mmtList) {
				mmt.setACTIVE_FLAG(LoyaltyConstants.LOYALTY_UNACTIVE);
			}
		}

		MMemberTier newMTier = new MMemberTier();
		newMTier.setID(PrimaryKeyGenerator.getInstance().generate());
		newMTier.setACTIVE_FLAG(LoyaltyConstants.LOYALTY_ACTIVE);
		newMTier.setMEMBER_ID(ctx.getMemberId());
		newMTier.setTIER(targetMt.getID());
		newMTier.setTIER_CLASS(targetMt.getTIER_CLASS_ID());
		newMTier.setSTART_DATE(sysDate);
		newMTier.setEND_DATE((Date) ((ValidityMessage) message).getResult());

		MMember member = null;

		member = as.getMMemberByMemberId(ctx.getMemberId());
		if (null == member) {
			throw new LoyaltyActionException("��������:"
					+ "member is not exist.<memberId:" + ctx.getMemberId()
					+ ">");
		}

		// ���»�Ա��Ч��
		member.setSTART_DATE(newMTier.getSTART_DATE());
		member.setEND_DATE(newMTier.getEND_DATE());

		as.getMacDao().updateByPrimaryKey(member);

		// �����ֱ��������Ƶ�������ʷ����ȥ
		List<MPoints> pList = as.findMPointsByMemberId(ctx.getMemberId());
		String currentPeriod = CalendarUtil.getMemberPeriod(ctx.getMemberId());

		for (MPoints p : pList) {
			// ����һ��������ʷ
			MPointsHis his = new MPointsHis();
			his.setID(PrimaryKeyGenerator.getInstance().generate());
			his.setMEMBER_ID(p.getMEMBER_ID());
			his.setPOINTS_TYPE_ID(p.getPOINT_TYPE_ID());
			his.setTOTAL_POINTS(NumberUtils.nullToZero(p.getTOTAL_POINTS()));
			his.setPOINTS(NumberUtils.nullToZero(p.getVALID_POINTS()));
			his.setSTART_DATE(member.getSTART_DATE());
			his.setEND_DATE(member.getEND_DATE());
			his.setMEMBER_PERIOD(p.getMEMBER_PERIOD());
			as.getMacDao().insert(his);
			// ���»��ּ�¼
			p.setLAST_BALANCE(NumberUtils.nullToZero(p.getVALID_POINTS()));
			p.setVALID_POINTS(0);
			p.setLIFETIME_VALID_POINTS(NumberUtils.nullToZero(p
					.getVALID_POINTS())
					+ NumberUtils.nullToZero(p.getLAST_BALANCE()));
			p.setMEMBER_PERIOD(currentPeriod);
			p.setTOTAL_POINTS(0);
			p.setFOZEN_POINTS(0);

			p.setUPDATE_TIME(CalendarUtil.getCurrentDate());
			as.getMacDao().updateByPrimaryKey(p);
		}
		// �ǻ�Ա�״̬�����ʷ
		MMemberActiveHis mmah = new MMemberActiveHis();
		mmah.setID(PrimaryKeyGenerator.getInstance().generate());
		mmah.setCHANGE_DATE(sysDate);
		mmah.setCHANGE_TYPE(LoyaltyActionEnums.LOYALTY_MEMBER_CLUB_RENEW);
		mmah.setCUSTOMER_ID(member.getCUSTOMER_ID());
		mmah.setMEMBER_ID(member.getID());
		// ���ºͲ����Ա�ȼ�,������һ����Ա�״̬�����ʷ
		as.updateAndInsertMMemberTier(mmtList, newMTier, member, mmah);
		doSuccess = true;
		return doSuccess;
	}
}
