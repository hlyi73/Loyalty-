package com.loyalty.action;

public interface Action {

}
