package com.loyalty.action.helper;

import com.loyalty.data.DataType;
import com.loyalty.data.DateOperate;
import com.loyalty.data.DateType;
import com.loyalty.data.DoubleOperate;
import com.loyalty.data.DoubleType;
import com.loyalty.data.IntegerOperate;
import com.loyalty.data.IntegerType;
import com.loyalty.data.StringOperate;
import com.loyalty.data.StringType;

import com.loyalty.data.Operates;
import com.loyalty.util.LoyaltyConstants;

public class DataOperateHelper {

	private DataType dt;
	private Operates operate;

	public DataOperateHelper(Object data, String type) {
		init(data, type);
	}

	public Object process(String aim, String operation) {
		if (LoyaltyConstants.CRITERIA_OPERATE_M_PLUS
				.equalsIgnoreCase(operation)
				|| LoyaltyConstants.MODIFY_ATTRIBUTE_M_PLUS
						.equalsIgnoreCase(operation)) {
			return operate.plus(dt, aim);
		} else if (LoyaltyConstants.CRITERIA_OPERATE_M_SUBTRACT
				.equalsIgnoreCase(operation)
				|| LoyaltyConstants.MODIFY_ATTRIBUTE_M_SUBTRACT
						.equalsIgnoreCase(operation)) {
			return operate.substract(dt, aim);
		} else if (LoyaltyConstants.CRITERIA_OPERATE_M_MULTIPLE
				.equalsIgnoreCase(operation)
				|| LoyaltyConstants.MODIFY_ATTRIBUTE_M_MULTIPLE
						.equalsIgnoreCase(operation)) {
			return operate.multiple(dt, aim);
		} else if (LoyaltyConstants.CRITERIA_OPERATE_M_DIVIDE
				.equalsIgnoreCase(operation)
				|| LoyaltyConstants.MODIFY_ATTRIBUTE_M_DIVIDE
						.equalsIgnoreCase(operation)) {
			return operate.divide(dt, aim);
		} else if (LoyaltyConstants.MODIFY_ATTRIBUTE_M_ASSIGN
				.equalsIgnoreCase(operation)) {
			return operate.assign(dt, aim);
		}
		return null;
	}

	private void init(Object data, String type) {
		if (LoyaltyConstants.ATTR_DATATYPE_INTEGER.equalsIgnoreCase(type)) {
			dt = new IntegerType(data);
			operate = new IntegerOperate();
		} else if (LoyaltyConstants.ATTR_DATATYPE_FLOAT.equalsIgnoreCase(type)) {
			dt = new DoubleType(data);
			operate = new DoubleOperate();
		} else if (LoyaltyConstants.ATTR_DATATYPE_DATE.equalsIgnoreCase(type)) {
			dt = new DateType(data);
			operate = new DateOperate();
		} else if (LoyaltyConstants.ATTR_DATATYPE_STRING.equalsIgnoreCase(type)) {
			dt = new StringType(data);
			operate = new StringOperate();
		}

	}
}
