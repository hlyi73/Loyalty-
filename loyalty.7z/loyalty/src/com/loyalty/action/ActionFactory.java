package com.loyalty.action;

import java.util.HashMap;
import java.util.Map;

import com.loyalty.generator.PrimaryKeyGenerator;
import com.loyalty.service.ActionService;
import com.loyalty.util.ObjectUtil;

public class ActionFactory {

	private static ActionFactory af = null;
	private Map<String, Action> actionMap = new HashMap<String, Action>();
	private final static Object key = new Object();

	public static ActionFactory getInstance() {
		if (null == af) {
			synchronized (key) {
				if (null == af) {
					af = new ActionFactory();
				}
			}
		}
		return af;
	}

	private ActionFactory() {
		init();
	}

	/**
	 * ��ʼ��
	 */
	public void init() {
		if (get(ActionService.class.getName()) == null) {
			actionMap.put(ActionService.class.getName(), new ActionService());
		}
	}

	/**
	 * @param key
	 * @return �´���
	 */
	private Action get(String key) {
		return actionMap.get(key);
	}

	public Action add(Class clzz) {

		if (null == clzz) {
			return null;
		}
		Action newAction = null;
		if (null == get(clzz.getName())) {
			try {
				Object newObject = Class.forName(clzz.getName()).newInstance();
				if (!(newObject instanceof Action)) {
					return null;
				}
				newAction = (Action) newObject;
				if (newAction instanceof AbstractAction) {
					Object as = get(ActionService.class.getName());
					if (null == as) {
						init();
					}
					((AbstractAction) newAction).setAs((ActionService) as);
				}
				// ���빤��
				actionMap.put(clzz.getName(), newAction);
			} catch (Exception e) {
				e.printStackTrace();
				return null;
			}
		}
		return newAction;
	}

	/**
	 * @param clzz
	 * @return
	 */
	public Action get(Class clzz) {
		Action target = get(clzz.getName());
		if (null == target) {
			target = add(clzz);
		}
		return target;
	}

	public void cleanAll() {
		actionMap = new HashMap<String, Action>();
	}

	/**
	 * @return
	 */
	public int size() {
		return actionMap.size();
	}
}
