package com.loyalty.exception;

public class PointRecordException extends LoyaltyException {

	private static final long serialVersionUID = 1L;

	public PointRecordException(String info) {
		super(info);
	}
}
