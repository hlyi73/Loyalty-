package com.loyalty.exception;

public class ExchangeRateException extends LoyaltyException {
	
	private static final long serialVersionUID = 1L;
	
	public ExchangeRateException(String info) {
		super(info);
	}     
}
