package com.loyalty.exception.action;

import com.loyalty.exception.LoyaltyException;
import com.loyalty.util.LoyaltyConstants;

public class LoyaltyPointException extends LoyaltyException {

	/** Ĭ�����л�ID */
	private static final long serialVersionUID = 1L;
	
	public LoyaltyPointException(String info) {
		super(info, LoyaltyConstants.ERRCD_POINT_OTHER);
	}
	
	public LoyaltyPointException(String info, int code) {
		super(info, code);
	}
}
