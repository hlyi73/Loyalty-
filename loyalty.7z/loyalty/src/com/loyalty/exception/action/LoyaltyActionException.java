package com.loyalty.exception.action;

import com.loyalty.exception.LoyaltyException;

public class LoyaltyActionException extends LoyaltyException {

	private static final long serialVersionUID = 1L;

	public LoyaltyActionException(String info) {
		super(info);
	}

	public LoyaltyActionException(String info, Throwable t) {
		super(info, t);
	}
}
