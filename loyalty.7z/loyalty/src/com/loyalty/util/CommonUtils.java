package com.loyalty.util;

import com.loyalty.dto.MMember;
import com.loyalty.enums.LoyaltyActionEnums;
import com.loyalty.service.ActionService;

public class CommonUtils {

	private static ActionService as = (ActionService) ObjectUtil
			.getAction(ActionService.class);

	/**
	 * �ж�memberId��״̬�Ƿ��Ǽ���״̬(���)
	 * 
	 * @param id
	 * @return
	 */
	public static Boolean isMemberActive(String id) {
		if (null == id) {
			return false;
		}
		MMember m = as.getMMemberByMemberId(id);
		if (m == null) {
			return false;
		}
		System.out.println(m.getACTIVE_FLAG());
		if (m.getACTIVE_FLAG().equals(LoyaltyConstants.LOYALTY_ACTIVE)) {
			return true;
		}
		return false;
	}

	/**
	 * 
	 * @param id
	 * @return
	 */
	public static Boolean isMemberNotActive(String id) {
		return !isMemberActive(id);
	}
}
