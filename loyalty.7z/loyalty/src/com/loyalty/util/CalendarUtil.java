package com.loyalty.util;

import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;

import com.loyalty.bean.MemberInfo;
import com.loyalty.data.DateType;
import com.loyalty.dto.MMember;
import com.loyalty.service.ActionService;

public class CalendarUtil {
	public final static String FORMAT_24 = "yyyy-MM-dd HH:mm:ss";// 24Сʱ
	public final static String FORMAT_12 = "yyyy-MM-dd hh:mm:ss";// 12Сʱ
	public final static String FORMAT_SHORT = "yyyy-MM-dd 00:00:00";// �� ʱ:��:��

	public static Date getCurrentDate() {
		Calendar calendar = getCalendarInstance(null);
		return calendar.getTime();
	}

	public static Calendar getCalendarInstance(Date sysDate) {
		if (null == sysDate) {
			return Calendar.getInstance();
		}
		Calendar calendar = Calendar.getInstance();
		calendar.setTime(sysDate);
		return calendar;
	}

	public static Date convertStringToDate(String str) throws ParseException {
		return getSimpleDateFormat24().parse(str);
	}

	public static String formatDateToSpecified(Date d) {
		return getShortTimeFormat().format(d);
	}

	public static Date resetHMSToZero(Date d) {
		if (d == null) {
			return null;
		}
		Calendar c = getCalendarInstance(d);
		c.set(Calendar.HOUR, 0);
		c.set(Calendar.MINUTE, 0);
		c.set(Calendar.SECOND, 0);
		return c.getTime();
	}

	public static SimpleDateFormat getSimpleDateFormat24() {
		return new SimpleDateFormat(FORMAT_24);
	}

	public static SimpleDateFormat getSimpleDateFormat12() {
		return new SimpleDateFormat(FORMAT_12);
	}

	public static SimpleDateFormat getShortTimeFormat() {
		return new SimpleDateFormat(FORMAT_SHORT);
	}

	public static String getStringDateFormatted(Date date) {
		return getSimpleDateFormat24().format(date);
	}

	public static Date dateToSpecifiedFormat(Date date) throws ParseException {
		return getSimpleDateFormat24().parse(getStringDateFormatted(date));
	}

	/*
	 * �ж�ʱ����㵥λ :��
	 */
	public static Boolean isUOMYear(String uom) {
		return LoyaltyConstants.POINTTYPE_UOM_M_YEAR.equalsIgnoreCase(uom);

	}

	/*
	 * �ж�ʱ����㵥λ :��
	 */
	public static Boolean isUOMMonth(String uom) {
		return LoyaltyConstants.POINTTYPE_UOM_M_MONTH.equalsIgnoreCase(uom);
	}

	/*
	 * ��ȡ��
	 */
	public static Integer getMonth(Date specified) {
		Calendar calendar = getCalendarInstance(null);
		calendar.setTime(specified);
		return calendar.get(calendar.MONTH) + 1;

	}

	/*
	 * ��ȡ��
	 */
	public static Integer getMonth(Calendar cal) {
		return cal.get(Calendar.MONTH) + 1;
	}

	/*
	 * �������Ӽ�����
	 */
	public static Date increaseTimeByYear(Date specifiedTime, Integer years) {
		Calendar calendar = getCalendarInstance(null);
		calendar.setTime(specifiedTime);
		calendar.add(calendar.YEAR, years);
		return calendar.getTime();
	}

	/*
	 * �������Ӽ�����
	 */
	public static Date increaseTimeByMonth(Date specifiedTime, Integer months) {
		Calendar calendar = getCalendarInstance(null);
		calendar.setTime(specifiedTime);
		calendar.add(calendar.MONTH, months);
		return calendar.getTime();
	}

	/*
	 * �������Ӽ�����
	 */
	public static Date increaseTimeByDay(Date specifiedTime, Integer days) {
		Calendar calendar = getCalendarInstance(null);
		calendar.setTime(specifiedTime);
		calendar.add(calendar.DAY_OF_MONTH, days);
		return calendar.getTime();
	}

	/*
	 * �ж�ָ��ʱ���Ƿ����ָ�����·�
	 */
	public static Boolean isLargerThanSpecifiedMonth(Date time, Integer month) {
		Calendar calendar = getCalendarInstance(null);
		calendar.setTime(time);
		Integer timeMonth = calendar.get(calendar.MONTH) + 1;
		return timeMonth >= month;
	}

	/*
	 * �Ƚ�ָ�����ڵ��յĴ�С
	 */
	public static Boolean isLargerThanSpecifiedDay(Date time, Integer day) {
		Calendar calendar = getCalendarInstance(null);
		calendar.setTime(time);
		Integer timeDay = calendar.get(calendar.DAY_OF_MONTH);
		return timeDay >= day;
	}

	public static Boolean isLessThanSpecifiedMonth(Date time, Integer month) {
		return !isLargerThanSpecifiedMonth(time, month);
	}

	public static Boolean isLessThanSpecifiedDay(Date time, Integer day) {
		return !isLargerThanSpecifiedDay(time, day);
	}

	public static Boolean isLargerThanSpecifiedMonthDay(Date time,
			Integer month, Integer day) {
		return isLargerThanSpecifiedMonth(time, month)
				&& isLargerThanSpecifiedDay(time, day);
	}

	public static Boolean isLessThanSpecifiedMonthDay(Date time, Integer month,
			Integer day) {
		return isLessThanSpecifiedMonth(time, month)
				&& isLessThanSpecifiedDay(time, day);
	}

	/*
	 * �����趨ָ�����ڵ���.��
	 */
	public static Date resetTimeOnMonthAndDay(Date specified, Integer month,
			Integer day) {
		Calendar calendar = getCalendarInstance(null);
		calendar.setTime(specified);
		calendar.set(calendar.MONTH, (month - 1));
		calendar.set(calendar.DAY_OF_MONTH, day);
		return calendar.getTime();
	}

	public static Boolean isLargerThanSpecifiedYear(Date specified, Date date) {
		Calendar calendar = getCalendarInstance(null);
		calendar.setTime(specified);
		Calendar compared = getCalendarInstance(null);
		compared.setTime(date);
		return calendar.get(calendar.YEAR) > compared.get(compared.YEAR);
	}

	public static Boolean isLarger(Date large, Date small) {
		return large.compareTo(small) > 0;
	}

	public static Boolean isEqual(Date large, Date small) {
		return large.compareTo(small) == 0;
	}

	public static Boolean isSmall(Date large, Date small) {
		return !isLarger(large, small);
	}

	public static String compositeYearAndMonthToString(Date specified) {
		Calendar calendar = getCalendarInstance(null);
		calendar.setTime(specified);
		return calendar.get(calendar.YEAR) + "-" + getMonth(calendar);
	}

	/**
	 * ��ȡָ��calendarĳ���·ݵ��������
	 */
	public static int getMaxDaysOfMonth(Calendar cal) {
		return cal.getActualMaximum(Calendar.DAY_OF_MONTH);
	}

	/**
	 * ����Ȼ��:������Ϊ2010-5-22
	 */
	public static Date onDaily(Integer periodOfTime, String validUnits,
			Date sysDate) {
		if (null == periodOfTime || null == validUnits) {
			return null;
		}
		Calendar calendar = CalendarUtil.getCalendarInstance(sysDate);
		Date date = null;
		adjustDate(calendar, periodOfTime, validUnits);
		calendar.add(Calendar.DAY_OF_YEAR, -1);
		date = calendar.getTime();
		return date;
	}

	/**
	 * ����Ȼ�µ��£���Ч��12���£�������Ϊ2010-4-30<��2009-5-23���Ϊ��>
	 * 
	 */
	public static Date onNaturalMonthCurrent(Integer periodOfTime,
			String validUnits, Date sysDate) {
		if (null == periodOfTime || null == validUnits) {
			return null;
		}
		Calendar calendar = CalendarUtil.getCalendarInstance(sysDate);
		Date date = null;
		adjustDate(calendar, periodOfTime, validUnits);
		calendar.add(calendar.MONTH, -1);
		calendar.set(Calendar.DAY_OF_MONTH, CalendarUtil
				.getMaxDaysOfMonth(calendar));
		date = calendar.getTime();
		return date;
	}

	/**
	 * ����Ȼ�����£���Ч��12���£�������Ϊ2010-5-31<��2009-5-23���Ϊ��>
	 */
	public static Date onNaturalMonthNext(Integer periodOfTime,
			String validUnits, Date sysDate) {
		if (null == periodOfTime || null == validUnits) {
			return null;
		}
		Calendar calendar = CalendarUtil.getCalendarInstance(sysDate);
		Date date = null;
		adjustDate(calendar, periodOfTime, validUnits);
		calendar.set(Calendar.DAY_OF_MONTH, CalendarUtil
				.getMaxDaysOfMonth(calendar));
		date = calendar.getTime();
		return date;
	}

	/**
	 * ��Ȼ�굱��:����Ȼ�굱�£���Ч��1�꣬������Ϊ2010-4-30
	 */
	public static Date onNaturalYearCurrent(Integer periodOfTime,
			String validUnits, Date sysDate) {
		if (null == periodOfTime || null == validUnits) {
			return null;
		}
		Calendar calendar = CalendarUtil.getCalendarInstance(sysDate);
		Date date = null;
		adjustDate(calendar, periodOfTime, validUnits);
		calendar.add(calendar.MONTH, -1);
		calendar.set(Calendar.DAY_OF_MONTH, CalendarUtil
				.getMaxDaysOfMonth(calendar));
		date = calendar.getTime();
		return date;
	}

	/**
	 * ��Ȼ������:��Ч��1�꣬������Ϊ2010-5-31
	 */
	public static Date onNaturalYearNext(Integer periodOfTime,
			String validUnits, Date sysDate) {
		if (null == periodOfTime || null == validUnits) {
			return null;
		}
		Calendar calendar = CalendarUtil.getCalendarInstance(sysDate);
		Date date = null;
		adjustDate(calendar, periodOfTime, validUnits);

		calendar.set(Calendar.DAY_OF_MONTH, CalendarUtil
				.getMaxDaysOfMonth(calendar));
		date = calendar.getTime();
		return date;
	}

	/**
	 * ��Ȼ����ĩ
	 */
	public static Date onNaturalYearEnd(Integer periodOfTime,
			String validUnits, Date sysDate) {
		if (null == periodOfTime || null == validUnits) {
			return null;
		}
		Calendar calendar = CalendarUtil.getCalendarInstance(sysDate);
		Date date = null;
		adjustDate(calendar, periodOfTime, validUnits);
		calendar.set(Calendar.MONTH, 11);
		calendar.set(Calendar.DAY_OF_MONTH, CalendarUtil
				.getMaxDaysOfMonth(calendar));
		date = calendar.getTime();
		return date;
	}

	public static void adjustDate(final Calendar calendar,
			final Integer periodOfTime, final String validUnits) {
		if (LoyaltyConstants.TIER_UOM_M_YEAR.equalsIgnoreCase(validUnits)) {
			calendar.add(Calendar.YEAR, periodOfTime);
		} else if (LoyaltyConstants.TIER_UOM_M_MONTH
				.equalsIgnoreCase(validUnits)) {
			calendar.add(Calendar.MONTH, periodOfTime);
		}
	}

	public static String getMemberPeriod(String memberId) {
		if (null == memberId) {
			return null;
		}
		ActionService as = (ActionService) ObjectUtil
				.getAction(ActionService.class);
		MMember m = as.getMMemberByMemberId(memberId);
		Date m_date = m.getSTART_DATE();
		Calendar c = Calendar.getInstance();
		c.setTime(m_date);
		return c.get(Calendar.YEAR) + "-" + getMonth(m_date) + "-"
				+ c.get(Calendar.DAY_OF_MONTH);
	}
	
	// 20140519 SQL�Ż�
	public static String getMemberPeriod(MemberInfo member) {
		if (member == null) {
			return null;
		}
		
		Date m_date = member.getStartDt();
		Calendar c = Calendar.getInstance();
		c.setTime(m_date);
		return c.get(Calendar.YEAR) + "-" + getMonth(m_date) + "-"
				+ c.get(Calendar.DAY_OF_MONTH);
	}

	public static Integer getDayFromSpecifiedDate(Calendar cal) {
		return cal.get(Calendar.DAY_OF_MONTH);
	}
}
