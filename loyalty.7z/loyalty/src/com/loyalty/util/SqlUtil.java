package com.loyalty.util;

public class SqlUtil {

}
