package com.loyalty.util;

import com.loyalty.system.DAOConfig;

public class DAOUtil {

	private DAOUtil() {}
	
	@SuppressWarnings("unchecked")
	public static <T> T getDao(Class<T> clzz) {
		
		return (T) DAOConfig.getDaoManager().getDao(clzz);
	}
}
