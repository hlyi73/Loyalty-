package com.loyalty.util;

import org.apache.commons.lang.builder.ReflectionToStringBuilder;
import org.apache.commons.lang.builder.ToStringStyle;

import com.loyalty.action.Action;
import com.loyalty.action.ActionFactory;

public class ObjectUtil {

	public static ToStringStyle style;

	public static String toString(Object o) {
		ReflectionToStringBuilder rtsb = new ReflectionToStringBuilder(o, style);
		return rtsb.toString();
	}

	public static Boolean isNull(Object o) {
		return null == o ? false : true;
	}

	public static Boolean isNotNull(Object o) {
		return !isNull(o);
	}

	public static Object getAction(Class clzz) {
		return getActionFactory().get(clzz);
	}

	public static ActionFactory getActionFactory() {
		return ActionFactory.getInstance();
	}

}
