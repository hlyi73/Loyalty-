package com.loyalty.util;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.GregorianCalendar;

public class DateUtil {
	/**
	* @Title: parseStringToDate
	* @Description: ��һ���ִ�ת��Ϊ��������
	* @param @param date
	* @param @return   
	* @return Date    
	* @throws
	*/
	public static Date parseStringToDate(String date) { 
	        Date result=null; 
	        String parse=date; 
	        parse=parse.replaceFirst("^[0-9]{4}([^0-9]?)", "yyyy$1"); 
	        parse=parse.replaceFirst("^[0-9]{2}([^0-9]?)", "yy$1"); 
	        parse=parse.replaceFirst("([^0-9]?)[0-9]{1,2}([^0-9]?)", "$1MM$2"); 
	        parse=parse.replaceFirst("([^0-9]?)[0-9]{1,2}( ?)", "$1dd$2"); 
	        parse=parse.replaceFirst("( )[0-9]{1,2}([^0-9]?)", "$1HH$2"); 
	        parse=parse.replaceFirst("([^0-9]?)[0-9]{1,2}([^0-9]?)", "$1mm$2"); 
	        parse=parse.replaceFirst("([^0-9]?)[0-9]{1,2}([^0-9]?)", "$1ss$2"); 
	        DateFormat format=new SimpleDateFormat(parse); 
	        try {
				result=format.parse(date);
			} catch (ParseException e) {
                return null;
			} 
	        return result; 
	    }

	/**
	* @Title: pareFormateDate
	* @Description: TODO
	* @param @param date
	* @param @return   
	* @return String    
	* @throws
	*/
	public static String pareFormateDate(Date date){
		DateFormat format=new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		return format.format(date);
	}
	/**
	* @Title: getSysDate
	* @Description: TODO
	* @param @param date
	* @param @return   
	* @return Date    
	* @throws
	*/
	public static Date  getSysDate(Date date){
		GregorianCalendar gCalendar = new GregorianCalendar();
		gCalendar.setTime(date);
		GregorianCalendar reValue = new GregorianCalendar(gCalendar.get(gCalendar.YEAR),gCalendar.get(gCalendar.MONTH),gCalendar.get(gCalendar.DAY_OF_MONTH));
		return reValue.getTime(); 
	}
}
