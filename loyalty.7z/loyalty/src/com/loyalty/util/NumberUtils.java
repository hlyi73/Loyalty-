package com.loyalty.util;

public class NumberUtils {

	public static Integer nullToZero(Integer n) {
		if (null == n) {
			n = 0;
		}
		return n;
	}
}
