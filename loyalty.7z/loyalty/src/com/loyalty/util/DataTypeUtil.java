package com.loyalty.util;

import com.loyalty.data.DataType;
import com.loyalty.data.DateType;
import com.loyalty.data.DoubleType;
import com.loyalty.data.IntegerType;

public class DataTypeUtil {

	public static boolean isInteger(DataType dt) {
		return dt instanceof IntegerType;
	}

	public static boolean isDouble(DataType dt) {
		return dt instanceof DoubleType;
	}

	public static boolean isCalender(DataType dt) {
		return dt instanceof DateType;
	}

	public static boolean isNumber(DataType dt) {
		return dt.getData() instanceof Number;
	}

	public static boolean isString(DataType dt) {
		return dt.getData() instanceof String;
	}

}
