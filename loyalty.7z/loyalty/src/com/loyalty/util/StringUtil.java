package com.loyalty.util;

public class StringUtil {

	private static String DOT = ".";
	private static String UNDER_LINE = "_";

	public static Boolean isUpperCase(Character c) {
		return c.isUpperCase(c);
	}

	public static Boolean isLowerCase(Character c) {
		return c.isLowerCase(c);
	}

	public static boolean hasLength(CharSequence str) {
		return ((str != null) && (str.length() > 0));
	}

	public static boolean hasLength(String str) {
		return hasLength((CharSequence) str);
	}

	public static boolean hasText(CharSequence str) {
		if (!(hasLength(str))) {
			return false;
		}
		int strLen = str.length();
		for (int i = 0; i < strLen; ++i) {
			if (!(Character.isWhitespace(str.charAt(i)))) {
				return true;
			}
		}
		return false;
	}

	public static String combinate(CharSequence str) {
		StringBuffer sbu = new StringBuffer();
		for (int i = 0; i < str.length(); i++) {
			Character c = str.charAt(i);
			if (0 != i && Character.isUpperCase(c)) {
				sbu.append(StringUtil.UNDER_LINE);
			}
			sbu.append(c);
		}
		return sbu.toString().toUpperCase();
	}

	public static String[] split(String str) {
		return str.split(StringUtil.DOT);
	}

	public static String nullToWhiteStr(String str) {
		if (null == str) {
			str = "";
			return str;
		}
		return str.trim();
	}
}
