package com.loyalty.util;

public class OperateUtil {

	private OperateUtil() {
	}

	/*
	 * 
	 */
	public static Integer compute(String operator, String valueStr, Double point) {
		if (valueStr == null) {
			return (int) Math.floor(point);
		}
		Double value = Double.parseDouble(valueStr);
		Integer result = null;
		if (LoyaltyConstants.CRITERIA_OPERATE_M_PLUS.equalsIgnoreCase(operator)) {
			result = (int) Math.floor(value + point);
		} else if (LoyaltyConstants.CRITERIA_OPERATE_M_SUBTRACT
				.equalsIgnoreCase(operator)) {
			result = (int) Math.floor(value - point);
		} else if (LoyaltyConstants.CRITERIA_OPERATE_M_MULTIPLE
				.equalsIgnoreCase(operator)) {
			result = (int) Math.floor(value * point);
		} else if (LoyaltyConstants.CRITERIA_OPERATE_M_DIVIDE
				.equalsIgnoreCase(operator)) {
			result = (int) Math.floor(point / value);
		}
		return result;
	}

}
