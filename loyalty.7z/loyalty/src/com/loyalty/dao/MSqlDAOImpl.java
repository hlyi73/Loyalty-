package com.loyalty.dao;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import com.ibatis.dao.client.DaoManager;
import com.ibatis.dao.client.template.SqlMapDaoTemplate;

public class MSqlDAOImpl extends SqlMapDaoTemplate implements MSqlDAO{

	public MSqlDAOImpl(DaoManager daoManager) {
		super(daoManager);

	}

	/* (non-Javadoc)
	 * @see com.loyalty.dao.MSqlDAO#selectForDate(java.lang.String)
	 */
	public Map<String, Date> selectForDate(String sql) {
		// TODO Auto-generated method stub
		Map<String,String> map = new HashMap<String,String>();
		map.put("sql", sql);
		HashMap<String,Date> record =(HashMap<String,Date>) queryForObject("sql.selectForDate",map);
		return record;
	}

	/* (non-Javadoc)
	 * @see com.loyalty.dao.MSqlDAO#selectForInteger(java.lang.String)
	 */
	public Map<String, Integer> selectForInteger(String sql) {
		Map<String,String> map = new HashMap<String,String>();
		map.put("sql", sql);
		HashMap<String,Integer> record =(HashMap<String,Integer>) queryForObject("sql.selectForInteger",map);
		return record;
	}

	/* (non-Javadoc)
	 * @see com.loyalty.dao.MSqlDAO#selectForDouble(java.lang.String)
	 */
	public Map<String, Double> selectForDouble(String sql) {
		Map<String,String> map = new HashMap<String,String>();
		map.put("sql", sql);
		HashMap<String,Double> record =(HashMap<String,Double>) queryForObject("sql.selectForDouble",map);
		return record;
	}



	/* (non-Javadoc)
	 * @see com.loyalty.dao.MSqlDAO#selectForString(java.lang.String)
	 */
	public Map<String, String> selectForString(String sql) {
		Map<String,String> map = new HashMap<String,String>();
		map.put("sql", sql);
		HashMap<String,String> record =(HashMap<String,String>) queryForObject("sql.selectForString",map);
		return record;
	}


    /*  (non-Javadoc)
    * <p>Title: callMCustCriteria</p>
    * <p>Description: </p>
    * @param procedureName
    * @param memberId
    * @param orderId
    * @return
    * @see com.loyalty.dao.MSqlDAO#callMCustCriteria(java.lang.String, java.lang.String, java.lang.String)
    */
    public Integer callMCustCriteria(String procedureName,String memberId,String orderId){
    
    	String sql="{call "+procedureName+" (?,?,?)}";
		Map<String,Object> map = new HashMap<String,Object>();
		map.put("sql", sql);
		map.put("PI_MEMBERID", memberId);
		map.put("PI_ORDERID",orderId);
        this.insert("sql.callMCustCriteria",map );
    	Integer record=(Integer) map.get("PO_RETURNCODE");
    	return record;
    }
    /*  (non-Javadoc)
    * <p>Title: getCustomizeAttr_Integer</p>
    * <p>Description: </p>
    * @param procedureName
    * @param memberId
    * @param orderId
    * @return
    * @see com.loyalty.dao.MSqlDAO#getCustomizeAttr_Integer(java.lang.String, java.lang.String, java.lang.String)
    */
    
    public Integer getCustomizeAttr_Integer(String procedureName,String memberId,String orderId){
        
    	String sql="{call "+procedureName+" (?,?,?)}";
		Map<String,Object> map = new HashMap<String,Object>();
		map.put("sql", sql);
		map.put("PI_MEMBERID", memberId);
		map.put("PI_ORDERID",orderId);
        this.insert("sql.getCustomizeAttr_Integer",map );
    	Integer record=(Integer) map.get("PO_RETURNCODE");
    	return record;
    }
    /*  (non-Javadoc)
    * <p>Title: getCustomizeAttr_Double</p>
    * <p>Description: </p>
    * @param procedureName
    * @param memberId
    * @param orderId
    * @return
    * @see com.loyalty.dao.MSqlDAO#getCustomizeAttr_Double(java.lang.String, java.lang.String, java.lang.String)
    */
    
    public Double getCustomizeAttr_Double(String procedureName,String memberId,String orderId){
        
    	String sql="{call "+procedureName+" (?,?,?)}";
		Map<String,Object> map = new HashMap<String,Object>();
		map.put("sql", sql);
		map.put("PI_MEMBERID", memberId);
		map.put("PI_ORDERID",orderId);
        this.insert("sql.getCustomizeAttr_Double",map );
        Double record=(Double) map.get("PO_RETURNCODE");
    	return record;
    }
    /*  (non-Javadoc)
    * <p>Title: getCustomizeAttr_String</p>
    * <p>Description: </p>
    * @param procedureName
    * @param memberId
    * @param orderId
    * @return
    * @see com.loyalty.dao.MSqlDAO#getCustomizeAttr_String(java.lang.String, java.lang.String, java.lang.String)
    */
    
    public String getCustomizeAttr_String(String procedureName,String memberId,String orderId){
        
    	String sql="{call "+procedureName+" (?,?,?)}";
		Map<String,Object> map = new HashMap<String,Object>();
		map.put("sql", sql);
		map.put("PI_MEMBERID", memberId);
		map.put("PI_ORDERID",orderId);
        this.insert("sql.getCustomizeAttr_String",map );
        String record=(String) map.get("PO_RETURNCODE");
    	return record;
    }
    /*  (non-Javadoc)
    * <p>Title: getCustomizeAttr_Date</p>
    * <p>Description: </p>
    * @param procedureName
    * @param memberId
    * @param orderId
    * @return
    * @see com.loyalty.dao.MSqlDAO#getCustomizeAttr_Date(java.lang.String, java.lang.String, java.lang.String)
    */
    
    public Date getCustomizeAttr_Date(String procedureName,String memberId,String orderId){
        
    	String sql="{call "+procedureName+" (?,?,?)}";
		Map<String,Object> map = new HashMap<String,Object>();
		map.put("sql", sql);
		map.put("PI_MEMBERID", memberId);
		map.put("PI_ORDERID",orderId);
        this.insert("sql.getCustomizeAttr_Date",map );
        Date record=(Date) map.get("PO_RETURNCODE");
    	return record;
    }
}
