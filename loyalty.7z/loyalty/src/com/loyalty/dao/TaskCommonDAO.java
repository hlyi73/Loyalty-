package com.loyalty.dao;

import java.util.Date;
import java.util.List;

import com.loyalty.bean.MemberInfo;
import com.loyalty.bean.OrderCondition;
import com.loyalty.bean.OrderInfo;
import com.loyalty.bean.OrganizationInfo;
import com.loyalty.bean.PointTypeInfo;
import com.loyalty.dto.MPoints;

public interface TaskCommonDAO {
	
	OrganizationInfo selectOrganizationInfo(String orgId);
	
	List<OrderInfo> selectOrderInfo(OrderCondition cond);
	
	List<MemberInfo> selectPointsDetails(String groupKey, String pointTypeId);
	
	List<String> selectMemberByProgram(String programId);
	
	Boolean selectPointsDetailByOrder(String orderId);
	
	int updatePointsDetailByOrder(OrderInfo order);
	
	int updateOrderMemberAndProgram(OrderInfo order);
	
	int updatePointsByMember(MPoints mp);
	
	void batchOrder2PointsDetail(List<OrderInfo> orders,
		List<PointTypeInfo> pointTypes, Date sysTime);
	
	
	OrderInfo selectOrderInfoById(String orderId, String programId);
	
	OrganizationInfo selectOrganizationInfoByProgram(String programId);
}
