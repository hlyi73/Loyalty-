package com.loyalty.dao;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.ibatis.dao.client.DaoManager;
import com.ibatis.dao.client.template.SqlMapDaoTemplate;
import com.loyalty.bean.ActionInfo;
import com.loyalty.bean.MemberInfo;
import com.loyalty.bean.PointsDetail;
import com.loyalty.bean.PromotionInfo;
import com.loyalty.bean.RuleInfo;

public class FluentPromotionDAOImpl extends SqlMapDaoTemplate implements FluentPromotionDAO{

	public FluentPromotionDAOImpl(DaoManager daoManager) {
		super(daoManager);
	}
	
	public MemberInfo selectMemberInfoByPrimaryKey(String id) {
		return (MemberInfo) queryForObject("PromotionCoreReduce.selectMemberDetailInfo", id);
	}

	@SuppressWarnings("unchecked")
	public List<RuleInfo> selectRulesByPromotion(String promotionId) {
		return (List<RuleInfo>) queryForList("PromotionCoreReduce.selectProgramPromotions", promotionId);
	}
	
	@SuppressWarnings("unchecked")
	public List<PromotionInfo> selectPromsByProgramId(String programId, String source) {
		Map<String, String> params = new HashMap<String, String>();
		params.put("ID", programId);
		params.put("SOURCE", source);
		return (List<PromotionInfo>) queryForList("PromotionCoreReduce.selectPromotionsByProgramId", params);
	}
	
	@SuppressWarnings("unchecked")
	public List<ActionInfo> selectActionsByRuleId(String ruleId) {
		return (List<ActionInfo>) queryForList("PromotionCoreReduce.selectActByRuleId", ruleId);
	}
	
	@SuppressWarnings("unchecked")
	public List<PointsDetail> selectPointsDetails(String memberId, String ptId) {
		Map<String, String> params = new HashMap<String, String>();
		params.put("MEMID", memberId);
		params.put("PTID", ptId);
		return (List<PointsDetail>) queryForList("PromotionCoreReduce.selectPointsDetails", params);
	}
	
	@SuppressWarnings("unchecked")
	public List<String> selectCustomerGroupByTime() {
		return (List<String>) queryForList("PromotionCoreReduce.selectCustomerGroupByTime");
	}
	
	//add start 2014/05/19 hansheng
	@Override
	public int updateMemberBindFlag(String memberId) {
		return update("PromotionCoreReduce.updateMemberBindFlag", memberId);
	//add end 2014/05/19 hansheng
	}
	
	@Override
	public int updatePointsDetails(PointsDetail pd) {
		return update("PromotionCoreReduce.updatePointsDetails", pd);
	//add end 2014/05/19 hansheng
	}
}
