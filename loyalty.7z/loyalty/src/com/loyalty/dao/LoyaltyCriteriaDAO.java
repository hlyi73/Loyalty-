package com.loyalty.dao;

import java.util.List;
import java.util.Map;

import com.loyalty.dto.MCriteria;
import com.loyalty.dto.MCustCriteria;
import com.loyalty.dto.MExclusiveCondition;
import com.loyalty.dto.MIncludeProduct;
import com.loyalty.dto.MIncludeTier;
import com.loyalty.dto.MLoyOrder;
import com.loyalty.dto.MLoyOrderItem;
import com.loyalty.dto.MMemberTier;
import com.loyalty.dto.MPromotion;
import com.loyalty.dto.MRule;
import com.loyalty.dto.MValueList;

public interface LoyaltyCriteriaDAO {
	 List<MPromotion> selectPromotion(String source,String type,Integer status,String PROGRAM_ID);
	 List<MLoyOrderItem> selectOrderItem(String orderId);
	 List<MMemberTier> selectTierByMember(String memberId,Integer status);
	 List<MIncludeProduct> selectIncludeProductByPromotion(String PROMOTION_ID);
	 List<MIncludeTier> selectIncludeTierByPromotion(String PROMOTION_ID);
	 List<MRule> selectRuleByPromotion(String PROMOTION_ID);
	 List<MCriteria> selectCriteriaByRule(String RULE_ID);
	 List<MCustCriteria> selectCustCriteriaByRule(String RuleId);
	 List<MValueList> selectValuebyCriteria(String ID);
	 List<String> selectExclusiveByProgram(String PROGRAM_ID);
	 List<MExclusiveCondition> selectMExclusiveConditionByME(String EXCLUSIVE_ID);
	 List<String> selectPromotionbyMExclusive(String PROGRAM_ID,String EXCLUSIVE_ID,String CONDITION_TYPE);
	 List<Map<String, String>> selectMMaxvalueByProgram(String PROGRAM_ID,String Order_ID);
	 
}
