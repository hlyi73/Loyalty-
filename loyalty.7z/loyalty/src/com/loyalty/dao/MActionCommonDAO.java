package com.loyalty.dao;

import java.util.Date;
import java.util.List;

import com.loyalty.dto.MAction;
import com.loyalty.dto.MCustAction;
import com.loyalty.dto.MMember;
import com.loyalty.dto.MMemberAttrData;
import com.loyalty.dto.MMemberCard;
import com.loyalty.dto.MMemberTier;
import com.loyalty.dto.MOrderDetail;
import com.loyalty.dto.MPointList;
import com.loyalty.dto.MPoints;
import com.loyalty.dto.MPointsHis;
import com.loyalty.dto.MPointsRate;
import com.loyalty.dto.MPromotionAttrData;
import com.loyalty.dto.MTierClass;

public interface MActionCommonDAO {

	Object insert(Object record);

	int updateByPrimaryKey(Object record);

	int deleteByPrimaryKey(Object record);

	Object selectByPrimaryKey(Object record);

	// ����MAction List
	List<MAction> selectActionsByForeignKey(String RULE_ID);

	// MMember
	MMember selectMMemberByCustomerIdAndProgramId(String custId,
			String programId);

	// MMemberTier
	MMemberTier selectMMemberTierByMMemberIdAndMTierClassIdAndActiveFlag(
			String memberId, String mMierClassId, Integer activeFlag);

	List selectMMemberTierByMMemberIdAndActiveFlag(String memberId,
			Integer activeFlag);

	// MPoints
	MPoints selectMPointsByPointTypeIdAndMemberId(String pointTypeId,
			String memberId);

	// MTierClass
	MTierClass selectMTierClassByProgramId(String programId);

	// MTier
	List selectMTierByMTierClassId(String mTierClassId);

	// ��̬�������
	void updateTableData(String sql);

	MPointsRate selectMPointsRateByCurrencyType(MPointsRate pointsRate);

	// ��ѯ������
	List<MPointList> selectPointListsByTypeIdAndMemberIdThanZeroAndValidStatus(
			MPointList pointList);

	// ��ѯ���ڵ���ϸ
	List<MPointList> selectPointListsByExpiryDate(MPointList pointList);

	//
	List<MOrderDetail> selectOrderDetailList(MOrderDetail orderDetail);

	// ��ѯCustAction List
	List<MCustAction> selectCustActionsByRuleId(String ruleId);

	// ��ѯPointList List
	List<MPointList> selectPointListsByOrderId(MPointList p);

	// ��ѯpoints
	MPoints selectMPointsByMemberIdAndPointTypeIdAndMemberPeriod(MPoints p);

	// ��ѯpointsHis
	MPointsHis selectMPointsHisByMemberIdAndPointTypeIdAndMemberPeriod(
			MPointsHis p);

	// ����points
	List<MPoints> selectPointsByMemberId(MPoints p);

	//
	MMemberCard selectMMemberCardByForeingnKey(MMemberCard c);

	//
	List<MMemberAttrData> selectMAttrDataByPIdAndMId(MMemberAttrData record);

	//
	List<MPromotionAttrData> selectPAttrDatasByPIdAndMIdAndProId(
			MPromotionAttrData record);

	List<MPoints> selectMPointsByMId(MPoints record);

	MPointsHis selectMPointsHisByMIdAndPidAndMPeriod(MPointsHis record);
}
