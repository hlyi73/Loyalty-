package com.loyalty.dao;

import java.util.Date;
import java.util.Map;

public interface MSqlDAO {
   Map<String,String> selectForString(String sql);
   Map<String,Integer> selectForInteger(String sql);
   Map<String,Double> selectForDouble(String sql);
   Map<String,Date> selectForDate(String sql);
   Integer callMCustCriteria(String procedureName,String memberId,String orderId);
   Integer getCustomizeAttr_Integer(String procedureName,String memberId,String orderId);
   Double  getCustomizeAttr_Double(String procedureName,String memberId,String orderId);
   String getCustomizeAttr_String(String procedureName,String memberId,String orderId);
   Date getCustomizeAttr_Date(String procedureName,String memberId,String orderId);
}
