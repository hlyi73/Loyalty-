package com.loyalty.dao;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.ibatis.dao.client.DaoManager;
import com.ibatis.dao.client.template.SqlMapDaoTemplate;
import com.loyalty.dto.MAction;
import com.loyalty.dto.MCustAction;
import com.loyalty.dto.MMember;
import com.loyalty.dto.MMemberAttrData;
import com.loyalty.dto.MMemberCard;
import com.loyalty.dto.MMemberTier;
import com.loyalty.dto.MOrderDetail;
import com.loyalty.dto.MPointList;
import com.loyalty.dto.MPoints;
import com.loyalty.dto.MPointsHis;
import com.loyalty.dto.MPointsRate;
import com.loyalty.dto.MPromotionAttrData;
import com.loyalty.dto.MTier;
import com.loyalty.dto.MTierClass;
import com.loyalty.util.CalendarUtil;
import com.loyalty.util.LoyaltyConstants;
import com.loyalty.util.StringUtil;

public class MActionCommonDAOImpl extends SqlMapDaoTemplate implements
		MActionCommonDAO {

	public MActionCommonDAOImpl(DaoManager daoManager) {
		super(daoManager);
	}

	// �����¼
	public Object insert(Object record) {
		return insert(parse(record) + ".abatorgenerated_insert", record);
	}

	// ���¼�¼
	public int updateByPrimaryKey(Object record) {
		int rows = update(
				parse(record) + ".abatorgenerated_updateByPrimaryKey", record);
		return rows;
	}

	// ɾ����¼
	public int deleteByPrimaryKey(Object record) {

		int rows = delete(
				parse(record) + ".abatorgenerated_deleteByPrimaryKey", record);
		return rows;
	}

	// ѡ���¼
	public Object selectByPrimaryKey(Object record) {

		Object returnVal = queryForObject(parse(record)
				+ ".abatorgenerated_selectByPrimaryKey", record);

		return returnVal;
	}

	// ͨ��rule_id����MAction
	public List<MAction> selectActionsByForeignKey(String RULE_ID) {
		MAction key = new MAction();
		key.setRULE_ID(RULE_ID);
		List<MAction> actions = (List<MAction>) queryForList(
				"M_ACTION_COMMON.SELECT_MACTIONS_BY_FOREIGN_KEY", key);
		return actions;
	}

	// MMember
	public MMember selectMMemberByCustomerIdAndProgramId(String custId,
			String programId) {

		MMember key = new MMember();
		key.setCUSTOMER_ID(custId);
		key.setPROGRAM_ID(programId);
		key.setEND_DATE(CalendarUtil.getCurrentDate());
		key.setACTIVE_FLAG(LoyaltyConstants.LOYALTY_ACTIVE);
		MMember record = (MMember) queryForObject(
				"M_ACTION_COMMON.SELECT_M_MEMBER_BY_CUSTOMER_ID_AND_PROGRAM_ID",
				key);
		return record;
	}

	// MMemberTier
	public MMemberTier selectMMemberTierByMMemberIdAndMTierClassIdAndActiveFlag(
			String memberId, String mMierClassId, Integer activeFlag) {
		MMemberTier key = new MMemberTier();
		key.setMEMBER_ID(memberId);
		key.setACTIVE_FLAG(activeFlag);
		key.setTIER_CLASS(mMierClassId);
		MMemberTier record = (MMemberTier) queryForObject(
				"M_ACTION_COMMON.SELECT_M_MEMBER_TIER_BY_M_MEMBER_ID_AND_M_TIER_CLASS_ID_AND_ACTIVE_FLAG",
				key);
		return record;
	}

	public List selectMMemberTierByMMemberIdAndActiveFlag(String memberId,
			Integer activeFlag) {
		MMemberTier key = new MMemberTier();
		key.setMEMBER_ID(memberId);
		key.setACTIVE_FLAG(activeFlag);
		List record = (List) queryForList(
				"M_ACTION_COMMON.SELECT_M_MEMBER_TIER_BY_M_MEMBER_ID_AND_M_TIER_CLASS_ID_AND_ACTIVE_FLAG",
				key);
		return record;
	}

	// MPoints
	public MPoints selectMPointsByPointTypeIdAndMemberId(String pointTypeId,
			String memberId) {
		MPoints key = new MPoints();
		key.setPOINT_TYPE_ID(pointTypeId);
		key.setMEMBER_ID(memberId);
		MPoints record = (MPoints) queryForObject(
				"M_ACTION_COMMON.SELECT_M_POINTS_BY_POINT_TYPE_ID_AND_MEMBER_ID",
				key);
		return record;
	}

	public MTierClass selectMTierClassByProgramId(String programId) {
		MTierClass key = new MTierClass();
		key.setPROGRAM_ID(programId);
		MTierClass record = (MTierClass) queryForObject(
				"M_ACTION_COMMON.SELECT_M_TIER_CLASS_BY_PROGRAM_ID", key);
		return record;
	}

	public List selectMTierByMTierClassId(String tierClassId) {
		MTier key = new MTier();
		key.setTIER_CLASS_ID(tierClassId);
		List record = (List) queryForList(
				"M_ACTION_COMMON.SELECT_M_TIER_BY_M_TIER_CLASS_ID", key);
		return record;
	}

	public void updateTableData(String sql) {
		Map<String, String> map = new HashMap<String, String>();
		map.put("sql", sql);
		this.update("M_ACTION_COMMON.UPDATE_TABLE_DATA", map);
	}

	private String parse(Object o) {
		String classInfo = o.getClass().toString();
		CharSequence subSequence = classInfo
				.subSequence(22, classInfo.length());
		String tableName = StringUtil.combinate(subSequence);
		return tableName;
	}

	public MPointsRate selectMPointsRateByCurrencyType(MPointsRate pointsRate) {

		return (MPointsRate) queryForObject(
				"M_ACTION_COMMON.SELECT_M_POINTS_RATE_BY_CURRENCY_TYPE",
				pointsRate);
	}

	public List<MPointList> selectPointListsByTypeIdAndMemberIdThanZeroAndValidStatus(
			MPointList pointList) {
		return (List<MPointList>) queryForList(
				"M_ACTION_COMMON.SELECT_POINTLISTS_BY_TYPE_ID_AND_MEMBER_ID_THAN_ZERO_AND_VALID_STATUS",
				pointList);
	}

	public List<MPointList> selectPointListsByExpiryDate(MPointList pointList) {
		return (List<MPointList>) queryForList(
				"M_ACTION_COMMON.SELECT_POINT_LISTS_BY_EXPIRY_DATE", pointList);
	}

	public List<MOrderDetail> selectOrderDetailList(MOrderDetail orderDetail) {
		return (List<MOrderDetail>) queryForList(
				"M_ACTION_COMMON.SELECT_ORDER_DETAIL_LIST", orderDetail);
	}

	public List<MCustAction> selectCustActionsByRuleId(String ruleId) {
		MCustAction mca = new MCustAction();
		mca.setRULE_ID(ruleId);
		return (List<MCustAction>) queryForList(
				"M_ACTION_COMMON.SELECT_CUST_ACTIONS_BY_RULE_ID", mca);
	}

	public List<MPointList> selectPointListsByOrderId(MPointList p) {
		return (List<MPointList>) queryForList(
				"M_ACTION_COMMON.SELECT_POINT_LISTS_BY_ORDER_ID", p);
	}

	public MPoints selectMPointsByMemberIdAndPointTypeIdAndMemberPeriod(
			MPoints p) {
		return (MPoints) queryForObject(
				"M_ACTION_COMMON.SELECT_M_POINTS_BY_MEMBER_ID_AND_POINT_TYPE_ID_AND_MEMBER_PERIOD",
				p);
	}

	public MPointsHis selectMPointsHisByMemberIdAndPointTypeIdAndMemberPeriod(
			MPointsHis p) {

		return (MPointsHis) queryForObject(
				"M_ACTION_COMMON.SELECT_M_POINTS_HIS_BY_MEMBER_ID_AND_POINT_TYPE_ID_AND_MEMBER_PERIOD",
				p);
	}

	public List<MPoints> selectPointsByMemberId(MPoints p) {
		return (List<MPoints>) queryForList(
				"M_ACTION_COMMON.SELECT_POINTS_BY_MEMBER_ID", p);
	}

	public MMemberCard selectMMemberCardByForeingnKey(MMemberCard c) {

		return (MMemberCard) queryForObject(
				"M_ACTION_COMMON.SELECT_M_MEMBER_CARD_BY_FOREINGN_KEY", c);
	}

	public List<MMemberAttrData> selectMAttrDataByPIdAndMId(
			MMemberAttrData record) {

		return (List<MMemberAttrData>) queryForList(
				"M_ACTION_COMMON.SELECT_M_ATTR_DATA_BY_P_ID_AND_M_ID", record);
	}

	public List<MPromotionAttrData> selectPAttrDatasByPIdAndMIdAndProId(
			MPromotionAttrData record) {
		// TODO Auto-generated method stub
		return (List<MPromotionAttrData>) queryForList(
				"M_ACTION_COMMON.SELECT_P_ATTR_DATAS_BY_P_ID_AND_M_ID_AND_PRO_ID",
				record);
	}

	public List<MPoints> selectMPointsByMId(MPoints record) {
		return (List<MPoints>) queryForList(
				"M_ACTION_COMMON.SELECT_MPOINTS_BY_M_ID", record);
	}

	public MPointsHis selectMPointsHisByMIdAndPidAndMPeriod(MPointsHis record) {
		return (MPointsHis) queryForObject(
				"M_ACTION_COMMON.SELECT_MPOINTSHIS_BY_MID_AND_PID_AND_MPERIOD",
				record);
	}

}
