package com.loyalty.dao;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.ibatis.dao.client.DaoManager;
import com.ibatis.dao.client.template.SqlMapDaoTemplate;
import com.loyalty.dto.MCriteria;
import com.loyalty.dto.MCustCriteria;
import com.loyalty.dto.MExclusive;
import com.loyalty.dto.MExclusiveCondition;
import com.loyalty.dto.MExclusiveRela;
import com.loyalty.dto.MIncludeProduct;
import com.loyalty.dto.MIncludeTier;
import com.loyalty.dto.MLoyOrderItem;
import com.loyalty.dto.MMemberTier;
import com.loyalty.dto.MOrderDetail;
import com.loyalty.dto.MPromotion;
import com.loyalty.dto.MRule;
import com.loyalty.dto.MValueList;

public class LoyaltyCriteriaDAOImpl extends SqlMapDaoTemplate implements LoyaltyCriteriaDAO{
 
	public LoyaltyCriteriaDAOImpl(DaoManager daoManager) {
        super(daoManager);
    }
    /* (non-Javadoc)
     * @see com.loyalty.dao.LoyaltyCriteriaDAO#selectPromotion(java.lang.String, java.lang.String, java.lang.Integer, java.lang.String)
     */
    @SuppressWarnings("unchecked")
	public List<MPromotion> selectPromotion(String source,String type,Integer status,String PROGRAM_ID) {
        MPromotion key = new MPromotion();
        key.setSOURCE(source);
        key.setTYPE(type);
        key.setACTIVE_STATUS(status);
        key.setPROGRAM_ID(PROGRAM_ID);
        List<MPromotion> record = (List<MPromotion>) queryForList("LOYALTY_CRITERIA.selectMPromotion", key);
        return record;
    }	
    
	/* (non-Javadoc)
	 * @see com.loyalty.dao.LoyaltyCriteriaDAO#selectOrderItem(java.lang.String)
	 */
	@SuppressWarnings("unchecked")
	public List<MLoyOrderItem> selectOrderItem(String orderId) {
        MLoyOrderItem key = new MLoyOrderItem();
        key.setORDER_ID(orderId);		
		List<MLoyOrderItem> lst = (List<MLoyOrderItem>) queryForList("LOYALTY_CRITERIA.selectOrderItemByOrder",key);
		return lst;
	}
	/* (non-Javadoc)
	 * @see com.loyalty.dao.LoyaltyCriteriaDAO#selectTierByMember(java.lang.String, java.lang.Integer)
	 */
	@SuppressWarnings("unchecked")
	public List<MMemberTier> selectTierByMember(String memberId,Integer status){
		MMemberTier key = new MMemberTier();
		key.setMEMBER_ID(memberId);
		key.setACTIVE_FLAG(status);
		List<MMemberTier> record =(List<MMemberTier>) queryForList("LOYALTY_CRITERIA.selectTierByMember",key);
	    return record;
	}
	/* (non-Javadoc)
	 * @see com.loyalty.dao.LoyaltyCriteriaDAO#selectIncludeTierByPromotion(java.lang.String)
	 */
	@SuppressWarnings("unchecked")
    public List<MIncludeTier> selectIncludeTierByPromotion(String PROMOTION_ID) {
        MIncludeTier key = new MIncludeTier();
        key.setPROMOTION_ID(PROMOTION_ID);
        return (List<MIncludeTier>) queryForList("LOYALTY_CRITERIA.selectIncludeTierByPromotion", key);
        
    }
	/* (non-Javadoc)
	 * @see com.loyalty.dao.LoyaltyCriteriaDAO#selectIncludeProductByPromotion(java.lang.String)
	 */
	@SuppressWarnings("unchecked")
	public List<MIncludeProduct> selectIncludeProductByPromotion(String PROMOTION_ID) {
		MIncludeProduct key = new MIncludeProduct();
		key.setPROMOTION_ID(PROMOTION_ID);
		return (List<MIncludeProduct>) queryForList(
				"LOYALTY_CRITERIA.selectIncludeProductByPromotion", key);
	}
	/* (non-Javadoc)
	 * @see com.loyalty.dao.LoyaltyCriteriaDAO#selectRuleByPromotion(java.lang.String)
	 */
	@SuppressWarnings("unchecked")
    public List<MRule> selectRuleByPromotion(String PROMOTION_ID) {
        MRule key = new MRule();
        key.setPROMOTION_ID(PROMOTION_ID);
        return (List<MRule>)queryForList("LOYALTY_CRITERIA.selectRuleByPromotion", key);
        
    }
	/* (non-Javadoc)
	 * @see com.loyalty.dao.LoyaltyCriteriaDAO#selectCriteriaByRule(java.lang.String)
	 */
	@SuppressWarnings("unchecked")
	public List<MCriteria> selectCriteriaByRule(String RULE_ID){
		MCriteria key = new MCriteria();
		key.setRULE_ID(RULE_ID);
		return (List<MCriteria>) queryForList("LOYALTY_CRITERIA.selectCriteriaByRule", key);
	}
	/* (non-Javadoc)
	 * @see com.loyalty.dao.LoyaltyCriteriaDAO#selectCustCriteriaByRule(java.lang.String)
	 */
	@SuppressWarnings("unchecked")
	public List<MCustCriteria> selectCustCriteriaByRule(String RuleId) {
		MCustCriteria key = new MCustCriteria();
		key.setRULE_ID(RuleId);
		return (List<MCustCriteria>) queryForList(
				"LOYALTY_CRITERIA.selectCustCriteriaByRule", key);
	}
	/* (non-Javadoc)
	 * @see com.loyalty.dao.LoyaltyCriteriaDAO#selectValuebyCriteria(java.lang.String)
	 */
	@SuppressWarnings("unchecked")
    public List<MValueList> selectValuebyCriteria(String ID) {
        MValueList key = new MValueList();
        key.setCRITERIA_ID(ID);
        List<MValueList> record = (List<MValueList>) queryForList("LOYALTY_CRITERIA.selectValuebyCriteria", key);
        return record;
    }
	
	 @SuppressWarnings("unchecked")
	public List<String> selectExclusiveByProgram(String PROGRAM_ID){
		 MExclusive key = new MExclusive();
		 key.setPROGRAM_ID(PROGRAM_ID);
		 List<String> record = queryForList("LOYALTY_CRITERIA.selectExclusiveByProgram",key);
		 return record;
	 }
	 @SuppressWarnings("unchecked")
	public List<MExclusiveCondition> selectMExclusiveConditionByME(String EXCLUSIVE_ID) {
	        MExclusiveCondition key = new MExclusiveCondition();
	        key.setEXCLUSIVE_ID(EXCLUSIVE_ID);
	        List<MExclusiveCondition> record = (List<MExclusiveCondition>) queryForList("LOYALTY_CRITERIA.selectMExclusiveConditionByME", key);
	        return record;
	}
    public List<String> selectPromotionbyMExclusive(String PROGRAM_ID,String EXCLUSIVE_ID,String CONDITION_TYPE) {
        MExclusiveRela key = new MExclusiveRela();
        key.setCONDITION_TYPE(CONDITION_TYPE);
        key.setPROGRAM_ID(PROGRAM_ID);
        key.setEXCLUSIVE_ID(EXCLUSIVE_ID);
        List<String> record = (List<String>)queryForList("LOYALTY_CRITERIA.selectPromotionbyMExclusive", key);
        return record;
    }
    
    @SuppressWarnings("unchecked")
	public 	 List<Map<String, String>> selectMMaxvalueByProgram(String PROGRAM_ID,String Order_ID){
    	HashMap<String,String> map= new HashMap<String,String>();
    	map.put("ORDER_ID", Order_ID);
    	map.put("PROGRAM_ID", PROGRAM_ID);
    	List<Map<String, String>> record = (List<Map<String, String>>) queryForList("LOYALTY_CRITERIA.selectMMaxvalueByProgram",map);
    	return record;
    }
}
