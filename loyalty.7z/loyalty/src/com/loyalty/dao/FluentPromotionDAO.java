package com.loyalty.dao;

import java.util.List;

import com.loyalty.bean.ActionInfo;
import com.loyalty.bean.MemberInfo;
import com.loyalty.bean.PointsDetail;
import com.loyalty.bean.PromotionInfo;
import com.loyalty.bean.RuleInfo;

public interface FluentPromotionDAO {
	
	MemberInfo selectMemberInfoByPrimaryKey(String id);
	
	List<RuleInfo> selectRulesByPromotion(String promotionId);
	
	List<PromotionInfo> selectPromsByProgramId(String programId, String source);
	
	List<ActionInfo> selectActionsByRuleId(String ruleId);
	
	List<PointsDetail> selectPointsDetails(String memberId, String ptId);
	
	List<String> selectCustomerGroupByTime();

	//add start 2014/05/19 hansheng
	int updateMemberBindFlag(String memberId);
	//add start 2014/05/19 hansheng
	
	int updatePointsDetails(PointsDetail pd);
}
