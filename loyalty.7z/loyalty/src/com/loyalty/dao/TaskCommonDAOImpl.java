package com.loyalty.dao;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

import com.ibatis.dao.client.DaoManager;
import com.ibatis.dao.client.template.SqlMapDaoTemplate;
import com.loyalty.bean.MemberInfo;
import com.loyalty.bean.OrderCondition;
import com.loyalty.bean.OrderInfo;
import com.loyalty.bean.OrganizationInfo;
import com.loyalty.bean.PointTypeInfo;
import com.loyalty.dto.MPointList;
import com.loyalty.dto.MPoints;
import com.loyalty.enums.LoyaltyActionEnums;
import com.loyalty.generator.PrimaryKeyGenerator;
import com.loyalty.util.CalendarUtil;

public class TaskCommonDAOImpl extends SqlMapDaoTemplate implements TaskCommonDAO{

	private static final Lock lock = new ReentrantLock();
	
	private static final String SQL_UPDATE_ORDER_MEM_PROG = "TaskCommon.updateOrderMemberAndProgram";
	private static final String SQL_UPDATE_POINT_DETAIL = "TaskCommon.updatePointsDetailByOrder";
	private static final String SQL_UPDATE_POINTS = "TaskCommon.updatePointsByMember";
	private static final String SQL_INSERT_POINT_DETAIL = "M_POINT_LIST.abatorgenerated_insert";
	
	private static final String PROMOTION_NAME = "����ת����";
	private static final String PROMOTION_TYPE = "M_ORDER";
	private static final String ACT_TYPE = "����";
	private static final String SUB_ACT_TYPE = "����ת����";
	
	public TaskCommonDAOImpl(DaoManager daoManager) {
		super(daoManager);
	}
	
	@SuppressWarnings("unchecked")
	public List<OrderInfo> selectOrderInfo(OrderCondition cond) {
		return (List<OrderInfo>) queryForList("TaskCommon.selectOrderInfo", cond);
	}
	
	public OrderInfo selectOrderInfoById(String orderId, String programId) {
		Map<String, String> params = new HashMap<String, String>();
		params.put("ORD_ID", orderId);
		params.put("PROGRAM_ID", programId);
		return (OrderInfo) queryForObject("TaskCommon.selectOrderInfoById", params);
	}
	
	public OrganizationInfo selectOrganizationInfoByProgram(String programId) {
		return (OrganizationInfo) queryForObject("TaskCommon.selectOrganizationInfoByProgram", programId);
	}

	public OrganizationInfo selectOrganizationInfo(String orgId) {
		return (OrganizationInfo) queryForObject("TaskCommon.selectOrganizationInfo", orgId);
	}
	
	@SuppressWarnings("unchecked")
	public List<MemberInfo> selectPointsDetails(String groupKey, String pointTypeId) {
		Map<String, String> params = new HashMap<String, String>();
		params.put("KEY", groupKey);
		params.put("PTID", pointTypeId);
		return (List<MemberInfo>) queryForList("TaskCommon.selectPointsDetails", params);
	}
	
	@SuppressWarnings("unchecked")
	public List<String> selectMemberByProgram(String programId) {
		return (List<String>) queryForList("TaskCommon.selectMemberByProgram", programId);
	}
	
	public Boolean selectPointsDetailByOrder(String orderId) {
		return (Boolean) queryForObject("TaskCommon.selectPointsDetailByOrder", orderId);
	}
	
	public int updatePointsDetailByOrder(OrderInfo order) {
		return update(SQL_UPDATE_POINT_DETAIL, order);
	}
	
	public int updateOrderMemberAndProgram(OrderInfo order) {
		return update(SQL_UPDATE_ORDER_MEM_PROG, order);
	}
	
	public int updatePointsByMember(MPoints mp) {
		return update(SQL_UPDATE_POINTS, mp);
	}
	
	public void batchOrder2PointsDetail(List<OrderInfo> orders,
		List<PointTypeInfo> pointTypes, Date sysTime) {
		
		lock.lock();
		
		try {
			this.startBatch();
			MPointList mpl;
			for (OrderInfo i : orders) {
				if (i.getAmount() == null) continue;
				
				//this.updateOrderMemberAndProgram(i);
				
				if (updatePointsDetailByOrder(i) > 0)
					continue;
				
				for (PointTypeInfo pt : pointTypes) {
					if (!pt.isActivity()) continue;
					
					mpl = new MPointList();
					mpl.setID(PrimaryKeyGenerator.getInstance().generate());
					mpl.setMEMBER_ID(i.getMember().getId());
					mpl.setORDER_ID(i.getId());
					mpl.setPOINTS(i.getConvertPoints().intValue());
					mpl.setSTART_DATE(i.getCreateDt());
					mpl.setEND_DATE(i.getUpdateDt());
					mpl.setPOINT_TYPE_ID(pt.getId());
					mpl.setPROMOTION_NAME(PROMOTION_NAME);
					mpl.setPROMOTION_TYPE(PROMOTION_TYPE);
					mpl.setPROCESS_FLAG(LoyaltyActionEnums
						.POINT_LIST_STATUS_HANDLER_POINTLIST_DO_NOTHING);
					mpl.setMEMBER_PERIOD(CalendarUtil.getMemberPeriod(i.getMember()));
					mpl.setBORN_DATE(sysTime);
					mpl.setVALID_FLAG(1);
					mpl.setACT_TYPE(ACT_TYPE);
					mpl.setACT_SUB_TYPE(SUB_ACT_TYPE);
					
					insert(SQL_INSERT_POINT_DETAIL, mpl);
				}
			}
			this.executeBatch();
		} finally {
			lock.unlock();
		}
	}
}
