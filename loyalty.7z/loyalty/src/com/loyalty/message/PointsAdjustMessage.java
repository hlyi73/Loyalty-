package com.loyalty.message;

import java.io.Serializable;

public class PointsAdjustMessage extends BaseLoyaltyMessage implements
		Serializable {

}
