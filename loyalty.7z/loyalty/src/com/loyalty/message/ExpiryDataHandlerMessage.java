package com.loyalty.message;

public class ExpiryDataHandlerMessage extends BaseLoyaltyMessage {

}
