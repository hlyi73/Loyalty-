package com.loyalty.message;

import java.io.Serializable;

public class PointsTransferMessage extends BaseLoyaltyMessage implements
		Serializable {

}
