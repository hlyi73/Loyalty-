package com.loyalty.message;

import java.io.Serializable;

public interface Message extends Serializable {

	public Boolean getSuccess();

	public void setSuccess(Boolean success);

	public void setEx(Exception ex);

	public String getDoInfo();

	public void setDoInfo(String doInfo);

	public int getMsgCode();

	public void setMsgCode(int msgCode);

}
