package com.loyalty.message;

import java.io.Serializable;

import com.loyalty.dto.MTier;

public class ValidityMessage extends BaseLoyaltyMessage implements Serializable {
	private Object result;// ���ؽ��
	private MTier mTier;

	public MTier getMTier() {
		return mTier;
	}

	public void setMTier(MTier tier) {
		mTier = tier;
	}

	public Object getResult() {
		return result;
	}

	public void setResult(Object result) {
		this.result = result;
	}
}
