package com.loyalty.message;

import java.io.Serializable;

public class BaseLoyaltyMessage implements Message, Serializable {
	private Boolean success = false;
	private Exception ex;
	private String doInfo;
	private int msgCode;

	public int getMsgCode() {
		return msgCode;
	}

	public void setMsgCode(int msgCode) {
		this.msgCode = msgCode;
	}

	public Exception getEx() {
		return ex;
	}

	public void setEx(Exception ex) {
		this.ex = ex;
	}

	public String getDoInfo() {
		return doInfo;
	}

	public void setDoInfo(String doInfo) {
		this.doInfo = doInfo;
	}

	public Boolean getSuccess() {
		return success;
	}

	public void setSuccess(Boolean success) {
		this.success = success;
	}

}
