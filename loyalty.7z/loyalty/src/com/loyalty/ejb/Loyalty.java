package com.loyalty.ejb;

import java.util.Map;

import javax.ejb.Remote;

import com.loyalty.exception.LoyaltyException;
import com.loyalty.message.Message;

@Remote
public interface Loyalty {

	public void ForOrder(String strOrderId) throws Exception;

	public void ForMember(String strMemberNum, String strSysDate)
			throws Exception;

	/**
	 * ��ʱ����ķ���
	 */

	public void handlerExpiryPointRecord(String id, String date)
			throws Exception;

	public void pLValidFlagAdjust(String id) throws Exception;

	/**
	 * �ⲿ��ط���
	 * 
	 * @param fromMemId
	 * @param toMemId
	 * @param pointTypeId
	 * @param transPoints
	 * @param sysDateStr
	 * @return
	 */
	public Message transferPoint(String fromMemId, String toMemId,
			String pointTypeId, Integer transPoints, String sysDateStr);

	public Message adjustPoint(String memberId, String pointTypeId,
			Integer adjustPoints, String operate, String sysDateStr);

	//add start 2014/04/15 liuxingya
	public void pointTimely(String memberId, String strSysDate, Map<String, Object> params) 
			throws Exception;
	//add end 2014/04/15 liuxingya
	
	void orderToPoints(String orderId, String programId) throws LoyaltyException;
}
