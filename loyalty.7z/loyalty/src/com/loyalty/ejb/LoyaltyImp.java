package com.loyalty.ejb;

import java.util.Date;
import java.util.Map;
import java.util.Properties;

import javax.annotation.Resource;
import javax.ejb.Remote;
import javax.ejb.SessionContext;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.loyalty.action.sub.PLValidFlagAdjustmentAct;
import com.loyalty.action.sub.PointsAdjustAct;
import com.loyalty.action.sub.PointsExpiryManageAct;
import com.loyalty.action.sub.PointsTransferAct;
import com.loyalty.bean.MemberInfo;
import com.loyalty.bean.OrderInfo;
import com.loyalty.bean.OrganizationInfo;
import com.loyalty.core.PromotionManger;
import com.loyalty.core.PromotionService;
import com.loyalty.dto.MLoyOrder;
import com.loyalty.dto.MLoyProgram;
import com.loyalty.dto.MMember;
import com.loyalty.enums.MessageEnums;
import com.loyalty.exception.LoyaltyException;
import com.loyalty.message.Message;
import com.loyalty.message.PointsAdjustMessage;
import com.loyalty.message.PointsTransferMessage;
import com.loyalty.util.CalendarUtil;
import com.loyalty.util.LoyaltyConstants;
import com.loyalty.util.ObjectUtil;
import com.ruixue.rfw.util.DateUtil;
import com.ruixue.rfw.util.LogUtil;
import com.ruixue.rfw.util.StringUtil;

/**
 * @ClassName: LoyaltyImp
 * @Description: Ӧ�ó���Ľӿ���
 * @author
 * @date Sep 28, 2009 5:39:03 PM
 * 
 */
@Stateless
@Remote
public class LoyaltyImp implements Loyalty {
	@Resource
	private SessionContext cnx;

	static Logger logger = Logger.getLogger(LoyaltyImp.class.getName());
	static {
		try {
			Properties pro = new Properties();
			pro.load(LoyaltyImp.class.getClassLoader().getResourceAsStream(
					"log4j.properties"));
			PropertyConfigurator.configure(pro);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/*
	 * <p>Title: ForMember</p> <p>Description: </p> @param memberId ��ԱID
	 * @return true �ɹ�, false ʧ��

	 * 
	 * @see com.loyalty.ejb.Loyalty#ForMember(java.lang.String)
	 */
	@TransactionAttribute(TransactionAttributeType.REQUIRED)
	public void ForMember(String memberId, String strSysDate) throws Exception {
		try {
			// ȡ�û�Ա����
			logger.info("��ʼ��Ա����" + memberId);

			PromotionService db = PromotionService.getInstance();
			MMember member = db.getMember(memberId);

			logger.info("---ϵͳʱ��---" + strSysDate);
			logger.info("---��Ա����---" + member.getNAME());
			// ��Ŀ�Ĵ�����
			MLoyProgram program = db.getProgram(member.getPROGRAM_ID());
			if (program == null || program.getPROGRAM_ID() == null) {
				logger.info("��Ŀ�����ڵ�");
				return;
			}
			PromotionManger pm = new PromotionManger();
			pm.onMember(member, strSysDate);
			logger.info("��ʼ��Ա����" + memberId);
		} catch (Exception e) {
			logger.info("�����쳣" + e.getMessage());
			// ����ع�
			if (!cnx.getRollbackOnly()) {
				cnx.setRollbackOnly();
			}
			throw e;
		}
		return;
	}

	/*
	 * (non-Javadoc) <p>Title: ForOrder</p> <p>Description: </p> @param
	 * strOrderId @return
	 * 
	 * @see com.loyalty.ejb.Loyalty#ForOrder(java.lang.String)
	 */

	@TransactionAttribute(TransactionAttributeType.REQUIRED)
	public void ForOrder(String strOrderId) throws Exception {
		logger.info("Start to handle order<order id is" + strOrderId + ">");
		try {
			PromotionService db = PromotionService.getInstance();
			MLoyOrder order = db.getOrder(strOrderId);
			// ȡ��order����
			if (order == null || order.getID() == null) {
				logger.info("Transcation is not exist.<oreder id:" + strOrderId
						+ ">");
				return;
			}
			// ��Ŀ�Ĵ�����
			MLoyProgram program = db.getProgram(order.getPROGRAM_ID());
			if (program == null || program.getID() == null) {
				logger.info("Program is not exist.<Program id is "
						+ order.getPROGRAM_ID() + ".>");
				return;
			}
			// ��Ա����ж�
			logger.info("Start to check member.");
			PromotionManger pm = new PromotionManger();
			String member_Id = order.getMEMBER_ID();
			boolean isSuccess = false;
			if (member_Id == null || member_Id.length() == 0) {
				isSuccess = pm.onQualify(order);
				if (isSuccess) {
					order = db.getOrder(strOrderId);
				}
			} else {
				isSuccess = true;
			}
			if (isSuccess) {
				if (LoyaltyConstants.TRANS_TYPE_BUY.equals(order.getTYPE())) {
					logger.info("��������---����");
					pm.onOrder(order);
				} else if (LoyaltyConstants.TRANS_TYPE_FILLTRANS.equals(order
						.getTYPE())) {
					logger.info("��������---������");
					pm.onOrder(order);
				}
				// �һ�
				else if (LoyaltyConstants.TRANS_TYPE_REDEEM.equals(order
						.getTYPE())) {
					// Promotion����ȡ����Դ�ǡ����ڶ�����������ǡ��һ�����״̬�ǡ�����ļ�¼
					logger.info("��������--- �һ�");
					pm.onSpecialPromotion(order,
							LoyaltyConstants.PROMOTION_TYPE_REDEEM);
				}
				// �˻�
				else if (LoyaltyConstants.TRANS_TYPE_REFUND.equals(order
						.getTYPE())) {
					logger.info("��������--- �˻�����");
					pm.onSpecialPromotion(order,
							LoyaltyConstants.PROMOTION_TYPE_REFUND);
				}
				// ����
				else if (LoyaltyConstants.TRANS_TYPE_GIFT.equals(order
						.getTYPE())) {
					logger.info("��������---����");
					pm.onSpecialPromotion(order,
							LoyaltyConstants.PROMOTION_TYPE_GIFT);
				}
				// �μӻ
				else if (LoyaltyConstants.TRANS_TYPE_CAMPAIGN.equals(order
						.getTYPE())) {
					logger.info("��������--�μӻ");
					// �ӷ�����
					pm.onSpecialPromotion(order,
							LoyaltyConstants.PROMOTION_TYPE_CAMPAIGN);
				} else {
					logger.info("�������ʹ���");
				}
			}
			// �����ɹ� ״̬����
			db
					.updateOrderStatus(order,
							LoyaltyConstants.TRANS_STATUS_PROCESSED);
		} catch (Exception e) {
			logger.info("�����쳣" + e.getMessage());
			if (!cnx.getRollbackOnly()) {
				cnx.setRollbackOnly();
			}
			throw e;
		}
		logger.info("End---------strOrderNum:" + strOrderId);
		return;
	}

	/**
	 * �������ڻ���
	 */
	@TransactionAttribute(TransactionAttributeType.REQUIRED)
	public void handlerExpiryPointRecord(String id, String date)
			throws Exception {
		PointsExpiryManageAct rema = (PointsExpiryManageAct) ObjectUtil
				.getAction(PointsExpiryManageAct.class);
		try {
			rema.process(id, date);
		} catch (Exception e) {
			if (!cnx.getRollbackOnly()) {
				cnx.setRollbackOnly();
			}
			throw e;
		}
	}

	/**
	 * �����ж����ڵĻ�����ϸ
	 */
	@TransactionAttribute(TransactionAttributeType.REQUIRED)
	public void pLValidFlagAdjust(String id) throws Exception {
		PLValidFlagAdjustmentAct plvfaa = (PLValidFlagAdjustmentAct) ObjectUtil
				.getAction(PLValidFlagAdjustmentAct.class);
		try {
			plvfaa.process(id);
		} catch (Exception e) {
			if (!cnx.getRollbackOnly()) {
				cnx.setRollbackOnly();
			}
			throw e;
		}
	}

	@TransactionAttribute(TransactionAttributeType.REQUIRED)
	public Message transferPoint(String fromMemId, String toMemId,
			String pointTypeId, Integer transPoints, String sysDateStr) {
		PointsTransferAct pta = (PointsTransferAct) ObjectUtil
				.getAction(PointsTransferAct.class);
		Message msg = null;
		try {
			Date sysDate = CalendarUtil.convertStringToDate(sysDateStr);
			msg = pta.process(fromMemId, toMemId, pointTypeId, transPoints,
					sysDate);
		} catch (Exception e) {
			if (!cnx.getRollbackOnly()) {
				cnx.setRollbackOnly();
			}
			msg = new PointsTransferMessage();
			msg.setSuccess(false);
			msg.setMsgCode(MessageEnums.SOURCE_POINT_FAILURE);
			msg.setEx(e);
			e.printStackTrace();
			return msg;
		}
		return msg;
	}

	@TransactionAttribute(TransactionAttributeType.REQUIRED)
	public Message adjustPoint(String memberId, String pointTypeId,
			Integer adjustPoints, String operate, String sysDateStr) {
		PointsAdjustAct paa = (PointsAdjustAct) ObjectUtil
				.getAction(PointsAdjustAct.class);
		Message msg = null;
		try {
			Date sysDate = CalendarUtil.convertStringToDate(sysDateStr);
			msg = paa.process(memberId, pointTypeId, adjustPoints, operate,
					sysDate);
		} catch (Exception e) {
			if (!cnx.getRollbackOnly()) {
				cnx.setRollbackOnly();
			}
			msg = new PointsAdjustMessage();
			msg.setSuccess(false);
			msg.setMsgCode(MessageEnums.ADJUST_POINT_FAILURE);
			msg.setEx(e);
			e.printStackTrace();
			return msg;
		}
		return msg;
	}

	/**
	 * @Title: getCnx
	 * @Description: TODO
	 * @param
	 * @return
	 * @return SessionContext
	 * @throws
	 */
	public SessionContext getCnx() {
		return cnx;
	}

	/**
	 * @Title: setCnx
	 * @Description: TODO
	 * @param
	 * @param cnx
	 * @return void
	 * @throws
	 */
	public void setCnx(SessionContext cnx) {
		this.cnx = cnx;
	}

	//add start 2014/04/15 liuxingya
	@Override
	@TransactionAttribute(TransactionAttributeType.REQUIRED)
	public void pointTimely(String memberId, String strSysDate,
			Map<String, Object> params) throws LoyaltyException {
		try {
			logger.info("��������   ��Աʵʱ���ִ�����ʼ  ��������");
			LogUtil.logParamsInfo(logger, memberId, strSysDate, params);
			
			PromotionService db = PromotionService.getInstance();
			MemberInfo m = db.getMemberDetail(memberId);
			
			// ��Ա���ж�
			if (StringUtil.isNotEmpty(m.getFatherId())) {
				throw new LoyaltyException("��Ա�Ѿ����ϲ������ֲ�����Ч", LoyaltyConstants.ERRCD_MEMBER_HAS_BOUND);
			}
			//MMember member = db.getMember(memberId);
			PromotionManger pm = new PromotionManger();
			pm.onTimly(m, strSysDate, params);
		} catch (LoyaltyException e) {
			throw e;
		} catch (Exception e) {
			logger.error("ʵʱ���ִ��������з����쳣.", e);
			throw new LoyaltyException("ʵʱ���ִ��������з����쳣.", e);
		} finally {
			logger.info("��������  ��Աʵʱ���ִ�������  ��������");
		}
	}
	//add end 2014/04/15 liuxingya
	
	@Override
	@TransactionAttribute(TransactionAttributeType.REQUIRED)
	public void orderToPoints(String orderId, String programId) throws LoyaltyException {
		try {
			logger.info("��������   ����ת���ִ�����ʼ  ��������");
			LogUtil.logParamsInfo(logger, orderId, programId);
			
			PromotionService db = PromotionService.getInstance();
			OrderInfo o = db.getOrderInfo(orderId, programId);
			
			if (o == null) {
				throw new LoyaltyException("���������ڻ���δ���");
			}
			
			OrganizationInfo org = db.getOrgInfoByProgram(programId);
			if (org == null || org.getPrograms().isEmpty()) {
				throw new LoyaltyException("��Ա���ֲ������ڻ����ѹ���");
			}
			
			PromotionManger pm = new PromotionManger();
			pm.onOrderToPoint(o, org, DateUtil.getSystemTime());
		} catch (LoyaltyException e) {
			throw e;
		} catch (Exception e) {
			logger.error("����ת���ִ��������з����쳣.", e);
			throw new LoyaltyException("����ת���ִ��������з����쳣.", e);
		} finally {
			logger.info("��������  ����ת���ִ�������  ��������");
		}
	}
}
