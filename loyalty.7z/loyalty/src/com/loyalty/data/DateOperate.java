package com.loyalty.data;

import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;

import com.loyalty.util.DataTypeUtil;

/*
 * �������Ͳ���
 */
public class DateOperate implements Operates {

	public Object divide(DataType dt, String aim) {
		return null;
	}

	public Object multiple(DataType dt, String aim) {
		return null;
	}

	public DateType plus(DataType dt, String aim) {
		if (null == dt || null == aim) {
			return null;
		}
		if (!DataTypeUtil.isCalender(dt)) {
			return null;
		}
		Integer inday = Integer.valueOf(aim);
		GregorianCalendar cCompareTo = new GregorianCalendar();
		cCompareTo.setTime((Date) dt.getData());
		cCompareTo.add(Calendar.DATE, inday);
		DateType afterOpe = new DateType(cCompareTo.getTime());
		return afterOpe;
	}

	public DateType substract(DataType dt, String aim) {
		if (null == dt || null == aim) {
			return null;
		}
		if (!DataTypeUtil.isCalender(dt)) {
			return null;
		}
		Integer inday = Integer.valueOf(aim);
		GregorianCalendar cCompareTo = new GregorianCalendar();
		cCompareTo.setTime((Date) dt.getData());
		cCompareTo.add(Calendar.DATE, (-1) * inday);
		DateType afterOpe = new DateType(cCompareTo.getTime());
		return afterOpe;
	}

	public Object assign(DataType dt, String aim) {
		return null;
	}
}
