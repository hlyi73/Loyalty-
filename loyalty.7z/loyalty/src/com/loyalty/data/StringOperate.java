package com.loyalty.data;

public class StringOperate implements Operates {

	public Object assign(DataType dt, String aim) {
		dt.setData(aim);
		return dt;
	}

	public Object divide(DataType dt, String aim) {
		// TODO Auto-generated method stub
		return null;
	}

	public Object multiple(DataType dt, String aim) {
		// TODO Auto-generated method stub
		return null;
	}

	public Object plus(DataType dt, String aim) {
		// TODO Auto-generated method stub
		return null;
	}

	public Object substract(DataType dt, String aim) {
		// TODO Auto-generated method stub
		return null;
	}

}
