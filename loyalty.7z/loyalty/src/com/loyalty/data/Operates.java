package com.loyalty.data;

public interface Operates {
	Object plus(DataType dt, String aim);

	Object substract(DataType dt, String aim);

	Object multiple(DataType dt, String aim);

	Object divide(DataType dt, String aim);

	Object assign(DataType dt, String aim);
}
