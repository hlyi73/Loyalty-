package com.loyalty.data;

public class DoubleType implements DataType {

	private Double data;

	public DoubleType(Number number) {
		data = (Double) number;
	}

	public DoubleType(Double in) {
		data = in;
	}

	public DoubleType(Object o) {
		data = (Double) o;
	}

	public Double getData() {
		return data;
	}

	public void setData(Object data) {
		data = (Double) data;

	}

	public String toString() {
		return data.toString();
	}

}
