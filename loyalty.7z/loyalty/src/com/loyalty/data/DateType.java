package com.loyalty.data;

import java.util.Date;

import com.loyalty.util.CalendarUtil;

public class DateType implements DataType {

	private Date data;

	public DateType(Date date) {
		this.data = date;
	}

	public DateType(Object o) {
		this.data = (Date) o;
	}

	public String toString() {
		return CalendarUtil.getStringDateFormatted(data);
	}

	public Date getData() {
		// TODO Auto-generated method stub
		return data;
	}

	public void setData(Object o) {
	}
}
