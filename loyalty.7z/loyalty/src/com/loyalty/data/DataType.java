package com.loyalty.data;

public interface DataType {

	Object getData();

	void setData(Object data);

}
