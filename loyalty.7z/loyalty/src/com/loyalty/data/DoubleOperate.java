package com.loyalty.data;

import java.math.BigDecimal;

import com.loyalty.util.DataTypeUtil;

public class DoubleOperate implements Operates {

	public Object divide(DataType dt, String aim) {
		if (!DataTypeUtil.isDouble(dt)) {
			return null;
		}
		Double operationalVal = Double.valueOf(aim);
		DoubleType sourceType = (DoubleType) dt;
		BigDecimal sourceBigDecimal = new BigDecimal(Double.toString(sourceType
				.getData()));
		BigDecimal operationBigDecimal = new BigDecimal(Double
				.toString(operationalVal));
		DoubleType afterOperate = new DoubleType((sourceBigDecimal
				.divide(operationBigDecimal)).doubleValue());
		return afterOperate;
	}

	public Object multiple(DataType dt, String aim) {
		if (!DataTypeUtil.isDouble(dt)) {
			return null;
		}
		Double operationalVal = Double.valueOf(aim);
		DoubleType sourceType = (DoubleType) dt;
		BigDecimal sourceBigDecimal = new BigDecimal(Double.toString(sourceType
				.getData()));
		BigDecimal operationBigDecimal = new BigDecimal(Double
				.toString(operationalVal));
		DoubleType afterOperate = new DoubleType((sourceBigDecimal
				.multiply(operationBigDecimal)).doubleValue());
		return afterOperate;
	}

	public Object plus(DataType dt, String aim) {
		if (!DataTypeUtil.isDouble(dt)) {
			return null;
		}
		Double operationalVal = Double.valueOf(aim);
		DoubleType sourceType = (DoubleType) dt;
		DoubleType afterOperate = new DoubleType(sourceType.getData()
				+ operationalVal);
		return afterOperate;
	}

	public Object substract(DataType dt, String aim) {
		if (!DataTypeUtil.isDouble(dt)) {
			return null;
		}
		Double operationalVal = Double.valueOf(aim);
		DoubleType sourceType = (DoubleType) dt;
		DoubleType afterOperate = new DoubleType(sourceType.getData()
				- operationalVal);
		return afterOperate;
	}

	public Object assign(DataType dt, String aim) {
		if (!DataTypeUtil.isDouble(dt)) {
			return null;
		}
		Double operationalVal = Double.valueOf(aim);
		DoubleType afterOperate = new DoubleType(operationalVal);
		return afterOperate;
	}
}
