package com.loyalty.data;

import com.loyalty.util.DataTypeUtil;

public class IntegerOperate implements Operates {

	public Object divide(DataType dt, String aim) {
		if (!DataTypeUtil.isInteger(dt)) {
			return null;
		}
		Integer operationalVal = Integer.valueOf(aim);
		IntegerType sourceType = (IntegerType) dt;
		IntegerType afterOperate = new IntegerType(sourceType.getData()
				/ operationalVal);
		return afterOperate;
	}

	public Object multiple(DataType dt, String aim) {
		if (!DataTypeUtil.isInteger(dt)) {
			return null;
		}
		Integer operationalVal = Integer.valueOf(aim);
		IntegerType sourceType = (IntegerType) dt;
		IntegerType afterOperate = new IntegerType(sourceType.getData()
				* operationalVal);
		return afterOperate;
	}

	public Object plus(DataType dt, String aim) {
		if (!DataTypeUtil.isInteger(dt)) {
			return null;
		}
		Integer operationalVal = Integer.valueOf(aim);
		IntegerType sourceType = (IntegerType) dt;
		IntegerType afterOperate = new IntegerType(sourceType.getData()
				+ operationalVal);
		return afterOperate;
	}

	public Object substract(DataType dt, String aim) {
		if (!DataTypeUtil.isInteger(dt)) {
			return null;
		}
		Integer operationalVal = Integer.valueOf(aim);
		IntegerType sourceType = (IntegerType) dt;
		IntegerType afterOperate = new IntegerType(sourceType.getData()
				- operationalVal);
		return afterOperate;
	}

	public Object assign(DataType dt, String aim) {
		if (!DataTypeUtil.isInteger(dt)) {
			return null;
		}
		Integer operationalVal = Integer.valueOf(aim);
		IntegerType afterOperate = new IntegerType(operationalVal);
		return afterOperate;
	}

}
