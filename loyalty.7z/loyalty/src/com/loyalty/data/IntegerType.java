package com.loyalty.data;

public class IntegerType implements DataType {

	private Integer data;

	public IntegerType(Number number) {
		data = (Integer) number;
	}

	public IntegerType(Integer in) {
		data = in;
	}

	public IntegerType(Object o) {
		data = (Integer) o;
	}

	public Integer getData() {
		return data;
	}

	public void setData(Object data) {
		data = (Integer) data;

	}

	public String toString() {
		return data.toString();
	}

}
