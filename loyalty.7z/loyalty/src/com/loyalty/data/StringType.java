package com.loyalty.data;

import java.util.Date;

public class StringType implements DataType {

	private String data;

	public StringType(String data) {
		this.data = data;
	}

	public StringType(Object o) {
		if (!(data instanceof String)) {
			data = null;
		}
		this.data = (String) o;
	}

	public Object getData() {
		return data;
	}

	public void setData(Object data) {
		if (!(data instanceof String)) {
			return;
		}
		this.data = (String) data;
	}

	public String toString() {
		return data;
	}
}
