package com.loyalty.service;

import java.util.Date;
import java.util.List;
import org.apache.log4j.Logger;
import com.ibatis.dao.client.DaoManager;
import com.loyalty.action.Action;
import com.loyalty.bean.ActionInfo;
import com.loyalty.bean.PointsDetail;
import com.loyalty.bean.RuleInfo;
import com.loyalty.dao.FluentPromotionDAO;
import com.loyalty.dao.MActionCommonDAO;
import com.loyalty.dao.MActionDAO;
import com.loyalty.dao.MMemberCardDAO;
import com.loyalty.dao.MSqlDAO;
import com.loyalty.dto.MAction;
import com.loyalty.dto.MAttributes;
import com.loyalty.dto.MCustAction;
import com.loyalty.dto.MCustomer;
import com.loyalty.dto.MLoyOrder;
import com.loyalty.dto.MMember;
import com.loyalty.dto.MMemberActiveHis;
import com.loyalty.dto.MMemberAttrData;
import com.loyalty.dto.MMemberCard;
import com.loyalty.dto.MMemberTier;
import com.loyalty.dto.MOrderDetail;
import com.loyalty.dto.MPointList;
import com.loyalty.dto.MPointType;
import com.loyalty.dto.MPoints;
import com.loyalty.dto.MPointsHis;
import com.loyalty.dto.MPointsRate;
import com.loyalty.dto.MPromotion;
import com.loyalty.dto.MPromotionAttrData;
import com.loyalty.dto.MRule;
import com.loyalty.dto.MTier;
import com.loyalty.dto.MTierClass;
import com.loyalty.dto.MTierDetail;
import com.loyalty.system.DAOConfig;
import com.loyalty.util.DAOUtil;
import com.loyalty.util.LoyaltyConstants;

public class ActionService implements Action {
	public static Logger logger = Logger.getLogger(ActionService.class);

	private MActionCommonDAO macDao;
	private DaoManager daoManager;

	public ActionService() {
		macDao = (MActionCommonDAO) DAOUtil.getDao(MActionCommonDAO.class);
	}

	/**
	 * ��ȡ���׶���
	 * 
	 * @param orderId
	 * @return
	 */
	public MLoyOrder getMLoyOrderByOrderId(String orderId) {
		if (null == orderId) {
			return null;
		}
		MLoyOrder mlo = new MLoyOrder();
		mlo.setID(orderId);
		mlo = (MLoyOrder) macDao.selectByPrimaryKey(mlo);
		return mlo;
	}

	public MRule getMRuleByRuleId(String ruleId) {
		if (null == ruleId) {
			return null;
		}
		MRule mr = new MRule();
		mr.setID(ruleId);
		mr = (MRule) macDao.selectByPrimaryKey(mr);
		return mr;
	}

	public MPromotion getMPromotionByPromotionId(String promotionId) {
		if (null == promotionId) {
			return null;
		}
		MPromotion mp = new MPromotion();
		mp.setID(promotionId);
		mp = (MPromotion) macDao.selectByPrimaryKey(mp);
		return mp;
	}

	public MMember getMMemberByMemberId(String memberId) {
		if (null == memberId) {
			return null;
		}
		MMember mm = new MMember();
		mm.setID(memberId);
		mm = (MMember) macDao.selectByPrimaryKey(mm);
		return mm;
	}

	public MPoints getMPointsByPointTypeIdAndMemberId(String pointTypeId,
			String memberId) {
		if (null == pointTypeId || null == memberId) {
			return null;
		}
		MPoints mps = macDao.selectMPointsByPointTypeIdAndMemberId(pointTypeId,
				memberId);

		return mps;
	}

	public Boolean updateMPoints(MPoints mPoints) throws RuntimeException {
		Boolean success = false;
		macDao.updateByPrimaryKey(mPoints);
		success = true;
		return success;
	}

	public void appendToMOrderDetail(MOrderDetail md) {
		macDao.insert(md);
	}

	public List<MAction> getMActionsByRuleId(String ruleId) {
		if (ruleId == null) {
			return null;
		}
		List<MAction> actions = macDao.selectActionsByForeignKey(ruleId);
		return actions;
	}

	public Boolean appendMPointsForMember(MPoints mPoints) {
		Boolean success = false;
		macDao.insert(mPoints);
		success = true;
		return success;
	}

	public MMemberCard getMMemberCardByMemberId(String memberId) {
		if (null == memberId) {
			return null;
		}
		MMemberCard c = new MMemberCard();
		return macDao.selectMMemberCardByForeingnKey(c);
	}

	public MCustomer getMCustomerByCustomerId(String custId) {
		if (null == custId) {
			return null;
		}
		MCustomer mc = new MCustomer();
		mc.setID(custId);
		mc = (MCustomer) macDao.selectByPrimaryKey(mc);
		return mc;
	}

	public List<MTier> getMTiersByProgramId(String programId) {

		if (null == programId) {
			return null;
		}
		MTierClass mtc = getMTierClassByProgramId(programId);
		if (null == mtc) {
			return null;
		}
		List<MTier> mts = macDao.selectMTierByMTierClassId(mtc.getID());
		return mts;
	}

	/*
	 * �����»�Ա,��Ա�ȼ�����Ա����Ϣ
	 */
	public void appendNewMMemberAndOtherInfos(MMember mMember, MMemberTier mmt,
			MMemberCard mmc, MMemberActiveHis mmah) {
		macDao.insert(mMember);
		macDao.insert(mmt);
		macDao.insert(mmc);
		macDao.insert(mmah);
	}

	/*
	 * ͨ����Ŀid��ȡ�ȼ����
	 */
	public MTierClass getMTierClassByProgramId(String programId) {
		if (null == programId) {
			return null;
		}
		MTierClass mtc = macDao.selectMTierClassByProgramId(programId);
		return mtc;
	}

	/*
	 * ��ȡ����״̬��Ա�ȼ�
	 */
	public MMemberTier getActiveMMemberTierByMMemberIdAndMTierClassId(
			String memberId, String mTierClassId, Integer activeFlag) {
		if (null == memberId) {
			return null;
		}
		MMemberTier mmt = macDao
				.selectMMemberTierByMMemberIdAndMTierClassIdAndActiveFlag(
						memberId, mTierClassId, activeFlag);
		return mmt;
	}

	/*
	 * ��ȡ�ȼ�
	 */
	public MTier getMTierById(String mTierId) {
		if (null == mTierId) {
			return null;
		}
		MTier mt = new MTier();
		mt.setID(mTierId);
		mt = (MTier) macDao.selectByPrimaryKey(mt);
		return mt;
	}

	/*
	 * ������Ա�ȼ�
	 */
	public Boolean adjustMMemberTier(MMemberTier currentMmt, MMemberTier newMmt)
			throws Exception {
		Boolean isSuccess = false;
		if (null == currentMmt || null == newMmt) {
			return isSuccess;
		}
		macDao.updateByPrimaryKey(currentMmt);
		macDao.insert(newMmt);
		isSuccess = true;
		return isSuccess;
	}

	/*
	 * ���ݿͻ�id��û�Ա��Ϣ
	 */

	public MMember getActiveMMemberByCustIdAndProgramId(String custId,
			String programId) {
		return macDao.selectMMemberByCustomerIdAndProgramId(custId, programId);
	}

	/*
	 * 
	 */
	public MAttributes getMAttributesById(String id) {
		if (null == id) {
			return null;
		}
		MAttributes attrTo = new MAttributes();
		attrTo.setID(id);
		attrTo = (MAttributes) macDao.selectByPrimaryKey(attrTo);
		return attrTo;
	}

	public void updateDynTableData(String sql) throws Exception {
		macDao.updateTableData(sql);
	}

	public List<MMemberTier> getMMemberTiersByMemberIdAndFlagActive(
			String memberId, int flag) {
		if (null == memberId) {
			return null;
		}
		List<MMemberTier> mmts = macDao
				.selectMMemberTierByMMemberIdAndActiveFlag(memberId, flag);
		return mmts;
	}

	public void updateAndInsertMMemberTier(List<MMemberTier> updataData,
			MMemberTier insertData, MMember member, MMemberActiveHis mmah) {

		for (MMemberTier mmt : updataData) {
			macDao.updateByPrimaryKey(mmt);
		}
		macDao.insert(insertData);

		if (null != member) {
			macDao.updateByPrimaryKey(member);
		}
		macDao.insert(mmah);
	}

	public void recordPointsDetails(MPointList mpl) {
		macDao.insert(mpl);
	}

	public MPointType findMPointTypeById(String pointTypeId) {
		MPointType pointType = new MPointType();
		pointType.setID(pointTypeId);
		return (MPointType) macDao.selectByPrimaryKey(pointType);
	}

	public void appendNewMPointType(MPointType pointType) {
		macDao.updateByPrimaryKey(pointType);
	}

	public void appendNewMPointList(MPointList mpl) {
		macDao.insert(mpl);
	}

	public MPointsRate findMPointsRateByCurrencyType(String currencyType,
			String orgId) {
		MPointsRate pointsRate = new MPointsRate();
		pointsRate.setCURRENCY_CODE(currencyType);
		pointsRate.setORG_ID(orgId);
		macDao.selectMPointsRateByCurrencyType(pointsRate);
		return macDao.selectMPointsRateByCurrencyType(pointsRate);
	}

	public List<MPointList> findPointListsByTypeIdAndMemberIdThanZeroAndValidStatus(
			String pointTypeId, String memberId) {
		MPointList pointList = new MPointList();
		pointList.setPOINT_TYPE_ID(pointTypeId);
		pointList.setMEMBER_ID(memberId);
		pointList.setPOINTS(0);
		pointList.setVALID_FLAG(LoyaltyConstants.LOYALTY_ACTIVE);
		return macDao
				.selectPointListsByTypeIdAndMemberIdThanZeroAndValidStatus(pointList);
	}

	public List<MPointList> findExpiryDatePointLists(Date expiryDate) {
		MPointList expiry = new MPointList();
		expiry.setEND_DATE(expiryDate);

		return macDao.selectPointListsByExpiryDate(expiry);

	}

	public void updatePointList(MPointList pointList) {
		macDao.updateByPrimaryKey(pointList);
	}

	public DaoManager getDaoManager() {
		return daoManager;
	}

	public void setDaoManager(DaoManager daoManager) {
		this.daoManager = daoManager;
	}

	public void appendMTierDetail(MTierDetail tierDetail) {
		macDao.insert(tierDetail);
	}

	public void updateMLoyOrder(MLoyOrder mlo) {
		macDao.updateByPrimaryKey(mlo);
	}

	public List<MOrderDetail> findOrderDetailListByOrderId(String orderId) {
		MOrderDetail orderDetail = new MOrderDetail();
		orderDetail.setORDER_ID(orderId);
		List<MOrderDetail> orderDetails = macDao
				.selectOrderDetailList(orderDetail);
		return orderDetails;
	}

	/**
	 * 
	 * @param points
	 * @param pointList
	 */
	public void updatePointsAndPointList(Object points, MPointList pointList) {
		if (null == points || null == pointList) {
			return;
		}
		macDao.updateByPrimaryKey(points);
		macDao.updateByPrimaryKey(pointList);
	}

	/**
	 * ͨ����Աid���������ͣ���Ա�ڲ���
	 */
	public MPoints findAdjustedPoints(String memberId, String pointTypeId,
			String memberPeriod) {
		MPoints p = new MPoints();
		p.setMEMBER_ID(memberId);
		p.setMEMBER_PERIOD(memberPeriod);
		p.setPOINT_TYPE_ID(pointTypeId);
		return macDao.selectMPointsByMemberIdAndPointTypeIdAndMemberPeriod(p);
	}

	/**
	 * ͨ����Աid���������ͣ���Ա�ڲ���
	 */
	public MPointsHis findAdjustedPointsHis(String memberId,
			String pointsTypeId, String memberPeriod) {

		MPointsHis p = new MPointsHis();
		p.setMEMBER_ID(memberId);
		p.setMEMBER_PERIOD(memberPeriod);
		p.setPOINTS_TYPE_ID(pointsTypeId);
		return macDao
				.selectMPointsHisByMemberIdAndPointTypeIdAndMemberPeriod(p);

	}

	/**
	 * ͨ��memberId���Ҹ��ֻ���
	 */
	public List<MPoints> findPointsByMemberId(String memberId) {
		MPoints p = new MPoints();
		p.setMEMBER_ID(memberId);
		return macDao.selectPointsByMemberId(p);
	}

	/**
	 * ��Ա����,���»��ֱ����ݣ��������ݵ�������ʷ
	 */
	public void updatePointsAndInsertPointsHis(MPoints points,
			MPointsHis pointsHis) {
		macDao.insert(pointsHis);
		macDao.updateByPrimaryKey(points);
	}

	/**
	 * 
	 * @param requestMember
	 * @param mmah
	 */
	public void updateMemberAndAppendActiveHis(MMember requestMember,
			MMemberActiveHis mmah) {
		macDao.updateByPrimaryKey(requestMember);
		macDao.insert(mmah);
	}

	/**
	 * 
	 * @return
	 */
	public MActionCommonDAO getMacDao() {
		return macDao;
	}

	/**
	 * 
	 * @param macDao
	 */
	public void setMacDao(MActionCommonDAO macDao) {
		this.macDao = macDao;
	}

	/**
	 * 
	 * @param procedureName
	 * @param memberId
	 * @param orderId
	 * @return
	 */
	public Integer callMCustCriteria(String procedureName, String memberId,
			String orderId) {
		MSqlDAO dao = (MSqlDAO) DAOConfig.getDaoManager().getDao(MSqlDAO.class);
		return dao.callMCustCriteria(procedureName, memberId, orderId);
	}

	/**
	 * 
	 * @param ruleId
	 * @return
	 */
	public List<MCustAction> getCustActionsByRuleId(String ruleId) {
		return macDao.selectCustActionsByRuleId(ruleId);
	}

	/**
	 * 
	 * @param orderId
	 * @return
	 */
	public List<MPointList> getPointListsByOrderId(String orderId) {
		MPointList p = new MPointList();
		p.setORDER_ID(orderId);
		return macDao.selectPointListsByOrderId(p);
	}

	/**
	 * 
	 */
	public List<MMemberAttrData> findMAttrDatasByPIdAndMId(String memberId,
			String programId) {
		MMemberAttrData mad = new MMemberAttrData();
		mad.setMEMBER_ID(memberId);
		mad.setPROGRAM_ID(programId);
		return macDao.selectMAttrDataByPIdAndMId(mad);
	}

	public List<MPromotionAttrData> findPAttrDatasByPIdAndMIdAndProId(
			String memberId, String programId, String promotionId) {
		MPromotionAttrData p = new MPromotionAttrData();
		p.setMEMBER_ID(memberId);
		p.setPROGRAM_ID(programId);
		p.setPROMOTION_ID(promotionId);
		return macDao.selectPAttrDatasByPIdAndMIdAndProId(p);
	}

	public List<MPoints> findMPointsByMemberId(String mId) {
		MPoints record = new MPoints();
		record.setMEMBER_ID(mId);
		return macDao.selectMPointsByMId(record);
	}

	public MPointsHis findMPointsHisByMIdAndPidAndMPeriod(String mId,
			String pId, String mP) {
		MPointsHis record = new MPointsHis();
		record.setMEMBER_ID(mId);
		record.setPOINTS_TYPE_ID(pId);
		record.setMEMBER_PERIOD(mP);
		return macDao.selectMPointsHisByMIdAndPidAndMPeriod(record);

	}
	
	// 20140519 SQL�Ż� liuhui
	/**
	 * @Title: getActionsByRuleId
	 * @Description: �����������õ������ActionInfo
	 * 
	 * @param ruleId
	 * @return List<ActionInfo>
	 * @throws
	 */
	public List<ActionInfo> getActionsByRuleId(String ruleId) {
		FluentPromotionDAO dao = (FluentPromotionDAO) DAOConfig.getDaoManager()
				.getDao(FluentPromotionDAO.class);
		return dao.selectActionsByRuleId(ruleId);
	}
	
	/**
	 * @Title: getActionsByRuleId
	 * @Description: �����������õ������ActionInfo
	 * 
	 * @param ruleId
	 * @return List<ActionInfo>
	 * @throws
	 */
	public List<PointsDetail> getPointDetails(String memId, String ptId) {
		FluentPromotionDAO dao = (FluentPromotionDAO) DAOConfig.getDaoManager()
				.getDao(FluentPromotionDAO.class);
		return dao.selectPointsDetails(memId, ptId);
	}
	
	/**
	 * @Title: getActionsByRuleId
	 * @Description: �����������õ������ActionInfo
	 * 
	 * @param ruleId
	 * @return List<ActionInfo>
	 * @throws
	 */
	public void updatePointDetails(List<PointsDetail> pds) {
		FluentPromotionDAO dao = (FluentPromotionDAO) DAOConfig.getDaoManager()
				.getDao(FluentPromotionDAO.class);
		for (PointsDetail pd : pds) {
			dao.updatePointsDetails(pd);
		}
	}
	
	public MAction getActionById(String id) {
		return ((MActionDAO) DAOUtil.getDao(MActionDAO.class)).selectByPrimaryKey(id);
	}
}
